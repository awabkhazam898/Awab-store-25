import config
from binance.client import Client

# الاتصال بـ API
c = Client(config.BINANCE_API_KEY, config.BINANCE_API_SECRET)

print("=== 💳 سجل تحويلات Binance Pay ===")
try:
    res = c.get_pay_trade_history()
    records = res.get('data', [])
    
    if records:
        for item in records:
            # تحديد نوع المعاملة (إيداع أم سحب)
            # في API بايننس Pay: orderType أو المعاملات ذات المبالغ الإيجابية تعتبر إيداع
            order_type = item.get('orderType', '')
            amount = float(item.get('amount', 0))
            
            # تصنيف العملية
            if "RECEIVE" in order_type.upper() or amount > 0:
                type_str = "📥 إيداع (استلام)"
            else:
                type_str = "📤 سحب (دفع)"

            print(f"🔹 **نوع المعاملة:** {type_str}")
            print(f"🔹 **معرف الطلب (Order ID):** {item.get('orderId')}")
            print(f"🔹 **معرف المعاملة (TxID):** {item.get('transactionId')}")
            print(f"🔹 **المبلغ:** {abs(amount)} {item.get('currency')}")
            print(f"🔹 **الحالة:** {item.get('status')}")
            print('-' * 35)
    else:
        print("💡 لا توجد معاملات مسجلة في Binance Pay.")

except Exception as e:
    print(f"⚠️ حدث خطأ: {e}")
import config
from binance.client import Client

client = Client(config.BINANCE_API_KEY, config.BINANCE_API_SECRET)

print("--- 💳 رصيد محفظة التمويل ---")
wallet_data = client.funding_wallet()

for item in wallet_data:
    if item['asset'] == 'USDT':
        print(f"🔹 USDT المتاح: {item['free']}")
        print(f"🔹 USDT المجمد: {item['freeze']}")
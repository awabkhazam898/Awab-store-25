"""
=============================================================
  run.py — نقطة تشغيل التطبيق
=============================================================
"""

import os
from app import create_app
from app.extensions import db

app = create_app()


def init_db():
    """إنشاء جداول قاعدة البيانات إذا لم تكن موجودة"""
    with app.app_context():
        from app.models import (user, order, product, inventory,
                                 payment, rewards, admin_staff, notification)
        db.create_all()
        # تهيئة البيانات الأولية
        from app.models import init_db as _init
        _init(app)
        print("Database initialized.")


if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_ENV", "development") == "development"
    print(f"Awab Store running on port {port}")
    app.run(host="0.0.0.0", port=port, debug=debug, use_reloader=False)

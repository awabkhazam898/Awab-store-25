import sqlite3

conn = sqlite3.connect('awab_store.db')
conn.row_factory = sqlite3.Row
cur = conn.cursor()
cur.execute("SELECT request_id, user_id, amount, method, status, sender_phone, sms_reference, binance_transaction_id, created_at, confirmed_at FROM top_up_requests ORDER BY id DESC LIMIT 10")
rows = cur.fetchall()
for r in rows:
    print(dict(r))
    print('---')
conn.close()

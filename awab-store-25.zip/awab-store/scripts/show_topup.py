import sqlite3
import os
DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'awab_store.db')
DB = os.path.abspath(DB)
req_id = 'TOP-075443AD'

conn = sqlite3.connect(DB)
conn.row_factory = sqlite3.Row
cur = conn.cursor()
try:
    cur.execute('SELECT * FROM top_up_requests WHERE request_id = ?', (req_id,))
    rows = cur.fetchall()
    if not rows:
        print('No rows found for', req_id)
    else:
        for r in rows:
            for k in r.keys():
                print(f'{k}: {r[k]}')
            print('-' * 40)
finally:
    conn.close()

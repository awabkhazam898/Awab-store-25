import sqlite3
import os

DB = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'awab_store.db'))
print('DB', DB)
conn = sqlite3.connect(DB)
conn.row_factory = sqlite3.Row
cur = conn.cursor()
cur.execute("SELECT id, request_id, user_id, amount, method, status, sender_phone, sms_reference, binance_transaction_id, created_at, confirmed_at FROM top_up_requests ORDER BY id DESC LIMIT 10")
rows = cur.fetchall()
for row in rows:
    print(dict(row))
    print('---')
conn.close()

"""Telegram bot side handlers and helpers.

Currently hosts the live auction flow (start, bid, finalize). The legacy
order-handling callbacks in `bot.py` continue to live there for backwards
compatibility.
"""

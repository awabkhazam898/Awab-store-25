"""Telegram bot side of the auction feature.

This module is imported by ``bot.py`` so the long-running auction workflow
(start auction, place bid from channel, admin decision, finalize) stays
isolated from the legacy order callbacks.

All database operations run inside the supplied Flask ``app.app_context()``.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from app.models.features import Auction, AuctionBid, TelegramLink
from app.services.features import finalize_auction, money, place_bid

logger = logging.getLogger("awab_bot.auctions")

# ---------------------------------------------------------------------------
# Localisation helpers (Arabic)
# ---------------------------------------------------------------------------
AR_DIGITS = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")


def fmt_money(value: float) -> str:
    return f"{value:.2f}".translate(AR_DIGITS)


def countdown(seconds: int) -> str:
    seconds = max(int(seconds), 0)
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def auction_brief(auction: Auction, highest_text: Optional[str] = None) -> str:
    """Short Arabic card describing an auction for inline buttons."""
    highest = auction.bids.order_by(AuctionBid.amount.desc(),
                                    AuctionBid.created_at.asc()).first()
    highest_label = highest_text or (
        f"${fmt_money(highest.amount)} من @{highest.user.username}" if highest
        else "لا توجد مزايدات بعد"
    )
    remaining = max((auction.ends_at - datetime.utcnow()).total_seconds(), 0)
    return (
        f"🏷️ <b>المزاد على:</b> {auction.title}\n"
        f"💰 <b>سعر البداية:</b> ${fmt_money(auction.start_price)}\n"
        f"📈 <b>قيمة المزايدة:</b> +${fmt_money(auction.bid_step)}\n"
        f"🥇 <b>أعلى مزايدة:</b> {highest_label}\n"
        f"⏱️ <b>الوقت المتبقي:</b> {countdown(remaining)}\n"
    )


def auction_keyboard(auction: Auction) -> InlineKeyboardMarkup:
    """Build the public bid keyboard shown in the channel/group post."""
    next_bid = auction.bid_step
    highest = auction.bids.order_by(AuctionBid.amount.desc()).first()
    if highest:
        next_bid = float(highest.amount) + auction.bid_step
    return InlineKeyboardMarkup([[
        InlineKeyboardButton(
            f"➕ زايد بـ ${fmt_money(next_bid)}",
            callback_data=f"bid:{auction.id}",
        )
    ]])


# ---------------------------------------------------------------------------
# Channel-facing commands
# ---------------------------------------------------------------------------
async def cmd_auction(update: Update, context: ContextTypes.DEFAULT_TYPE,
                      flask_app, chat_id: Optional[int] = None) -> None:
    """Post a fresh auction card into the configured Telegram chat."""
    args = context.args or []
    if len(args) < 1:
        await update.message.reply_text("استخدم: /auction <auction_id>")
        return
    try:
        auction_id = int(args[0])
    except ValueError:
        await update.message.reply_text("رقم المزاد غير صحيح.")
        return

    with flask_app.app_context():
        auction = Auction.query.get(auction_id)
        if not auction or auction.status != "active":
            await update.message.reply_text("المزاد غير متاح.")
            return
        target = chat_id or update.effective_chat.id
        text = auction_brief(auction)
        sent = await context.bot.send_message(
            chat_id=target,
            text=text,
            reply_markup=auction_keyboard(auction),
            parse_mode=ParseMode.HTML,
        )
        auction.telegram_chat_id = sent.chat_id
        auction.telegram_message_id = sent.message_id
        from app.extensions import db
        db.session.commit()


async def cb_bid(update: Update, context: ContextTypes.DEFAULT_TYPE,
                 flask_app) -> None:
    """Handle a press on the public ➕ bid button."""
    query = update.callback_query
    await query.answer("جاري التحقق من رصيدك...")
    tid = update.effective_user.id
    try:
        auction_id = int((query.data or "").split(":", 1)[1])
    except (ValueError, IndexError):
        await query.answer("بيانات الزر غير صالحة.", show_alert=True)
        return

    with flask_app.app_context():
        link = TelegramLink.query.filter_by(telegram_id=tid).first()
        if not link or not link.verified_at:
            await query.answer(
                "🔗 اربط حسابك في الموقع أولاً عبر صفحة الحساب.",
                show_alert=True,
            )
            return

        try:
            bid = place_bid(auction_id, link.user_id, telegram_id=tid)
        except ValueError as exc:
            await query.answer(f"❌ {exc}", show_alert=True)
            return

        auction = Auction.query.get(auction_id)
        if not auction:
            await query.answer("المزاد غير موجود.", show_alert=True)
            return

        username = update.effective_user.username or "مستخدم"
        text = auction_brief(
            auction,
            highest_text=f"${fmt_money(bid.amount)} من @{username}",
        )
        try:
            await context.bot.edit_message_text(
                chat_id=auction.telegram_chat_id,
                message_id=auction.telegram_message_id,
                text=text,
                reply_markup=auction_keyboard(auction),
                parse_mode=ParseMode.HTML,
            )
        except Exception as exc:
            logger.warning("تعذر تحديث منشور المزاد: %s", exc)
        await query.answer(
            f"✅ تم تسجيل مزايدتك بقيمة ${fmt_money(bid.amount)}",
            show_alert=True,
        )


# ---------------------------------------------------------------------------
# Admin decision flow (finalize / cancel)
# ---------------------------------------------------------------------------
async def send_admin_decision_card(context: ContextTypes.DEFAULT_TYPE,
                                    flask_app, auction: Auction) -> None:
    """Send a private report to the owner with inline decision buttons."""
    from config import OWNER_TELEGRAM_ID
    if not OWNER_TELEGRAM_ID:
        logger.warning("OWNER_TELEGRAM_ID غير معرّف، لا يمكن إرسال تقرير المزاد.")
        return

    bids = auction.bids.order_by(AuctionBid.amount.desc(),
                                 AuctionBid.created_at.asc()).all()
    medals = ["🥇", "🥈", "🥉"]
    lines = [
        f"📊 <b>انتهى وقت المزاد على:</b> {auction.title}",
        f"💰 <b>سعر البداية:</b> ${fmt_money(auction.start_price)}",
        f"👥 <b>إجمالي المشاركين:</b> {len(bids)} زبون",
        "",
        "<b>قائمة المزايدين بالترتيب:</b>",
    ]
    for idx, bid in enumerate(bids[:10], start=1):
        medal = medals[idx - 1] if idx <= 3 else f"{idx}."
        username = (
            f"@{bid.user.username}" if bid.user else f"ID:{bid.user_id}"
        )
        lines.append(
            f"{medal} {username} — المزايدة: ${fmt_money(bid.amount)}"
        )

    if not bids:
        lines.append("لا توجد مزايدات.")

    buttons = []
    if bids:
        winner = bids[0]
        winner_handle = (
            f"@{winner.user.username}" if winner.user else "الفائز"
        )
        buttons.append([
            InlineKeyboardButton(
                f"🟢 البيع لـ {winner_handle} (${fmt_money(winner.amount)})",
                callback_data=f"auction_sell:{auction.id}",
            )
        ])
    buttons.append([
        InlineKeyboardButton(
            "🔴 إلغاء لعدم الاكتفاء",
            callback_data=f"auction_cancel:{auction.id}",
        )
    ])

    try:
        await context.bot.send_message(
            chat_id=OWNER_TELEGRAM_ID,
            text="\n".join(lines),
            reply_markup=InlineKeyboardMarkup(buttons),
            parse_mode=ParseMode.HTML,
        )
    except Exception as exc:
        logger.warning("فشل إرسال تقرير المزاد للمالك: %s", exc)


async def cb_auction_decision(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              flask_app) -> None:
    """Finalize an auction by selling or cancelling it."""
    from config import OWNER_TELEGRAM_ID
    query = update.callback_query
    await query.answer()
    if update.effective_user.id != OWNER_TELEGRAM_ID:
        await query.answer("🔒 إجراء المالك فقط.", show_alert=True)
        return

    action, _, payload = (query.data or "").partition(":")
    try:
        auction_id = int(payload)
    except ValueError:
        await query.edit_message_text("رقم المزاد غير صالح.")
        return

    with flask_app.app_context():
        from app.extensions import db
        auction = Auction.query.get(auction_id)
        if not auction:
            await query.edit_message_text("المزاد غير موجود.")
            return
        if auction.status != "active":
            await query.edit_message_text(f"المزاد بحالة: {auction.status}")
            return

        if action == "auction_sell":
            try:
                bid = finalize_auction(auction.id)
            except ValueError as exc:
                await query.edit_message_text(f"❌ {exc}")
                return
            if not bid:
                await query.edit_message_text(
                    "⚠️ لا يوجد مزايدين، تم الإلغاء."
                )
                return
            await _notify_auction_sold(context, auction, bid)
            username = bid.user.username if bid.user else "الفائز"
            await query.edit_message_text(
                f"🟢 تم البيع لـ @{username} مقابل "
                f"${fmt_money(bid.amount)}.\n"
                f"تم خصم المبلغ وإرسال المنتج.",
            )
        else:
            auction.status = "cancelled"
            db.session.commit()
            await _notify_auction_cancelled(context, auction)
            await query.edit_message_text("🔴 تم إلغاء المزاد.")


async def _notify_auction_sold(context, auction: Auction,
                               bid: AuctionBid) -> None:
    if auction.telegram_chat_id and auction.telegram_message_id:
        try:
            winner = bid.user.username if bid.user else "الفائز"
            await context.bot.edit_message_text(
                chat_id=auction.telegram_chat_id,
                message_id=auction.telegram_message_id,
                text=(
                    f"🏁 <b>أُغلق المزاد!</b>\n"
                    f"🥇 الفائز: @{winner}\n"
                    f"💰 المبلغ: ${fmt_money(bid.amount)}\n"
                    f"🎉 تهانينا!"
                ),
                parse_mode=ParseMode.HTML,
            )
        except Exception:
            pass

    delivery = auction.delivery_text or (
        "سيتم تسليم بيانات الحساب لك قريباً."
    )
    target_tid = bid.telegram_id
    if not target_tid and bid.user_id:
        link = TelegramLink.query.filter_by(user_id=bid.user_id).first()
        if link:
            target_tid = link.telegram_id
    if not target_tid:
        logger.info("لا يوجد telegram_id لإرسال التسليم للمستخدم %s", bid.user_id)
        return
    try:
        await context.bot.send_message(
            chat_id=target_tid,
            text=(
                f"🎉 مبروك! فزت بالمزاد على: {auction.title}\n"
                f"💰 المبلغ المخصوم: ${fmt_money(bid.amount)}\n\n"
                f"📦 <b>بيانات التسليم:</b>\n{delivery}"
            ),
            parse_mode=ParseMode.HTML,
        )
    except Exception as exc:
        logger.warning("تعذر إرسال بيانات التسليم للفائز: %s", exc)


async def _notify_auction_cancelled(context, auction: Auction) -> None:
    if auction.telegram_chat_id and auction.telegram_message_id:
        try:
            await context.bot.edit_message_text(
                chat_id=auction.telegram_chat_id,
                message_id=auction.telegram_message_id,
                text=(
                    f"❌ <b>تم إلغاء المزاد</b>\n"
                    f"لم يصل التفاعل للنصاب المطلوب.\n"
                    f"المنتج: {auction.title}"
                ),
                parse_mode=ParseMode.HTML,
            )
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Periodic finalizer (called from the bot's polling loop)
# ---------------------------------------------------------------------------
async def finalize_due_auctions(context: ContextTypes.DEFAULT_TYPE,
                                flask_app) -> int:
    """Auto-finalize auctions whose end-time passed and notify the owner."""
    with flask_app.app_context():
        from app.extensions import db
        due = Auction.query.filter(
            Auction.status == "active",
            Auction.ends_at <= datetime.utcnow(),
        ).all()
        for auction in due:
            await send_admin_decision_card(context, flask_app, auction)
        db.session.commit()
        return len(due)


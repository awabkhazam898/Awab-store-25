"""
=============================================================
  app/models/admin_staff.py — نموذج المشرفين
  يمثّل بيانات مشرفي بوت تيليجرام وإحصائيات أدائهم
=============================================================
"""

from datetime import datetime
from ..extensions import db


class AdminStaff(db.Model):
    """مشرف بوت تيليجرام — يختلف عن مستخدمي الموقع"""
    __tablename__ = "admin_staff"

    id              = db.Column(db.Integer, primary_key=True)
    telegram_id     = db.Column(db.BigInteger, unique=True, nullable=False, index=True)
    username        = db.Column(db.String(64), nullable=True)
    full_name       = db.Column(db.String(128), nullable=True)
    is_active       = db.Column(db.Boolean, default=True)
    added_at        = db.Column(db.DateTime, default=datetime.utcnow)

    # إحصائيات الأداء (يتم تحديثها تلقائياً)
    total_accepted    = db.Column(db.Integer, default=0)
    total_completed   = db.Column(db.Integer, default=0)
    total_rejected    = db.Column(db.Integer, default=0)
    total_transferred = db.Column(db.Integer, default=0)
    total_failed      = db.Column(db.Integer, default=0)

    # العلاقات
    reward_points = db.relationship("RewardPoint", backref="admin", lazy="dynamic")

    @property
    def display_name(self) -> str:
        if self.username:
            return f"@{self.username}"
        return self.full_name or f"Admin #{self.telegram_id}"

    @property
    def points_this_month(self) -> int:
        from datetime import datetime
        from .rewards import RewardPoint
        now = datetime.utcnow()
        return RewardPoint.query.filter_by(
            admin_id=self.id,
            month=now.month,
            year=now.year,
        ).count()

    def __repr__(self):
        return f"<AdminStaff {self.display_name}>"

"""
=============================================================
  app/models/user.py — نموذج المستخدم
  يمثّل حسابات المستخدمين في المتجر
=============================================================
"""

from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from ..extensions import db


class User(UserMixin, db.Model):
    """نموذج المستخدم — يشمل العملاء والمشرفين"""
    __tablename__ = "users"

    id            = db.Column(db.Integer, primary_key=True)
    username      = db.Column(db.String(64),  unique=True, nullable=False, index=True)
    email         = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    phone         = db.Column(db.String(20),  nullable=True)

    # الرصيد (بالدينار الليبي)
    balance       = db.Column(db.Float, default=0.0, nullable=False)

    # الصلاحيات
    is_admin      = db.Column(db.Boolean, default=False)
    is_active     = db.Column(db.Boolean, default=True)
    is_verified   = db.Column(db.Boolean, default=False)
    is_banned     = db.Column(db.Boolean, default=False)

    # التواريخ
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    last_login    = db.Column(db.DateTime, nullable=True)

    # العلاقات
    orders        = db.relationship("Order",
                                   foreign_keys="Order.user_id",
                                   backref="user", lazy="dynamic")
    top_up_requests = db.relationship("TopUpRequest", backref="user", lazy="dynamic")
    transactions  = db.relationship("Transaction", backref="user", lazy="dynamic")
    audit_logs    = db.relationship("AuditLog",    foreign_keys="AuditLog.target_user_id",
                                    backref="target_user", lazy="dynamic")

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def add_balance(self, amount: float, note: str = "", performed_by: str = "system",
                    reference_id: str = None, transaction_type: str = "credit") -> bool:
        """إضافة رصيد للمستخدم مع تسجيل العملية"""
        from .payment import Transaction, AuditLog
        if reference_id and Transaction.query.filter_by(
                user_id=self.id, reference_id=reference_id, type=transaction_type
        ).first():
            return False
        old_balance = self.balance
        self.balance += amount
        txn = Transaction(
            user_id=self.id,
            amount=amount,
            balance_before=old_balance,
            balance_after=self.balance,
            type=transaction_type,
            note=note,
            reference_id=reference_id,
        )
        db.session.add(txn)
        if performed_by != "system":
            log = AuditLog(
                action="balance_credit",
                target_user_id=self.id,
                data={"amount": amount, "old": old_balance, "new": self.balance, "note": note},
                performed_by=performed_by,
            )
            db.session.add(log)
        return True

    def deduct_balance(self, amount: float, note: str = "") -> bool:
        """خصم رصيد من المستخدم — يعيد True عند النجاح"""
        from .payment import Transaction
        if self.balance < amount:
            return False
        old_balance = self.balance
        self.balance -= amount
        txn = Transaction(
            user_id=self.id,
            amount=-amount,
            balance_before=old_balance,
            balance_after=self.balance,
            type="debit",
            note=note,
        )
        db.session.add(txn)
        return True

    def __repr__(self):
        return f"<User {self.username}>"

"""
=============================================================
  app/models/payment.py — نماذج المدفوعات والمعاملات
  يمثّل طلبات الشحن والمعاملات المالية وسجل التدقيق
=============================================================
"""

import uuid
import json
from datetime import datetime
from ..extensions import db

# طرق الدفع
PAYMENT_METHOD_SMS     = "sms"
PAYMENT_METHOD_BINANCE = "binance"
PAYMENT_METHOD_MANUAL  = "manual"

# حالات طلب الشحن
TOPUP_STATUS_PENDING   = "pending"
TOPUP_STATUS_COMPLETED = "completed"
TOPUP_STATUS_FAILED    = "failed"
TOPUP_STATUS_EXPIRED   = "expired"


class TopUpRequest(db.Model):
    """طلبات شحن الرصيد"""
    __tablename__ = "top_up_requests"

    id             = db.Column(db.Integer, primary_key=True)
    request_id     = db.Column(db.String(32), unique=True, nullable=False,
                                default=lambda: f"TOP-{uuid.uuid4().hex[:8].upper()}",
                                index=True)
    user_id        = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    amount         = db.Column(db.Float, nullable=False)
    method         = db.Column(db.String(32), nullable=False)  # sms | binance | manual
    status         = db.Column(db.String(32), default=TOPUP_STATUS_PENDING)

    # SMS
    sender_phone   = db.Column(db.String(20), nullable=True)
    sms_text       = db.Column(db.Text, nullable=True)
    sms_reference  = db.Column(db.String(64), unique=True, nullable=True, index=True)

    # Binance
    binance_transaction_id = db.Column(db.String(128), unique=True, nullable=True, index=True)
    binance_sender_uid     = db.Column(db.String(64),  nullable=True)
    binance_coin           = db.Column(db.String(16),  nullable=True)
    binance_amount_usd     = db.Column(db.Float,       nullable=True)  # المبلغ المُدخَل من المستخدم

    # التواريخ
    created_at     = db.Column(db.DateTime, default=datetime.utcnow)
    confirmed_at   = db.Column(db.DateTime, nullable=True)
    expires_at     = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f"<TopUpRequest {self.request_id} amount={self.amount} status={self.status}>"


class Transaction(db.Model):
    """سجل جميع المعاملات المالية"""
    __tablename__ = "transactions"
    __table_args__ = (
        db.Index("idx_txn_user_type", "user_id", "type"),
    )

    id             = db.Column(db.Integer, primary_key=True)
    txn_id         = db.Column(db.String(32), unique=True, nullable=False,
                                default=lambda: f"TXN-{uuid.uuid4().hex[:8].upper()}")
    user_id        = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    amount         = db.Column(db.Float, nullable=False)
    balance_before = db.Column(db.Float, nullable=False)
    balance_after  = db.Column(db.Float, nullable=False)
    type           = db.Column(db.String(32), nullable=False)  # credit | debit | refund
    note           = db.Column(db.String(256), nullable=True)
    reference_id   = db.Column(db.String(64), nullable=True)   # order_id أو request_id
    created_at     = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Transaction {self.txn_id} {self.type} {self.amount}>"


class AuditLog(db.Model):
    """سجل تدقيق جميع العمليات الحساسة"""
    __tablename__ = "audit_logs"

    id             = db.Column(db.Integer, primary_key=True)
    action         = db.Column(db.String(64), nullable=False, index=True)
    target_user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    performed_by   = db.Column(db.String(64), nullable=False)  # username أو "system"
    _data          = db.Column("data", db.Text, nullable=True)  # JSON
    ip_address     = db.Column(db.String(45), nullable=True)
    created_at     = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    @property
    def data(self):
        if self._data:
            try:
                return json.loads(self._data)
            except Exception:
                return {}
        return {}

    @data.setter
    def data(self, value):
        self._data = json.dumps(value, ensure_ascii=False) if value else None

    def __init__(self, action, performed_by, target_user_id=None, data=None, ip_address=None):
        self.action = action
        self.performed_by = performed_by
        self.target_user_id = target_user_id
        self.data = data or {}
        self.ip_address = ip_address

    def __repr__(self):
        return f"<AuditLog {self.action} by={self.performed_by}>"

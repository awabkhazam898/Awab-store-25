"""
=============================================================
  app/models/__init__.py — نماذج قاعدة البيانات
=============================================================
"""

from .user         import User
from .product      import Category, Product, ProductField
from .inventory    import InventoryItem
from .order        import Order, OrderItem, OrderStatusLog, OrderFieldValue
from .payment      import TopUpRequest, Transaction, AuditLog
from .admin_staff  import AdminStaff
from .rewards      import RewardPoint, MonthlyReward, PointValueHistory
from .notification import SiteNotification
from .features import (TelegramLink, Auction, AuctionBid, GiftOrder, GroupBuy,
                        GroupBuyParticipant, ProviderSession, NetflixProfile,
                        NetflixDevice, NetflixAccess, NetflixProfileAssignment,
                        DomainEmailAddress, DomainEmailVerificationBatch, DomainEmailEvent)

__all__ = [
    "User",
    "Category", "Product", "ProductField",
    "InventoryItem",
    "Order", "OrderItem", "OrderStatusLog", "OrderFieldValue",
    "TopUpRequest", "Transaction", "AuditLog",
    "AdminStaff",
    "RewardPoint", "MonthlyReward", "PointValueHistory",
    "SiteNotification",
    "TelegramLink", "Auction", "AuctionBid", "GiftOrder", "GroupBuy",
    "GroupBuyParticipant", "ProviderSession", "NetflixProfile", "NetflixDevice", "NetflixAccess",
    "NetflixProfileAssignment", "DomainEmailAddress", "DomainEmailVerificationBatch", "DomainEmailEvent",
]


def init_db(app):
    """تهيئة البيانات الأولية (Seed Data)"""
    from ..extensions import db
    from config import ADMIN_USERNAME, ADMIN_PASSWORD, DEFAULT_POINT_VALUE_USD
    from werkzeug.security import generate_password_hash

    with app.app_context():
        if not User.query.filter_by(username=ADMIN_USERNAME).first():
            admin_user = User(
                username=ADMIN_USERNAME,
                email="admin@awab-store.com.ly",
                password_hash=generate_password_hash(ADMIN_PASSWORD),
                is_admin=True,
                is_verified=True,
                balance=0.0,
            )
            db.session.add(admin_user)

        default_categories = [
            {"name": "بطاقات الهدايا", "slug": "gift-cards",    "icon": "gift",      "sort_order": 1},
            {"name": "الاشتراكات",      "slug": "subscriptions", "icon": "play-circle","sort_order": 2},
            {"name": "حسابات جاهزة",   "slug": "accounts",      "icon": "person",    "sort_order": 3},
            {"name": "خدمات تيليجرام", "slug": "telegram",      "icon": "telegram",  "sort_order": 4},
        ]
        for cat_data in default_categories:
            if not Category.query.filter_by(slug=cat_data["slug"]).first():
                cat = Category(**cat_data)
                db.session.add(cat)

        if not PointValueHistory.query.first():
            pv = PointValueHistory(value_usd=DEFAULT_POINT_VALUE_USD, changed_by="system")
            db.session.add(pv)

        db.session.commit()

"""
=============================================================
  app/models/product.py — نماذج المنتجات والفئات
  يمثّل الفئات والمنتجات وحقول المنتجات الديناميكية
=============================================================
"""

from datetime import datetime
from ..extensions import db


class Category(db.Model):
    """فئات المنتجات"""
    __tablename__ = "categories"

    id         = db.Column(db.Integer, primary_key=True)
    name       = db.Column(db.String(64),  nullable=False)
    slug       = db.Column(db.String(64),  unique=True, nullable=False, index=True)
    icon       = db.Column(db.String(64),  default="box")
    image_url  = db.Column(db.String(256), nullable=True)
    sort_order = db.Column(db.Integer, default=0)
    is_active  = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    products   = db.relationship("Product", backref="category", lazy="dynamic")

    def __repr__(self):
        return f"<Category {self.name}>"


# أنواع المنتجات
PRODUCT_TYPE_GIFT_CARD    = "gift_card"         # بطاقات هدايا (أكواد)
PRODUCT_TYPE_ACCOUNT      = "ready_account"      # حسابات جاهزة
PRODUCT_TYPE_SUBSCRIPTION = "account_subscription"  # اشتراك مرتبط بحساب المستخدم

PRODUCT_TYPES = {
    PRODUCT_TYPE_GIFT_CARD:    "بطاقة هدية",
    PRODUCT_TYPE_ACCOUNT:      "حساب جاهز",
    PRODUCT_TYPE_SUBSCRIPTION: "اشتراك بحساب المستخدم",
}


class Product(db.Model):
    """المنتجات"""
    __tablename__ = "products"

    id           = db.Column(db.Integer, primary_key=True)
    category_id  = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False, index=True)
    name         = db.Column(db.String(128), nullable=False)
    slug         = db.Column(db.String(128), unique=True, nullable=False, index=True)
    description  = db.Column(db.Text, nullable=True)
    image_url    = db.Column(db.String(256), nullable=True)

    # النوع: gift_card | ready_account | account_subscription
    product_type = db.Column(db.String(32), nullable=False, default=PRODUCT_TYPE_GIFT_CARD)

    # الأسعار
    price        = db.Column(db.Float, nullable=False)  # سعر البيع (LYD)
    cost         = db.Column(db.Float, default=0.0)      # تكلفة الشراء

    # الحالة
    is_active    = db.Column(db.Boolean, default=True)
    is_featured  = db.Column(db.Boolean, default=False)
    sort_order   = db.Column(db.Integer, default=0)

    # التواريخ
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at   = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # العلاقات
    fields       = db.relationship("ProductField", backref="product",
                                   lazy="dynamic", order_by="ProductField.sort_order")
    inventory    = db.relationship("InventoryItem", backref="product", lazy="dynamic")
    order_items  = db.relationship("OrderItem", backref="product", lazy="dynamic")

    @property
    def stock_count(self) -> int:
        """عدد العناصر المتاحة في المخزون"""
        from .inventory import InventoryItem
        return InventoryItem.query.filter_by(
            product_id=self.id, is_sold=False
        ).count()

    @property
    def is_in_stock(self) -> bool:
        """هل المنتج متوفر؟"""
        if self.product_type == PRODUCT_TYPE_SUBSCRIPTION:
            return True  # خدمة — لا تحتاج مخزوناً
        return self.stock_count > 0

    @property
    def type_label(self) -> str:
        return PRODUCT_TYPES.get(self.product_type, self.product_type)

    def __repr__(self):
        return f"<Product {self.name}>"


class ProductField(db.Model):
    """الحقول الديناميكية للمنتجات (مطلوبة عند الطلب)"""
    __tablename__ = "product_fields"

    id          = db.Column(db.Integer, primary_key=True)
    product_id  = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)
    name        = db.Column(db.String(64), nullable=False)   # المفتاح الداخلي
    label       = db.Column(db.String(128), nullable=False)  # النص الظاهر للمستخدم
    field_type  = db.Column(db.String(32), default="text")   # text | email | tel | number | textarea
    placeholder = db.Column(db.String(256), nullable=True)
    is_required = db.Column(db.Boolean, default=True)
    sort_order  = db.Column(db.Integer, default=0)

    def __repr__(self):
        return f"<ProductField {self.label}>"

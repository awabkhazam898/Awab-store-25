"""
=============================================================
  app/models/order.py — نماذج الطلبات
  يمثّل الطلبات وعناصرها وسجل تغيير الحالات
=============================================================
"""

import uuid
from datetime import datetime
from ..extensions import db

# حالات الطلب
ORDER_STATUS_PENDING    = "pending"
ORDER_STATUS_ACCEPTED   = "accepted"
ORDER_STATUS_TRANSFERRED= "transferred"
ORDER_STATUS_PROCESSING = "processing"
ORDER_STATUS_COMPLETED  = "completed"
ORDER_STATUS_REJECTED   = "rejected"
ORDER_STATUS_CANCELLED  = "cancelled"
ORDER_STATUS_FAILED     = "failed"

ORDER_STATUSES = {
    ORDER_STATUS_PENDING:     {"label": "قيد المراجعة",  "color": "warning"},
    ORDER_STATUS_ACCEPTED:    {"label": "مقبول",          "color": "info"},
    ORDER_STATUS_TRANSFERRED: {"label": "محوّل",          "color": "secondary"},
    ORDER_STATUS_PROCESSING:  {"label": "جارٍ التنفيذ",  "color": "primary"},
    ORDER_STATUS_COMPLETED:   {"label": "مكتمل",          "color": "success"},
    ORDER_STATUS_REJECTED:    {"label": "مرفوض",          "color": "danger"},
    ORDER_STATUS_CANCELLED:   {"label": "ملغى",           "color": "secondary"},
    ORDER_STATUS_FAILED:      {"label": "فشل",            "color": "danger"},
}


def generate_order_id() -> str:
    """توليد معرّف طلب فريد"""
    return f"AWB-{uuid.uuid4().hex[:8].upper()}"


class Order(db.Model):
    """الطلب الرئيسي"""
    __tablename__ = "orders"

    id              = db.Column(db.Integer, primary_key=True)
    order_number    = db.Column(db.String(32), unique=True, nullable=False,
                                default=generate_order_id, index=True)
    user_id         = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)

    # الإجماليات
    total_amount    = db.Column(db.Float, nullable=False)

    # الحالة
    status          = db.Column(db.String(32), default=ORDER_STATUS_PENDING, index=True)

    # معالجة طلبات account_subscription
    assigned_admin_id   = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    accepted_by_id      = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    completed_by_id     = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    accepted_at         = db.Column(db.DateTime, nullable=True)
    completed_at        = db.Column(db.DateTime, nullable=True)

    # Idempotency Key لمنع التكرار
    idempotency_key = db.Column(db.String(64), unique=True, nullable=True, index=True)

    # معرّف رسالة تيليجرام (للتحديث لاحقاً)
    telegram_message_ids = db.Column(db.Text, nullable=True)  # JSON list

    # ملاحظات
    notes           = db.Column(db.Text, nullable=True)
    reject_reason   = db.Column(db.String(256), nullable=True)

    # التواريخ
    created_at      = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at      = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # العلاقات
    items           = db.relationship("OrderItem",      backref="order", lazy="dynamic",
                                      cascade="all, delete-orphan")
    status_logs     = db.relationship("OrderStatusLog", backref="order", lazy="dynamic",
                                      cascade="all, delete-orphan",
                                      order_by="OrderStatusLog.created_at")

    @property
    def status_info(self) -> dict:
        return ORDER_STATUSES.get(self.status, {"label": self.status, "color": "secondary"})

    @property
    def has_subscription_items(self) -> bool:
        from .product import PRODUCT_TYPE_SUBSCRIPTION
        return any(item.product.product_type == PRODUCT_TYPE_SUBSCRIPTION
                   for item in self.items if item.product)

    def log_status_change(self, old_status: str, new_status: str,
                          admin_id: int = None, note: str = "") -> None:
        """تسجيل تغيير الحالة في السجل"""
        log = OrderStatusLog(
            order_id=self.id,
            old_status=old_status,
            new_status=new_status,
            changed_by_id=admin_id,
            note=note,
        )
        db.session.add(log)

    def __repr__(self):
        return f"<Order {self.order_number} status={self.status}>"


class OrderItem(db.Model):
    """عنصر داخل الطلب"""
    __tablename__ = "order_items"

    id           = db.Column(db.Integer, primary_key=True)
    order_id     = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False, index=True)
    product_id   = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)

    quantity     = db.Column(db.Integer, default=1)
    unit_price   = db.Column(db.Float, nullable=False)
    total_price  = db.Column(db.Float, nullable=False)

    # المنتجات المسلّمة (للبطاقات والحسابات)
    delivered_items = db.Column(db.Text, nullable=True)  # JSON

    def __repr__(self):
        return f"<OrderItem order={self.order_id} product={self.product_id}>"


class OrderFieldValue(db.Model):
    """قيم الحقول الديناميكية المُدخلة من المستخدم عند الطلب"""
    __tablename__ = "order_field_values"

    id         = db.Column(db.Integer, primary_key=True)
    order_id   = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False, index=True)
    field_name = db.Column(db.String(64),  nullable=False)
    field_label= db.Column(db.String(128), nullable=False)
    value      = db.Column(db.Text, nullable=False)

    order = db.relationship("Order", backref=db.backref("field_values", lazy="dynamic"))


class OrderStatusLog(db.Model):
    """سجل تغييرات حالة الطلبات"""
    __tablename__ = "order_status_logs"

    id            = db.Column(db.Integer, primary_key=True)
    order_id      = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False, index=True)
    old_status    = db.Column(db.String(32), nullable=False)
    new_status    = db.Column(db.String(32), nullable=False)
    changed_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    note          = db.Column(db.String(256), nullable=True)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)

    changed_by    = db.relationship("User", foreign_keys=[changed_by_id])

"""
=============================================================
  app/models/notification.py — إشعارات الموقع
  الإشعارات التي يضبطها الادمن وتظهر للمستخدمين كـ Popup
=============================================================
"""

from datetime import datetime
from ..extensions import db

NOTIF_TYPE_INFO    = "info"
NOTIF_TYPE_WARNING = "warning"
NOTIF_TYPE_SUCCESS = "success"
NOTIF_TYPE_DANGER  = "danger"

NOTIF_TYPES = {
    NOTIF_TYPE_INFO:    {"label": "معلومة",  "icon": "ℹ️",  "css": "info"},
    NOTIF_TYPE_WARNING: {"label": "تحذير",   "icon": "⚠️",  "css": "warning"},
    NOTIF_TYPE_SUCCESS: {"label": "نجاح",    "icon": "✅",  "css": "success"},
    NOTIF_TYPE_DANGER:  {"label": "تنبيه",   "icon": "🚨",  "css": "danger"},
}


class SiteNotification(db.Model):
    """إشعارات الموقع — يضبطها الادمن وتظهر للمستخدمين"""
    __tablename__ = "site_notifications"

    id          = db.Column(db.Integer, primary_key=True)
    title       = db.Column(db.String(128), nullable=False)
    message     = db.Column(db.Text, nullable=False)
    notif_type  = db.Column(db.String(32), default=NOTIF_TYPE_INFO)
    starts_at   = db.Column(db.DateTime, nullable=True)    # None = فوري
    expires_at  = db.Column(db.DateTime, nullable=True)    # None = لا تنتهي
    is_active   = db.Column(db.Boolean, default=True)
    created_by  = db.Column(db.String(64), nullable=False, default="admin")
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at  = db.Column(db.DateTime, default=datetime.utcnow,
                            onupdate=datetime.utcnow)

    @classmethod
    def get_active_now(cls):
        """الإشعارات النشطة في الوقت الحالي"""
        now = datetime.utcnow()
        return (
            cls.query
            .filter_by(is_active=True)
            .filter(db.or_(cls.starts_at.is_(None), cls.starts_at <= now))
            .filter(db.or_(cls.expires_at.is_(None), cls.expires_at > now))
            .order_by(cls.created_at.desc())
            .all()
        )

    @property
    def type_info(self) -> dict:
        return NOTIF_TYPES.get(self.notif_type, NOTIF_TYPES[NOTIF_TYPE_INFO])

    @property
    def status_label(self) -> str:
        now = datetime.utcnow()
        if not self.is_active:
            return "معطّل"
        if self.starts_at and self.starts_at > now:
            return "مجدول"
        if self.expires_at and self.expires_at <= now:
            return "منتهي"
        return "نشط"

    @property
    def status_css(self) -> str:
        return {
            "نشط":   "success",
            "مجدول": "warning",
            "منتهي": "secondary",
            "معطّل": "danger",
        }.get(self.status_label, "secondary")

    def to_dict(self) -> dict:
        return {
            "id":       self.id,
            "title":    self.title,
            "message":  self.message,
            "type":     self.notif_type,
            "icon":     self.type_info["icon"],
        }

    def __repr__(self):
        return f"<SiteNotification #{self.id} '{self.title}'>"

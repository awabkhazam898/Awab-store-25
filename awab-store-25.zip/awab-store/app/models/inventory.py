"""
=============================================================
  app/models/inventory.py — نموذج المخزون
  يمثّل الأكواد والحسابات المخزنة
=============================================================
"""

from datetime import datetime
from ..extensions import db


class InventoryItem(db.Model):
    """
    عنصر مخزون واحد:
    - بطاقة هدية: سطر واحد = كود واحد
    - حساب جاهز: سجل واحد = حساب كامل (Email + Password + PIN + Notes)
    """
    __tablename__ = "inventory_items"
    __table_args__ = (
        db.Index("idx_inventory_product_sold", "product_id", "is_sold"),
    )

    id          = db.Column(db.Integer, primary_key=True)
    product_id  = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)

    # بطاقة هدية: الكود مباشرة
    code        = db.Column(db.Text, nullable=True)

    # حساب جاهز: بيانات متعددة
    email       = db.Column(db.String(256), nullable=True)
    password    = db.Column(db.String(256), nullable=True)
    pin         = db.Column(db.String(64),  nullable=True)
    notes       = db.Column(db.Text, nullable=True)

    # الحالة
    is_sold     = db.Column(db.Boolean, default=False, index=True)
    sold_at     = db.Column(db.DateTime, nullable=True)
    order_id    = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=True)

    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def delivery_text(self) -> str:
        """النص الذي يُسلَّم للمستخدم"""
        from .product import PRODUCT_TYPE_ACCOUNT
        parts = []
        if self.code:
            parts.append(f"الكود: {self.code}")
        if self.email:
            parts.append(f"البريد الإلكتروني: {self.email}")
        if self.password:
            parts.append(f"كلمة المرور: {self.password}")
        if self.pin:
            parts.append(f"PIN: {self.pin}")
        if self.notes:
            parts.append(f"ملاحظات: {self.notes}")
        return "\n".join(parts) if parts else "—"

    def mark_sold(self, order_id: int) -> None:
        """تحديد العنصر كمباع"""
        self.is_sold  = True
        self.sold_at  = datetime.utcnow()
        self.order_id = order_id

    def __repr__(self):
        return f"<InventoryItem #{self.id} product={self.product_id} sold={self.is_sold}>"

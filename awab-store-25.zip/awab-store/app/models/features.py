"""Models for auctions, gifting, group buys and provider-backed delivery."""
from datetime import datetime
from ..extensions import db


class TelegramLink(db.Model):
    __tablename__ = "telegram_links"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)
    telegram_id = db.Column(db.BigInteger, nullable=True, unique=True, index=True)
    username = db.Column(db.String(64), nullable=True)
    token_hash = db.Column(db.String(128), nullable=True)
    token_expires_at = db.Column(db.DateTime, nullable=True)
    verified_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    user = db.relationship("User", backref=db.backref("telegram_link", uselist=False))


class Auction(db.Model):
    __tablename__ = "auctions"
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(160), nullable=False)
    description = db.Column(db.Text, nullable=True)
    start_price = db.Column(db.Float, nullable=False)
    bid_step = db.Column(db.Float, nullable=False)
    ends_at = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), default="active", nullable=False, index=True)
    winner_user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    winning_amount = db.Column(db.Float, nullable=True)
    delivery_text = db.Column(db.Text, nullable=True)
    telegram_chat_id = db.Column(db.BigInteger, nullable=True)
    telegram_message_id = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    bids = db.relationship("AuctionBid", backref="auction", lazy="dynamic",
                           cascade="all, delete-orphan", order_by="AuctionBid.amount.desc()")
    winner = db.relationship("User", foreign_keys=[winner_user_id])


class AuctionBid(db.Model):
    __tablename__ = "auction_bids"
    id = db.Column(db.Integer, primary_key=True)
    auction_id = db.Column(db.Integer, db.ForeignKey("auctions.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    amount = db.Column(db.Float, nullable=False)
    telegram_id = db.Column(db.BigInteger, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    user = db.relationship("User")


class GiftOrder(db.Model):
    __tablename__ = "gift_orders"
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    recipient = db.Column(db.String(160), nullable=False)
    channel = db.Column(db.String(20), nullable=False, default="telegram")
    message = db.Column(db.Text, nullable=True)
    anonymous = db.Column(db.Boolean, default=True, nullable=False)
    status = db.Column(db.String(20), default="pending", nullable=False)
    delivery_text = db.Column(db.Text, nullable=True)
    delivered_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    product = db.relationship("Product")


class GroupBuy(db.Model):
    __tablename__ = "group_buys"
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    target_count = db.Column(db.Integer, nullable=False)
    deal_price = db.Column(db.Float, nullable=False)
    ends_at = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), default="open", nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    participants = db.relationship("GroupBuyParticipant", backref="group_buy", lazy="dynamic",
                                   cascade="all, delete-orphan")
    product = db.relationship("Product")


class GroupBuyParticipant(db.Model):
    __tablename__ = "group_buy_participants"
    id = db.Column(db.Integer, primary_key=True)
    group_buy_id = db.Column(db.Integer, db.ForeignKey("group_buys.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    amount_paid = db.Column(db.Float, nullable=False, default=0)
    status = db.Column(db.String(20), nullable=False, default="joined")
    delivery_text = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    user = db.relationship("User")
    __table_args__ = (db.UniqueConstraint("group_buy_id", "user_id", name="uq_group_buy_user"),)


class ProviderSession(db.Model):
    """Encrypted/provider session metadata; raw credentials are never returned by APIs."""
    __tablename__ = "provider_sessions"
    id = db.Column(db.Integer, primary_key=True)
    provider = db.Column(db.String(32), unique=True, nullable=False)
    encrypted_value = db.Column(db.Text, nullable=True)
    expires_at = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), default="not_configured", nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    @property
    def is_expired(self) -> bool:
        """True if an expiration is set and has passed."""
        return bool(self.expires_at and self.expires_at <= datetime.utcnow())

    @property
    def is_usable(self) -> bool:
        """A provider session is usable only when configured and not expired."""
        return (
            self.status == "configured"
            and bool(self.encrypted_value)
            and not self.is_expired
        )

    def refresh_status(self) -> None:
        """Re-evaluate status against expiration; sets 'expired' when needed."""
        if self.is_expired and self.status == "configured":
            self.status = "expired"
        elif self.status == "expired" and not self.is_expired:
            self.status = "configured"


class NetflixProfile(db.Model):
    __tablename__ = "netflix_profiles"
    id = db.Column(db.Integer, primary_key=True)
    account_label = db.Column(db.String(120), nullable=False)
    profile_number = db.Column(db.Integer, nullable=False)
    pin_hash = db.Column(db.String(256), nullable=True)
    expiration_date = db.Column(db.Date, nullable=True)
    status = db.Column(db.String(20), default="active", nullable=False)
    reset_count = db.Column(db.Integer, default=0, nullable=False)
    reset_window_started = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    __table_args__ = (db.UniqueConstraint("account_label", "profile_number", name="uq_netflix_profile"),)


class NetflixDevice(db.Model):
    __tablename__ = "netflix_devices"
    id = db.Column(db.Integer, primary_key=True)
    profile_id = db.Column(db.Integer, db.ForeignKey("netflix_profiles.id"), nullable=False)
    assignment_id = db.Column(db.Integer, db.ForeignKey("netflix_profile_assignments.id"), nullable=True, index=True)
    # Only a one-way digest is retained; the browser/device fingerprint is never recoverable.
    fingerprint = db.Column(db.String(64), nullable=False)
    ip_address = db.Column(db.String(64), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    profile = db.relationship("NetflixProfile", backref=db.backref("devices", lazy="dynamic"))
    assignment = db.relationship("NetflixProfileAssignment", backref=db.backref("devices", lazy="dynamic"))
    __table_args__ = (db.UniqueConstraint("assignment_id", "fingerprint", name="uq_assignment_device"),)


class NetflixAccess(db.Model):
    """A purchased profile assignment. The signed access link never contains credentials."""
    __tablename__ = "netflix_accesses"
    id = db.Column(db.Integer, primary_key=True)
    profile_id = db.Column(db.Integer, db.ForeignKey("netflix_profiles.id"), nullable=False, unique=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    max_devices = db.Column(db.Integer, nullable=False, default=1)
    expires_at = db.Column(db.DateTime, nullable=True)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    profile = db.relationship("NetflixProfile", backref=db.backref("access", uselist=False))
    user = db.relationship("User", backref=db.backref("netflix_accesses", lazy="dynamic"))

    @property
    def registered_device_count(self):
        return NetflixDevice.query.filter_by(profile_id=self.profile_id, assignment_id=None).count()

    @property
    def device_reset_count(self):
        return self.profile.reset_count


class NetflixProfileAssignment(db.Model):
    """Historical profile allocation; credentials are deliberately absent."""
    __tablename__ = "netflix_profile_assignments"
    id = db.Column(db.Integer, primary_key=True)
    profile_id = db.Column(db.Integer, db.ForeignKey("netflix_profiles.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    starts_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=True, index=True)
    ended_at = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), default="active", nullable=False, index=True)
    max_devices = db.Column(db.Integer, default=1, nullable=False)
    reset_count = db.Column(db.Integer, default=0, nullable=False)
    reset_window_started = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    profile = db.relationship("NetflixProfile", backref=db.backref("assignments", lazy="dynamic"))
    user = db.relationship("User")
    __table_args__ = (
        db.Index("uq_active_netflix_profile_assignment", "profile_id", unique=True,
                 sqlite_where=db.text("status = 'active'"),
                 postgresql_where=db.text("status = 'active'")),
    )

    @property
    def registered_device_count(self):
        return self.devices.count()

    @property
    def device_reset_count(self):
        return self.reset_count


class DomainEmailAddress(db.Model):
    __tablename__ = "domain_email_addresses"
    id = db.Column(db.Integer, primary_key=True)
    address = db.Column(db.String(254), nullable=False, unique=True, index=True)
    status = db.Column(db.String(20), default="generated", nullable=False, index=True)
    batch_id = db.Column(db.String(64), nullable=True, index=True)
    last_tested_at = db.Column(db.DateTime, nullable=True)
    verified_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class DomainEmailVerificationBatch(db.Model):
    __tablename__ = "domain_email_verification_batches"
    id = db.Column(db.Integer, primary_key=True)
    batch_id = db.Column(db.String(64), nullable=False, unique=True, index=True)
    requested_count = db.Column(db.Integer, nullable=False, default=10)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class DomainEmailEvent(db.Model):
    __tablename__ = "domain_email_events"
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.String(160), nullable=False, unique=True, index=True)
    address = db.Column(db.String(254), nullable=False, index=True)
    event_type = db.Column(db.String(40), nullable=False)
    received_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
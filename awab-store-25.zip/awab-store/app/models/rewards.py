"""
=============================================================
  app/models/rewards.py — نظام النقاط والمكافآت
  يمثّل نقاط المشرفين والمكافآت الشهرية وتاريخ قيم النقاط
=============================================================
"""

from datetime import datetime
from ..extensions import db


class RewardPoint(db.Model):
    """نقطة مكافأة لمشرف — نقطة واحدة لكل طلب مكتمل"""
    __tablename__ = "reward_points"
    __table_args__ = (
        db.UniqueConstraint("order_id", name="uq_reward_per_order"),
        db.Index("idx_reward_admin_month", "admin_id", "month", "year"),
    )

    id                    = db.Column(db.Integer, primary_key=True)
    admin_id              = db.Column(db.Integer, db.ForeignKey("admin_staff.id"),
                                      nullable=False, index=True)
    order_id              = db.Column(db.Integer, db.ForeignKey("orders.id"),
                                      nullable=True)   # null للتعديلات اليدوية
    month                 = db.Column(db.Integer, nullable=False)
    year                  = db.Column(db.Integer, nullable=False)
    reward_value_at_award = db.Column(db.Float,   nullable=False)  # قيمة النقطة وقت المنح
    awarded_at            = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def points(self):
        """توافق مع القوالب/التقارير القديمة: كل سجل يمثل نقطة واحدة."""
        return 1

    @property
    def source(self):
        return "manual" if self.is_manual_adjustment else "order_complete"

    # تعديل يدوي
    is_manual_adjustment  = db.Column(db.Boolean, default=False)
    manual_reason         = db.Column(db.String(256), nullable=True)
    adjusted_by           = db.Column(db.String(64),  nullable=True)  # معرّف المالك

    order = db.relationship("Order", foreign_keys=[order_id])

    def __repr__(self):
        return f"<RewardPoint admin={self.admin_id} order={self.order_id}>"


class MonthlyReward(db.Model):
    """سجل المكافآت الشهرية المغلقة"""
    __tablename__ = "monthly_rewards"
    __table_args__ = (
        db.UniqueConstraint("admin_id", "month", "year", name="uq_monthly_admin"),
    )

    id               = db.Column(db.Integer, primary_key=True)
    admin_id         = db.Column(db.Integer, db.ForeignKey("admin_staff.id"), nullable=False)
    month            = db.Column(db.Integer, nullable=False)
    year             = db.Column(db.Integer, nullable=False)
    total_points     = db.Column(db.Integer, default=0)
    total_value_usd  = db.Column(db.Float,   default=0.0)
    point_value_usd  = db.Column(db.Float,   nullable=False)  # القيمة وقت الإغلاق
    is_closed        = db.Column(db.Boolean, default=False)
    closed_at        = db.Column(db.DateTime, nullable=True)
    closed_by        = db.Column(db.String(64), nullable=True)

    admin = db.relationship("AdminStaff", backref=db.backref("monthly_rewards", lazy="dynamic"))

    def __repr__(self):
        return f"<MonthlyReward admin={self.admin_id} {self.month}/{self.year}>"


class PointValueHistory(db.Model):
    """تاريخ قيم النقاط — يُحفظ وقت كل تغيير"""
    __tablename__ = "point_value_history"

    id          = db.Column(db.Integer, primary_key=True)
    value_usd   = db.Column(db.Float, nullable=False)
    changed_by  = db.Column(db.String(64), nullable=False)
    changed_at  = db.Column(db.DateTime, default=datetime.utcnow)

    @classmethod
    def current_value(cls) -> float:
        """الحصول على قيمة النقطة الحالية"""
        from config import DEFAULT_POINT_VALUE_USD
        latest = cls.query.order_by(cls.changed_at.desc()).first()
        return latest.value_usd if latest else DEFAULT_POINT_VALUE_USD

    def __repr__(self):
        return f"<PointValueHistory ${self.value_usd} by={self.changed_by}>"

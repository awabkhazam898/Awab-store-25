/**
 * ═══════════════════════════════════════════════════════
 *   Awab Store — Main JavaScript
 *   التفاعلات الرئيسية للمتجر
 * ═══════════════════════════════════════════════════════
 */

'use strict';

/* ─── Navbar scroll effect ─── */
(function () {
  const navbar = document.querySelector('.navbar-glass');
  if (!navbar) return;
  const onScroll = () => navbar.classList.toggle('scrolled', window.scrollY > 20);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();

/* ─── Theme toggle ─── */
(function () {
  const toggleBtn = document.getElementById('themeToggle');
  if (!toggleBtn) return;
  const saved = localStorage.getItem('awab-theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);
  toggleBtn.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('awab-theme', next);
    toggleBtn.querySelector('i').className = next === 'dark'
      ? 'bi bi-moon-stars-fill'
      : 'bi bi-sun-fill';
  });
  toggleBtn.querySelector('i').className = saved === 'dark'
    ? 'bi bi-moon-stars-fill'
    : 'bi bi-sun-fill';
})();

/* ─── Auto-dismiss alerts ─── */
document.querySelectorAll('.alert-auto-dismiss').forEach(el => {
  setTimeout(() => {
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    el.style.opacity    = '0';
    el.style.transform  = 'translateY(-10px)';
    setTimeout(() => el.remove(), 500);
  }, 4000);
});

/* ─── Animate on scroll ─── */
(function () {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.style.animationPlayState = 'running';
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.animate-fade-in-up, .animate-fade-in').forEach(el => {
    el.style.animationPlayState = 'paused';
    observer.observe(el);
  });
})();

/* ─── Quantity selector ─── */
document.querySelectorAll('.qty-minus, .qty-plus').forEach(btn => {
  btn.addEventListener('click', () => {
    const input = btn.closest('.qty-wrapper').querySelector('input[type="number"]');
    let val = parseInt(input.value) || 1;
    val += btn.classList.contains('qty-plus') ? 1 : -1;
    input.value = Math.max(1, Math.min(val, parseInt(input.max) || 99));
  });
});

/* ─── Cart preview ripple effect ─── */
document.querySelectorAll('.btn-primary').forEach(btn => {
  btn.addEventListener('click', function (e) {
    const circle = document.createElement('span');
    circle.className = 'ripple-effect';
    const rect = this.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    circle.style.cssText = `
      width: ${size}px; height: ${size}px;
      left: ${e.clientX - rect.left - size / 2}px;
      top: ${e.clientY - rect.top - size / 2}px;
    `;
    this.appendChild(circle);
    setTimeout(() => circle.remove(), 600);
  });
});

/* ─── Product image fallback ─── */
document.querySelectorAll('.product-card-img').forEach(img => {
  img.addEventListener('error', function () {
    this.src = '/static/img/product-placeholder.svg';
  });
});

/* ─── Countdown timer for top-up requests ─── */
const countdownEls = document.querySelectorAll('[data-countdown]');
countdownEls.forEach(el => {
  const target = new Date(el.dataset.countdown).getTime();
  const timer = setInterval(() => {
    const diff = target - Date.now();
    if (diff <= 0) {
      el.textContent = 'انتهت المهلة';
      el.classList.add('text-danger');
      clearInterval(timer);
      return;
    }
    const m = Math.floor(diff / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    el.textContent = `${m}:${String(s).padStart(2, '0')}`;
  }, 1000);
});

/* ─── Smooth page transition ─── */
document.querySelectorAll('a:not([target="_blank"]):not([href^="#"]):not([href^="mailto"])').forEach(a => {
  a.addEventListener('click', function (e) {
    const href = this.getAttribute('href');
    if (!href || href.startsWith('javascript') || href === '#') return;
    // minimal transition — just fade out
    document.body.style.transition = 'opacity 0.15s ease';
    document.body.style.opacity    = '0';
  });
});

window.addEventListener('pageshow', () => {
  document.body.style.opacity = '1';
});

console.log('%c Awab Store v1.0.0 ', 'background: #0066ff; color: #fff; font-weight: bold; border-radius: 4px; padding: 4px 8px;');

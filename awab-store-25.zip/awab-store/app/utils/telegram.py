"""
=============================================================
  app/utils/telegram.py — إرسال إشعارات تيليجرام
  إرسال الطلبات إلى الإداريين وإلى مجموعة السجلات
  مع أزرار Inline لقبول / رفض / تحويل / إتمام
=============================================================
"""

import asyncio
import json
from config import (TELEGRAM_BOT_TOKEN, ADMIN_TELEGRAM_IDS,
                    ORDERS_LOG_GROUP_ID, OWNER_TELEGRAM_ID)


def _run_async(coro):
    """تشغيل دالة async بشكل متزامن"""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import threading
            result = [None]
            exc    = [None]
            def _run():
                try:
                    result[0] = asyncio.run(coro)
                except Exception as e:
                    exc[0] = e
            t = threading.Thread(target=_run)
            t.start()
            t.join(timeout=10)
            if exc[0]:
                raise exc[0]
            return result[0]
        else:
            return loop.run_until_complete(coro)
    except Exception:
        return asyncio.run(coro)


def _order_inline_keyboard(order_id: int):
    """بناء لوحة مفاتيح Inline للطلب الجديد"""
    try:
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ قبول",  callback_data=f"accept_{order_id}"),
                InlineKeyboardButton("❌ رفض",   callback_data=f"reject_{order_id}"),
            ],
            [
                InlineKeyboardButton("🔄 تحويل", callback_data=f"transfer_{order_id}"),
            ],
        ])
    except Exception:
        return None


async def _send_message(chat_id: int, text: str, reply_markup=None) -> dict:
    """إرسال رسالة تيليجرام"""
    try:
        from telegram import Bot
        from telegram.constants import ParseMode
        bot = Bot(token=TELEGRAM_BOT_TOKEN)
        msg = await bot.send_message(
            chat_id=chat_id,
            text=text,
            parse_mode=ParseMode.HTML,
            reply_markup=reply_markup,
        )
        return {"ok": True, "message_id": msg.message_id}
    except Exception as e:
        return {"ok": False, "error": str(e)}


async def _edit_message(chat_id: int, message_id: int, text: str, reply_markup=None) -> dict:
    """تعديل رسالة تيليجرام موجودة"""
    try:
        from telegram import Bot
        from telegram.constants import ParseMode
        bot = Bot(token=TELEGRAM_BOT_TOKEN)
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=text,
            parse_mode=ParseMode.HTML,
            reply_markup=reply_markup,
        )
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def format_order_message(order) -> str:
    """تنسيق رسالة الطلب"""
    from ..models.order import ORDER_STATUSES
    user = order.user
    items_text = ""
    for item in order.items.all():
        items_text += f"• {item.product.name} × {item.quantity} = {item.total_price:.2f} LYD\n"

    fields_text = ""
    for fv in order.field_values.all():
        fields_text += f"• {fv.field_label}: <code>{fv.value}</code>\n"

    status_info = ORDER_STATUSES.get(order.status, {})
    return (
        f"🆕 <b>طلب اشتراك جديد</b>\n"
        f"{'━' * 25}\n"
        f"🆔 <b>رقم الطلب:</b> <code>{order.order_number}</code>\n"
        f"👤 <b>المستخدم:</b> {user.username}\n"
        f"🆔 <b>User ID:</b> <code>{user.id}</code>\n"
        f"\n<b>📦 المنتجات:</b>\n{items_text}"
        + (f"\n<b>📋 بيانات الحساب:</b>\n{fields_text}" if fields_text else "")
        + f"\n💰 <b>الإجمالي:</b> {order.total_amount:.2f} LYD\n"
        f"🕒 <b>وقت الطلب:</b> {order.created_at.strftime('%Y-%m-%d %H:%M')}\n"
        f"📌 <b>الحالة:</b> ⏳ {status_info.get('label', order.status)}"
    )


def notify_admins_new_order(order) -> None:
    """إرسال إشعار طلب جديد إلى جميع الإداريين مع أزرار الإجراءات"""
    if not TELEGRAM_BOT_TOKEN or TELEGRAM_BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        return

    text     = format_order_message(order)
    keyboard = _order_inline_keyboard(order.id)

    # قائمة من يستقبل الإشعار: ADMIN_TELEGRAM_IDS + المالك
    recipients = set(ADMIN_TELEGRAM_IDS)
    if OWNER_TELEGRAM_ID:
        recipients.add(OWNER_TELEGRAM_ID)

    message_ids = []
    for admin_id in recipients:
        result = _run_async(_send_message(admin_id, text, reply_markup=keyboard))
        if result and result.get("ok"):
            message_ids.append({"admin_id": admin_id, "message_id": result["message_id"]})

    # إرسال إلى مجموعة السجلات (بدون أزرار)
    if ORDERS_LOG_GROUP_ID:
        _run_async(_send_message(
            ORDERS_LOG_GROUP_ID,
            f"📝 <b>طلب جديد</b>\n{text}",
        ))

    # حفظ معرّفات الرسائل للتحديث لاحقاً
    if message_ids:
        order.telegram_message_ids = json.dumps(message_ids)


def notify_order_status_change(order, old_status: str, note: str = "",
                                admin_name: str = "النظام") -> None:
    """إرسال إشعار تغيير حالة الطلب إلى مجموعة السجلات"""
    if not TELEGRAM_BOT_TOKEN or TELEGRAM_BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        return

    from ..models.order import ORDER_STATUSES
    old_label = ORDER_STATUSES.get(old_status, {}).get("label", old_status)
    new_label = ORDER_STATUSES.get(order.status, {}).get("label", order.status)

    text = (
        f"🔄 <b>تحديث حالة الطلب</b>\n"
        f"{'━' * 25}\n"
        f"🆔 <b>رقم الطلب:</b> <code>{order.order_number}</code>\n"
        f"👤 <b>العميل:</b> {order.user.username}\n"
        f"📌 <b>الحالة:</b> {old_label} ➜ {new_label}\n"
        f"👮 <b>بواسطة:</b> {admin_name}\n"
    )
    if note:
        text += f"📝 <b>ملاحظة:</b> {note}\n"

    if ORDERS_LOG_GROUP_ID:
        _run_async(_send_message(ORDERS_LOG_GROUP_ID, text))


def notify_user_order_update(order, message: str) -> None:
    """إشعار العميل بتحديث طلبه عبر التيليجرام إذا كان لديه معرّف"""
    if not TELEGRAM_BOT_TOKEN or TELEGRAM_BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        return
    user = order.user
    telegram_id = getattr(user, "telegram_id", None)
    if not telegram_id:
        return
    _run_async(_send_message(int(telegram_id), message))

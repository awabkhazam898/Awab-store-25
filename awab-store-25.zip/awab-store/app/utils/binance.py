"""
=============================================================
  app/utils/binance.py — التحقق من مدفوعات Binance Pay
  يتحقق من Order ID والمبلغ عبر Binance API الرسمية
=============================================================
"""

import hashlib
import hmac
import time
import json
import urllib.request
import urllib.parse
import urllib.error
from dataclasses import dataclass
from typing import Optional


@dataclass
class BinanceVerifyResult:
    success: bool
    verified: bool          # هل المعاملة مؤكدة ومطابقة؟
    error: Optional[str]    # رسالة الخطأ إن وُجدت
    order_status: Optional[str] = None
    order_amount: Optional[float] = None
    currency: Optional[str] = None
    raw: Optional[dict] = None


def _sign(secret: str, query_string: str) -> str:
    """توليد HMAC-SHA256 signature"""
    return hmac.new(
        secret.encode("utf-8"),
        query_string.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def verify_binance_pay_order(
    order_id: str,
    expected_amount: float,
    expected_currency: str = "USDT",
    tolerance: float = 0.01,
) -> BinanceVerifyResult:
    """
    يتحقق من معاملة Binance Pay عبر Order ID.

    المعاملات:
        order_id          — رقم الطلب من Binance
        expected_amount   — المبلغ المتوقع (USD/USDT)
        expected_currency — العملة المتوقعة (USDT افتراضياً)
        tolerance         — هامش الخطأ المقبول في المبلغ

    الإرجاع:
        BinanceVerifyResult مع verified=True إن كانت المعاملة صحيحة
    """
    from config import BINANCE_API_KEY, BINANCE_API_SECRET
    try:
        from binance.client import Client
    except Exception:
        return BinanceVerifyResult(
            success=False,
            verified=False,
            error="مكتبة Binance غير مثبتة أو لا يمكن استيرادها.",
        )

    if not BINANCE_API_KEY or not BINANCE_API_SECRET:
        return BinanceVerifyResult(
            success=False,
            verified=False,
            error="مفاتيح Binance API غير مضبوطة. يرجى التواصل مع الإدارة.",
        )

    try:
        client = Client(BINANCE_API_KEY, BINANCE_API_SECRET)
        res = client.get_pay_trade_history()
        records = res.get("data", [])

        if not records:
            return BinanceVerifyResult(
                success=True,
                verified=False,
                error="لم يتم العثور على أي معاملات Binance Pay حديثة.",
                raw=res,
            )

        user_order_id_clean = str(order_id).strip()

        for item in records:
            tx_order_id = str(item.get("orderId", "")).strip()
            tx_id = str(item.get("transactionId", "")).strip()
            status = str(item.get("status", "")).upper()
            try:
                amount = float(item.get("amount", 0))
            except Exception:
                amount = 0.0
            order_type = str(item.get("orderType", "")).upper()

            if user_order_id_clean in [tx_order_id, tx_id]:
                # 1. Direction Check
                if "PAY" in order_type and "RECEIVE" not in order_type and amount < 0:
                    return BinanceVerifyResult(
                        success=True,
                        verified=False,
                        error="المعاملة المدخلة هي عملية سحب وليست إيداع للمتجر.",
                        raw=item,
                    )

                # 2. Status Check
                if status not in ["SUCCESS", "PAID", "COMPLETED"]:
                    return BinanceVerifyResult(
                        success=True,
                        verified=False,
                        error=f"حالة المعاملة غير مكتملة ({status}).",
                        order_status=status,
                        raw=item,
                    )

                # 3. Amount Check
                paid_amount = abs(amount)
                if paid_amount + tolerance < float(expected_amount):
                    return BinanceVerifyResult(
                        success=True,
                        verified=False,
                        error=f"المبلغ المدفوع ({paid_amount}) أقل من المطلوب ({expected_amount}).",
                        order_amount=paid_amount,
                        currency=item.get("currency", "USDT"),
                        raw=item,
                    )

                # Success
                return BinanceVerifyResult(
                    success=True,
                    verified=True,
                    error=None,
                    order_status=status,
                    order_amount=paid_amount,
                    currency=item.get("currency", "USDT"),
                    raw=item,
                )

        return BinanceVerifyResult(
            success=True,
            verified=False,
            error="لم يتم العثور على معرف المعاملة في سجل الدفع.",
            raw=res,
        )

    except Exception as e:
        return BinanceVerifyResult(
            success=False,
            verified=False,
            error=f"حدث خطأ أثناء الاتصال بـ Binance API: {str(e)}",
        )


def verify_binance_payment(user_order_id: str, expected_amount: float) -> dict:
    """
    Compatibility wrapper implementing the exact tested logic returning a dict.

    Returns a dict with keys: success, message, amount_paid, currency, transaction_id
    """
    import config
    try:
        from binance.client import Client
    except Exception:
        return {"success": False, "message": "مكتبة Binance غير مثبتة أو لا يمكن استيرادها."}

    try:
        client = Client(config.BINANCE_API_KEY, config.BINANCE_API_SECRET)
        res = client.get_pay_trade_history()
        records = res.get('data', [])

        if not records:
            return {"success": False, "message": "لم يتم العثور على أي معاملات Binance Pay حديثة."}

        user_order_id_clean = str(user_order_id).strip()

        for item in records:
            tx_order_id = str(item.get('orderId', '')).strip()
            tx_id = str(item.get('transactionId', '')).strip()
            status = str(item.get('status', '')).upper()
            try:
                amount = float(item.get('amount', 0))
            except Exception:
                amount = 0.0
            order_type = str(item.get('orderType', '')).upper()

            # Check if user submitted ID matches orderId or transactionId
            if user_order_id_clean in [tx_order_id, tx_id]:
                # 1. Direction Check: Ensure it's a deposit/receive (positive amount or RECEIVE type)
                if "PAY" in order_type and "RECEIVE" not in order_type and amount < 0:
                    return {"success": False, "message": "المعاملة المدخلة هي عملية سحب وليست إيداع للمتجر."}

                # 2. Status Check
                if status not in ['SUCCESS', 'PAID', 'COMPLETED']:
                    return {"success": False, "message": f"حالة المعاملة غير مكتملة ({status})."}

                # 3. Amount Check
                paid_amount = abs(amount)
                if paid_amount < float(expected_amount):
                    return {"success": False, "message": f"المبلغ المدفوع ({paid_amount}) أقل من المطلوب ({expected_amount})."}

                # ✅ Success
                return {
                    "success": True,
                    "message": "تم تأكيد الدفع بنجاح!",
                    "amount_paid": paid_amount,
                    "currency": item.get('currency', 'USDT'),
                    "transaction_id": tx_id or tx_order_id,
                }

        return {"success": False, "message": "لم يتم العثور على معرف المعاملة في سجل الدفع."}

    except Exception as e:
        return {"success": False, "message": f"حدث خطأ أثناء الاتصال بـ Binance API: {str(e)}"}

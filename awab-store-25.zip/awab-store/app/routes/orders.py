"""
=============================================================
  app/routes/orders.py — مسارات عرض الطلبات
=============================================================
"""

import json
from flask import Blueprint, render_template, redirect, url_for, abort
from flask_login import login_required, current_user
from ..models.order import Order

orders_bp = Blueprint("orders", __name__)


@orders_bp.route("/")
@orders_bp.route("")
@login_required
def list_orders():
    """قائمة طلبات المستخدم الحالي"""
    orders = (Order.query
              .filter_by(user_id=current_user.id)
              .order_by(Order.created_at.desc())
              .all())
    return render_template("orders/list.html", orders=orders)


@orders_bp.route("/<order_number>")
@login_required
def detail(order_number):
    """تفاصيل طلب واحد"""
    order = Order.query.filter_by(order_number=order_number).first_or_404()
    if order.user_id != current_user.id and not current_user.is_admin:
        abort(403)

    items = order.items.all()
    for item in items:
        if item.delivered_items:
            try:
                item._delivered_list = json.loads(item.delivered_items)
            except Exception:
                item._delivered_list = [item.delivered_items]
        else:
            item._delivered_list = []

    field_values = order.field_values.all()
    status_logs  = order.status_logs.all()
    return render_template("orders/detail.html",
                           order=order,
                           items=items,
                           field_values=field_values,
                           status_logs=status_logs)

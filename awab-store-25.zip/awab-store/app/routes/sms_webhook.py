"""
=============================================================
  app/routes/sms_webhook.py — Webhook استقبال رسائل SMS
  POST /sms/inbound — يستقبل ويعالج رسائل SMS تلقائياً
=============================================================
"""

import hmac
import hashlib
import logging
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, current_app
from ..extensions import db, csrf
from ..models.payment import (TopUpRequest,
                               PAYMENT_METHOD_SMS, TOPUP_STATUS_PENDING, TOPUP_STATUS_COMPLETED)
from ..models.user import User
from config import WEBHOOK_SECRET, LIBYANA_VERIFICATION_WINDOW, ALMADAR_VERIFICATION_WINDOW

sms_bp = Blueprint("sms", __name__)
logger = logging.getLogger("sms_webhook")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.FileHandler("sms_webhook.log", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(handler)


@sms_bp.route("/inbound", methods=["POST"])
@csrf.exempt
def inbound():
    """استقبال رسالة SMS واردة من SMS Forwarder"""

    logger.info("SMS webhook POST received path=/sms/inbound from=%s payload=%s", request.remote_addr, request.get_json(silent=True))

    # التحقق من الـ Webhook Secret
    secret = request.headers.get("X-Webhook-Secret", "")
    if not hmac.compare_digest(secret, WEBHOOK_SECRET):
        return jsonify({"error": "Unauthorized"}), 401

    data = request.get_json(silent=True) or {}
    sender  = data.get("sender", "").strip()
    message = data.get("message", "").strip()
    amount  = data.get("amount")       # يُرسل مُعالَجاً من Forwarder
    ref_id  = data.get("ref_id", "")   # مرجع العملية الفريد

    if not all([sender, message, amount, ref_id]):
        return jsonify({"error": "Missing fields"}), 400

    # منع تكرار المعالجة
    if TopUpRequest.query.filter_by(sms_reference=ref_id).first():
        return jsonify({"status": "duplicate"}), 200

    # البحث عن طلب شحن مطابق
    now = datetime.utcnow()
    window = timedelta(seconds=LIBYANA_VERIFICATION_WINDOW)

    pending = (TopUpRequest.query
               .filter_by(status=TOPUP_STATUS_PENDING, method=PAYMENT_METHOD_SMS)
               .filter(TopUpRequest.amount == float(amount))
               .filter(TopUpRequest.created_at >= now - window)
               .order_by(TopUpRequest.created_at.desc())
               .first())

    if not pending:
        return jsonify({"status": "no_matching_request"}), 200

    # تحديث الطلب
    pending.status       = TOPUP_STATUS_COMPLETED
    pending.sender_phone = sender
    pending.sms_text     = message
    pending.sms_reference= ref_id
    pending.confirmed_at = now

    # إضافة الرصيد للمستخدم
    user = User.query.get(pending.user_id)
    if user:
        user.add_balance(float(amount),
                         note=f"شحن SMS — المرجع: {ref_id}",
                         performed_by="sms_webhook",
                         reference_id=pending.request_id)

    db.session.commit()
    return jsonify({"status": "ok", "credited": float(amount)}), 200


@sms_bp.route("/binance/confirm", methods=["POST"])
@csrf.exempt
def binance_confirm():
    """تأكيد تحويل Binance الداخلي"""

    logger.info("Binance webhook POST received path=/sms/binance/confirm from=%s payload=%s", request.remote_addr, request.get_json(silent=True))

    secret = request.headers.get("X-Webhook-Secret", "")
    if not hmac.compare_digest(secret, WEBHOOK_SECRET):
        return jsonify({"error": "Unauthorized"}), 401

    data = request.get_json(silent=True) or {}
    transaction_id = data.get("transaction_id", "").strip()
    sender_uid     = data.get("sender_uid", "").strip()
    amount         = data.get("amount")
    coin           = data.get("coin", "USDT").upper()
    request_id     = data.get("request_id", "").strip()

    if not all([transaction_id, amount, request_id]):
        return jsonify({"error": "Missing fields"}), 400

    # منع تكرار التحويل
    from ..models.payment import TopUpRequest
    if TopUpRequest.query.filter_by(binance_transaction_id=transaction_id).first():
        return jsonify({"status": "duplicate"}), 200

    pending = TopUpRequest.query.filter_by(
        request_id=request_id, status=TOPUP_STATUS_PENDING
    ).first()

    if not pending:
        return jsonify({"status": "not_found"}), 404

    if abs(float(pending.amount) - float(amount)) > 0.01:
        return jsonify({"status": "amount_mismatch"}), 400

    pending.status                 = TOPUP_STATUS_COMPLETED
    pending.binance_transaction_id = transaction_id
    pending.binance_sender_uid     = sender_uid
    pending.binance_coin           = coin
    pending.confirmed_at           = datetime.utcnow()

    user = User.query.get(pending.user_id)
    if user:
        user.add_balance(float(amount),
                         note=f"شحن Binance — TxID: {transaction_id}",
                         performed_by="binance_webhook",
                         reference_id=pending.request_id)

    db.session.commit()
    return jsonify({"status": "ok", "credited": float(amount)}), 200

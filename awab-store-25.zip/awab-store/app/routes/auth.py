"""
=============================================================
  app/routes/auth.py — مسارات التسجيل وتسجيل الدخول
=============================================================
"""

from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_user, logout_user, login_required, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, EmailField, BooleanField
from wtforms.validators import DataRequired, Email, Length, EqualTo, ValidationError

from ..extensions import db, limiter
from ..models.user import User

auth_bp = Blueprint("auth", __name__)


# ─────────────────────────────────────────────
#  نماذج WTForms
# ─────────────────────────────────────────────
class RegisterForm(FlaskForm):
    username  = StringField("اسم المستخدم", validators=[DataRequired(), Length(3, 64)])
    email     = EmailField("البريد الإلكتروني", validators=[DataRequired(), Email()])
    password  = PasswordField("كلمة المرور", validators=[DataRequired(), Length(8)])
    confirm   = PasswordField("تأكيد كلمة المرور", validators=[DataRequired(), EqualTo("password")])

    def validate_username(self, field):
        if User.query.filter_by(username=field.data).first():
            raise ValidationError("اسم المستخدم مستخدم بالفعل.")

    def validate_email(self, field):
        if User.query.filter_by(email=field.data).first():
            raise ValidationError("البريد الإلكتروني مستخدم بالفعل.")


class LoginForm(FlaskForm):
    username  = StringField("اسم المستخدم", validators=[DataRequired()])
    password  = PasswordField("كلمة المرور",  validators=[DataRequired()])
    remember  = BooleanField("تذكّرني")


# ─────────────────────────────────────────────
#  المسارات
# ─────────────────────────────────────────────
@auth_bp.route("/register", methods=["GET", "POST"])
@limiter.limit("10 per hour")
def register():
    if current_user.is_authenticated:
        return redirect(url_for("store.index"))
    form = RegisterForm()
    if form.validate_on_submit():
        user = User(
            username=form.username.data.strip(),
            email=form.email.data.strip().lower(),
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash("مرحباً بك في Awab Store! تم إنشاء حسابك بنجاح.", "success")
        return redirect(url_for("store.index"))
    return render_template("auth/register.html", form=form)


@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("20 per hour")
def login():
    if current_user.is_authenticated:
        return redirect(url_for("store.index"))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data) and user.is_active:
            user.last_login = datetime.utcnow()
            db.session.commit()
            login_user(user, remember=form.remember.data)
            next_page = request.args.get("next")
            flash("مرحباً بعودتك!", "success")
            return redirect(next_page or url_for("store.index"))
        flash("اسم المستخدم أو كلمة المرور غير صحيحة.", "danger")
    return render_template("auth/login.html", form=form)


@auth_bp.route("/logout")
@login_required
def logout():
    session.pop("cart", None)
    logout_user()
    flash("تم تسجيل الخروج بنجاح.", "info")
    return redirect(url_for("store.index"))


@auth_bp.route("/account")
@login_required
def account():
    return render_template("account/dashboard.html")


@auth_bp.route("/account/orders")
@login_required
def account_orders():
    page = request.args.get("page", 1, type=int)
    orders = (current_user.orders
              .order_by(db.text("created_at DESC"))
              .paginate(page=page, per_page=10, error_out=False))
    return render_template("account/orders.html", orders=orders)


@auth_bp.route("/account/wallet")
@login_required
def account_wallet():
    page = request.args.get("page", 1, type=int)
    transactions = (current_user.transactions
                    .order_by(db.text("created_at DESC"))
                    .paginate(page=page, per_page=20, error_out=False))
    top_up_requests = current_user.top_up_requests.order_by(db.text("created_at DESC")).limit(5).all()
    return render_template("account/wallet.html",
                           transactions=transactions,
                           top_up_requests=top_up_requests)


@auth_bp.route("/account/settings", methods=["GET", "POST"])
@login_required
def account_settings():
    if request.method == "POST":
        action = request.form.get("action", "")

        if action == "change_password":
            current_pw  = request.form.get("current_password", "")
            new_pw      = request.form.get("new_password", "")
            confirm_pw  = request.form.get("confirm_password", "")

            if not current_user.check_password(current_pw):
                flash("كلمة المرور الحالية غير صحيحة.", "danger")
            elif len(new_pw) < 8:
                flash("كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل.", "danger")
            elif new_pw != confirm_pw:
                flash("كلمة المرور الجديدة وتأكيدها غير متطابقين.", "danger")
            else:
                current_user.set_password(new_pw)
                from ..models.payment import AuditLog
                log = AuditLog(
                    action="password_changed",
                    performed_by=current_user.username,
                    target_user_id=current_user.id,
                    data={},
                    ip_address=request.remote_addr,
                )
                db.session.add(log)
                db.session.commit()
                flash("✅ تم تغيير كلمة المرور بنجاح.", "success")

        elif action == "update_profile":
            new_username = request.form.get("username", "").strip()
            new_email    = request.form.get("email", "").strip().lower()
            new_phone    = request.form.get("phone", "").strip()

            if not new_username or not new_email:
                flash("اسم المستخدم والبريد الإلكتروني مطلوبان.", "danger")
            else:
                # التحقق من عدم التكرار
                taken_user = User.query.filter(
                    User.username == new_username, User.id != current_user.id
                ).first()
                taken_email = User.query.filter(
                    User.email == new_email, User.id != current_user.id
                ).first()

                if taken_user:
                    flash("اسم المستخدم مستخدم بالفعل.", "danger")
                elif taken_email:
                    flash("البريد الإلكتروني مستخدم بالفعل.", "danger")
                else:
                    current_user.username = new_username
                    current_user.email    = new_email
                    current_user.phone    = new_phone or None
                    db.session.commit()
                    flash("✅ تم تحديث البيانات بنجاح.", "success")

        return redirect(url_for("auth.account_settings"))

    return render_template("account/settings.html")

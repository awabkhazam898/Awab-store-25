"""
=============================================================
  app/routes/payments.py — مسارات شحن الرصيد
  SMS (Libyana/Almadar) + Binance Internal Transfer
=============================================================
"""

from datetime import datetime, timedelta
from flask import (Blueprint, render_template, redirect, url_for,
                   flash, request, jsonify, abort)
from flask_login import login_required, current_user
from flask_wtf import FlaskForm
from wtforms import FloatField, StringField, SelectField
from wtforms.validators import DataRequired, NumberRange

from ..extensions import db, limiter, csrf
from ..models.payment import (TopUpRequest, AuditLog,
                               PAYMENT_METHOD_SMS, PAYMENT_METHOD_BINANCE,
                               TOPUP_STATUS_PENDING, TOPUP_STATUS_COMPLETED)
from config import (LIBYANA_PHONE, ALMADAR_PHONE,
                    BINANCE_UID, BINANCE_EMAIL,
                    LIBYANA_VERIFICATION_WINDOW, ALMADAR_VERIFICATION_WINDOW)

payments_bp = Blueprint("payments", __name__)


class TopUpForm(FlaskForm):
    amount = FloatField("المبلغ (LYD)", validators=[DataRequired(), NumberRange(min=1)])
    method = SelectField("طريقة الشحن", choices=[
        (PAYMENT_METHOD_SMS,     "SMS — Libyana / Almadar"),
        (PAYMENT_METHOD_BINANCE, "Binance Internal Transfer"),
    ], validators=[DataRequired()])


@payments_bp.route("/topup", methods=["GET", "POST"])
@login_required
@limiter.limit("10 per hour")
def topup():
    form = TopUpForm()
    if form.validate_on_submit():
        req = TopUpRequest(
            user_id=current_user.id,
            amount=form.amount.data,
            method=form.method.data,
            status=TOPUP_STATUS_PENDING,
        )
        if form.method.data == PAYMENT_METHOD_SMS:
            req.expires_at = datetime.utcnow() + timedelta(minutes=10)
        db.session.add(req)
        db.session.commit()

        if form.method.data == PAYMENT_METHOD_SMS:
            return redirect(url_for("payments.topup_sms", request_id=req.request_id))
        elif form.method.data == PAYMENT_METHOD_BINANCE:
            return redirect(url_for("payments.topup_binance", request_id=req.request_id))

    return render_template("payments/topup.html", form=form)


@payments_bp.route("/topup/sms/<request_id>", methods=["GET", "POST"])
@login_required
def topup_sms(request_id):
    req = TopUpRequest.query.filter_by(
        request_id=request_id, user_id=current_user.id
    ).first_or_404()

    if request.method == "POST":
        phone       = request.form.get("sender_phone", "").strip()
        amount_sent = request.form.get("amount_sent", "").strip()
        if not phone or not amount_sent:
            flash("يرجى إدخال رقم الهاتف والمبلغ المُرسَل.", "danger")
            return redirect(url_for("payments.topup_sms", request_id=request_id))
        req.sender_phone = phone
        req.sms_text     = f"المبلغ المُرسَل: {amount_sent} د.ل"
        db.session.commit()
        flash("✅ تم استلام طلبك! سيتم مراجعته وإضافة الرصيد خلال دقائق.", "success")
        return redirect(url_for("auth.account_wallet"))

    return render_template("payments/topup_sms.html", req=req,
                           libyana_phone=LIBYANA_PHONE,
                           almadar_phone=ALMADAR_PHONE)


@payments_bp.route("/topup/binance/<request_id>")
@login_required
def topup_binance(request_id):
    req = TopUpRequest.query.filter_by(
        request_id=request_id, user_id=current_user.id
    ).first_or_404()
    return render_template("payments/topup_binance.html", req=req,
                           binance_uid=BINANCE_UID,
                           binance_email=BINANCE_EMAIL)


@payments_bp.route("/topup/binance/<request_id>/verify", methods=["GET", "POST"])
@login_required
def topup_binance_verify(request_id):
    from ..utils.binance import verify_binance_pay_order
    from config import BINANCE_API_KEY

    req = TopUpRequest.query.filter_by(
        request_id=request_id, user_id=current_user.id
    ).first_or_404()

    # منع إعادة التحقق إن كان الطلب مكتملاً
    if req.status == TOPUP_STATUS_COMPLETED:
        flash("✅ هذا الطلب تم تأكيده مسبقاً.", "info")
        return redirect(url_for("auth.account_wallet"))

    api_configured = bool(BINANCE_API_KEY)

    if request.method == "POST":
        order_id       = request.form.get("order_id", "").strip()
        amount_str     = request.form.get("amount_usd", "").strip()

        if not order_id:
            flash("يرجى إدخال Order ID.", "danger")
            return redirect(url_for("payments.topup_binance_verify", request_id=request_id))
        if not amount_str:
            flash("يرجى إدخال المبلغ المُحوَّل.", "danger")
            return redirect(url_for("payments.topup_binance_verify", request_id=request_id))

        try:
            amount_usd = float(amount_str)
            if amount_usd <= 0:
                raise ValueError()
        except ValueError:
            flash("المبلغ المُدخَل غير صحيح.", "danger")
            return redirect(url_for("payments.topup_binance_verify", request_id=request_id))

        # منع تكرار نفس Order ID
        existing = TopUpRequest.query.filter_by(binance_transaction_id=order_id).first()
        if existing and existing.id != req.id:
            flash("⚠️ هذا Order ID مستخدم مسبقاً.", "danger")
            return redirect(url_for("payments.topup_binance_verify", request_id=request_id))

        # حفظ البيانات دائماً
        req.binance_transaction_id = order_id
        req.binance_amount_usd     = amount_usd

        # ── التحقق عبر Binance API إن كانت المفاتيح مضبوطة ──
        if api_configured:
            result = verify_binance_pay_order(
                order_id=order_id,
                expected_amount=amount_usd,
                expected_currency="USDT",
            )

            if not result.success:
                # خطأ في الاتصال أو الإعداد — نقبل الطلب يدوياً
                req.binance_coin = "USDT"
                db.session.commit()
                flash(
                    "⚠️ تعذّر التحقق التلقائي الآن. تم حفظ طلبك وسيُراجَع يدوياً.",
                    "warning",
                )
                return redirect(url_for("auth.account_wallet"))

            if not result.verified:
                db.session.commit()  # نحتفظ بالـ order_id للمراجعة
                flash(f"❌ فشل التحقق: {result.error}", "danger")
                return redirect(url_for("payments.topup_binance_verify", request_id=request_id))

            # ── المعاملة مؤكدة ── أضف الرصيد مرة واحدة فقط ─────
            req.binance_coin   = result.currency or "USDT"
            req.status         = TOPUP_STATUS_COMPLETED
            req.confirmed_at   = datetime.utcnow()

            # إضافة الرصيد للمستخدم
            user = current_user._get_current_object()
            user.add_balance(
                req.amount,
                note=f"شحن Binance — Order ID: {order_id}",
                reference_id=req.request_id,
            )
            db.session.commit()

            flash(f"✅ تم التحقق وإضافة {req.amount:.2f} د.ل إلى رصيدك تلقائياً!", "success")
            return redirect(url_for("auth.account_wallet"))

        else:
            # لا توجد مفاتيح — يدوي
            req.binance_coin = "USDT"
            db.session.commit()
            flash("✅ تم استلام طلب التحقق! سيتم مراجعة التحويل وإضافة الرصيد خلال دقائق.", "success")
            return redirect(url_for("auth.account_wallet"))

    return render_template(
        "payments/topup_binance_verify.html",
        req=req,
        binance_uid=BINANCE_UID,
        api_configured=api_configured,
    )

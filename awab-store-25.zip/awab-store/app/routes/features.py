"""Customer routes and JSON APIs for optional store features."""
from datetime import datetime, timedelta
import hashlib

from flask import Blueprint, current_app, flash, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required
from sqlalchemy.exc import IntegrityError

from ..extensions import csrf, db
from ..models.features import Auction, GiftOrder, GroupBuy, NetflixProfileAssignment, TelegramLink
from ..models.inventory import InventoryItem
from ..models.product import PRODUCT_TYPE_SUBSCRIPTION, Product
from ..services.features import (active_access_for_user, expire_group_buys, join_group_buy,
                                 make_link_token, place_bid, preview_game_code, reset_access_devices,
                                 reset_devices, subscription_days_remaining, valid_link_token)

features_bp = Blueprint("features", __name__)


def _wants_json():
    return request.is_json or request.accept_mimetypes.best == "application/json"


def _error(message, status=400, endpoint="features.feature_hub"):
    if _wants_json():
        return jsonify({"status": False, "message": message}), status
    flash(message, "danger")
    return redirect(url_for(endpoint))


@features_bp.route("/account/telegram-link")
@login_required
def telegram_link():
    token, token_hash = make_link_token()
    link = TelegramLink.query.filter_by(user_id=current_user.id).first()
    if not link:
        # Existing SQLite installations may still enforce NOT NULL on telegram_id.
        link = TelegramLink(user_id=current_user.id, telegram_id=-current_user.id)
        db.session.add(link)
    link.token_hash = token_hash
    link.token_expires_at = datetime.utcnow() + timedelta(minutes=10)
    db.session.commit()
    bot = current_app.config.get("AUCTION_BOT_USERNAME", "AwabAuctionBot")
    return jsonify({"status": True, "expires_in": 600, "deep_link": f"https://t.me/{bot}?start={token}"})


@features_bp.route("/api/telegram/preview/<token>")
def telegram_preview(token):
    from ..models.user import User
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    link = TelegramLink.query.filter_by(token_hash=token_hash).first()
    if not valid_link_token(link, token):
        return jsonify({"status": False, "message": "رابط الربط منتهي أو غير صالح"}), 400
    user = User.query.get(link.user_id)
    return jsonify({"status": True, "username": user.username, "email": user.email, "balance": round(user.balance, 2)})


@features_bp.route("/api/telegram/confirm/<token>", methods=["POST"])
@csrf.exempt
def telegram_confirm(token):
    data = request.get_json(silent=True) or request.form
    link = TelegramLink.query.filter_by(token_hash=hashlib.sha256(token.encode()).hexdigest()).first()
    if not valid_link_token(link, token):
        return jsonify({"status": False, "message": "رابط الربط منتهي أو غير صالح"}), 400
    try:
        telegram_id = int(data.get("telegram_id"))
        if telegram_id <= 0:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({"status": False, "message": "telegram_id غير صالح"}), 400
    other = TelegramLink.query.filter_by(telegram_id=telegram_id).first()
    if other and other.id != link.id:
        return jsonify({"status": False, "message": "حساب تليجرام مربوط بحساب آخر"}), 409
    link.telegram_id = telegram_id
    link.username = (data.get("username") or "").strip().lstrip("@")[:64] or None
    link.verified_at = datetime.utcnow()
    link.token_hash = None
    link.token_expires_at = None
    db.session.commit()
    return jsonify({"status": True, "message": "تم ربط حساب تليجرام بنجاح"})


@features_bp.route("/features")
def feature_hub():
    expire_group_buys()
    auctions = Auction.query.filter_by(status="active").order_by(Auction.ends_at.asc()).all()
    group_buys = GroupBuy.query.filter_by(status="open").order_by(GroupBuy.ends_at.asc()).all()
    gifts, accesses = [], []
    if current_user.is_authenticated:
        gifts = GiftOrder.query.filter_by(sender_id=current_user.id).order_by(GiftOrder.created_at.desc()).limit(10).all()
        accesses = NetflixProfileAssignment.query.filter_by(
            user_id=current_user.id, status="active").filter(
            (NetflixProfileAssignment.expires_at.is_(None)) |
            (NetflixProfileAssignment.expires_at > datetime.utcnow())
        ).all()
        if not accesses:
            accesses = current_user.netflix_accesses.filter_by(is_active=True).all()
    gift_products = Product.query.filter(
        Product.is_active.is_(True), Product.product_type != PRODUCT_TYPE_SUBSCRIPTION
    ).order_by(Product.name).all()
    return render_template("features/hub.html", auctions=auctions, group_buys=group_buys,
                           gifts=gifts, accesses=accesses, gift_products=gift_products,
                           subscription_days_remaining=subscription_days_remaining,
                           now=datetime.utcnow())


@features_bp.route("/auctions")
def auctions():
    rows = Auction.query.filter_by(status="active").order_by(Auction.ends_at.asc()).all()
    return jsonify([{"id": row.id, "title": row.title, "description": row.description,
                     "start_price": row.start_price, "bid_step": row.bid_step,
                     "ends_at": row.ends_at.isoformat(),
                     "highest_bid": row.bids.first().amount if row.bids.first() else None}
                    for row in rows])


@features_bp.route("/auctions/<int:auction_id>/bid", methods=["POST"])
@login_required
def auction_bid(auction_id):
    try:
        bid = place_bid(auction_id, current_user.id)
    except ValueError as exc:
        db.session.rollback()
        return _error(str(exc))
    if _wants_json():
        return jsonify({"status": True, "amount": bid.amount, "auction_id": bid.auction_id})
    flash(f"تم تسجيل مزايدتك بقيمة {bid.amount:.2f} LYD.", "success")
    return redirect(url_for("features.feature_hub"))


@features_bp.route("/gifts", methods=["POST"])
@login_required
def create_gift():
    data = request.get_json(silent=True) or request.form
    recipient = str(data.get("recipient", "")).strip()[:160]
    channel = str(data.get("channel", "telegram")).strip().lower()
    message = str(data.get("message", "")).strip()[:2000]
    # anonymous flag — checkbox: when present and truthy → true; default True for safety
    _anon_raw = data.get("anonymous", "true")
    if isinstance(_anon_raw, bool):
        anonymous = _anon_raw
    else:
        anonymous = str(_anon_raw).strip().lower() not in {"0", "false", "no", "off", ""}
    # If a JSON body explicitly includes "anonymous": null/0 we honor that; otherwise default true.
    try:
        product_id = int(data.get("product_id", 0))
    except (TypeError, ValueError):
        product_id = 0
    product = Product.query.get(product_id)
    if not recipient or channel not in {"telegram", "whatsapp", "manual"}:
        return _error("أدخل بيانات المستلم واختر قناة إرسال صحيحة.")
    if not product or not product.is_active or product.product_type == PRODUCT_TYPE_SUBSCRIPTION or product.price <= 0:
        return _error("هذا المنتج غير متاح للإهداء.")
    try:
        item = InventoryItem.query.filter_by(product_id=product.id, is_sold=False).with_for_update().first()
        if not item:
            return _error("المنتج غير متوفر حالياً.", 409)
        if not current_user.deduct_balance(product.price, "شراء هدية"):
            return _error("رصيدك غير كاف لشراء الهدية.")
        item.mark_sold(None)
        gift = GiftOrder(sender_id=current_user.id, product_id=product.id, recipient=recipient,
                         channel=channel, message=message or None, anonymous=anonymous,
                         status="ready", delivery_text=item.delivery_text, delivered_at=datetime.utcnow())
        db.session.add(gift)
        db.session.commit()
    except Exception:
        db.session.rollback()
        return _error("تعذر تجهيز الهدية. حاول مرة أخرى.", 409)
    if _wants_json():
        return jsonify({"status": True, "gift_id": gift.id, "delivery": gift.delivery_text,
                        "message": "تم تجهيز الهدية."})
    flash("تم تجهيز الهدية. ستجد رمز التسليم في سجل الهدايا.", "success")
    return redirect(url_for("features.feature_hub"))


@features_bp.route("/group-buys/<int:group_id>/join", methods=["POST"])
@login_required
def join_group_buy_route(group_id):
    try:
        participant, status, count = join_group_buy(group_id, current_user.id)
    except (IntegrityError, ValueError) as exc:
        db.session.rollback()
        return _error("أنت مشترك بالفعل في هذا العرض." if isinstance(exc, IntegrityError) else str(exc))
    if _wants_json():
        return jsonify({"status": True, "participants": count, "group_status": status,
                        "delivery": participant.delivery_text})
    flash("تم تفعيل العرض وتسليم الكود." if status == "unlocked" else "تم حجز اشتراكك في العرض الجماعي.", "success")
    return redirect(url_for("features.feature_hub"))


@features_bp.route("/api/games/preview", methods=["POST"])
@login_required
def game_preview():
    data = request.get_json(silent=True) or request.form
    return jsonify(preview_game_code(data.get("provider"), data.get("code"), data.get("player_id")))


@features_bp.route("/netflix/<int:profile_id>/device", methods=["POST"])
@login_required
def netflix_device(profile_id):
    access = active_access_for_user(profile_id, current_user.id)
    if not access:
        return _error("لا تملك وصولاً نشطاً لهذا البروفايل.", 403)
    fingerprint = str((request.get_json(silent=True) or request.form).get("fingerprint", "")).strip()
    try:
        device = reset_devices(access, fingerprint, request.remote_addr)
    except ValueError as exc:
        return _error(str(exc), 409)
    return jsonify({"status": True, "device_id": device.id, "message": "تم تسجيل الجهاز"})


@features_bp.route("/netflix/<int:profile_id>/reset-devices", methods=["POST"])
@login_required
def netflix_reset_devices(profile_id):
    access = active_access_for_user(profile_id, current_user.id)
    if not access:
        return _error("لا تملك وصولاً نشطاً لهذا البروفايل.", 403)
    try:
        reset_access_devices(access)
    except ValueError as exc:
        return _error(str(exc), 409)
    if _wants_json():
        return jsonify({"status": True, "message": "تمت إعادة ضبط الأجهزة المسجلة"})
    flash("تمت إعادة ضبط الأجهزة المسجلة.", "success")
    return redirect(url_for("features.feature_hub"))
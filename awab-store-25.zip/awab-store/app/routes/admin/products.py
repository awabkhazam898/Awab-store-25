"""
=============================================================
  admin/products.py — إدارة المنتجات والفئات
=============================================================
"""

from flask import render_template, redirect, url_for, request, flash, session
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, DecimalField, IntegerField, SelectField, BooleanField, HiddenField
from wtforms.validators import DataRequired, Optional, NumberRange
from . import admin_bp, admin_required
from app.extensions import db
from app.models.product import Product, Category, ProductField


# ─────────────────────────────────────────────
#  Forms
# ─────────────────────────────────────────────

class CategoryForm(FlaskForm):
    name       = StringField("اسم الفئة", validators=[DataRequired()])
    icon       = StringField("أيقونة Bootstrap Icons", default="grid")
    sort_order = IntegerField("ترتيب العرض", default=0)
    is_active  = BooleanField("فئة مفعّلة", default=True)


class ProductForm(FlaskForm):
    name             = StringField("اسم المنتج",   validators=[DataRequired()])
    description      = TextAreaField("الوصف",       validators=[Optional()])
    price            = DecimalField("السعر (د.ل)",  validators=[DataRequired(), NumberRange(min=0)])
    category_id      = SelectField("الفئة",          coerce=int, validators=[DataRequired()])
    product_type     = SelectField("نوع المنتج", choices=[
        ("gift_card",      "بطاقة هدية"),
        ("account_subscription", "اشتراك"),
        ("ready_account",  "حساب جاهز"),
    ])
    image_url        = StringField("رابط الصورة", validators=[Optional()])
    is_active        = BooleanField("منتج مفعّل", default=True)
    sort_order       = IntegerField("ترتيب العرض", default=0)


# ─────────────────────────────────────────────
#  Categories
# ─────────────────────────────────────────────

@admin_bp.route("/categories")
@admin_required
def categories():
    cats = Category.query.order_by(Category.sort_order, Category.name).all()
    return render_template("admin/categories/list.html", categories=cats)


@admin_bp.route("/categories/new", methods=["GET", "POST"])
@admin_required
def category_new():
    form = CategoryForm()
    if form.validate_on_submit():
        import re
        slug = re.sub(r"[^\w-]", "", form.name.data.lower().replace(" ", "-"))
        cat  = Category(
            name=form.name.data,
            slug=slug,
            icon=form.icon.data or "grid",
            sort_order=form.sort_order.data or 0,
            is_active=form.is_active.data,
        )
        db.session.add(cat)
        db.session.commit()
        flash("تمت إضافة الفئة بنجاح.", "success")
        return redirect(url_for("admin.categories"))
    return render_template("admin/categories/form.html", form=form, title="فئة جديدة")


@admin_bp.route("/categories/<int:cat_id>/edit", methods=["GET", "POST"])
@admin_required
def category_edit(cat_id):
    cat  = Category.query.get_or_404(cat_id)
    form = CategoryForm(obj=cat)
    if form.validate_on_submit():
        cat.name       = form.name.data
        cat.icon       = form.icon.data or "grid"
        cat.sort_order = form.sort_order.data or 0
        cat.is_active  = form.is_active.data
        db.session.commit()
        flash("تم تحديث الفئة.", "success")
        return redirect(url_for("admin.categories"))
    return render_template("admin/categories/form.html", form=form, title="تعديل الفئة", cat=cat)


# ─────────────────────────────────────────────
#  Products
# ─────────────────────────────────────────────

@admin_bp.route("/products")
@admin_required
def products():
    page = request.args.get("page", 1, type=int)
    q    = request.args.get("q", "").strip()
    query = Product.query
    if q:
        query = query.filter(Product.name.ilike(f"%{q}%"))
    prods = query.order_by(Product.sort_order, Product.name).paginate(page=page, per_page=20)
    return render_template("admin/products/list.html", products=prods, q=q)


@admin_bp.route("/products/new", methods=["GET", "POST"])
@admin_required
def product_new():
    form = ProductForm()
    form.category_id.choices = [
        (c.id, c.name) for c in Category.query.filter_by(is_active=True).order_by(Category.sort_order).all()
    ]
    if form.validate_on_submit():
        import re
        base_slug = re.sub(r"[^\w-]+", "-", form.name.data.strip().lower()).strip("-") or "product"
        slug = base_slug
        suffix = 2
        while Product.query.filter_by(slug=slug).first() is not None:
            slug = f"{base_slug}-{suffix}"
            suffix += 1
        prod = Product(
            name=form.name.data,
            slug=slug,
            description=form.description.data,
            price=float(form.price.data),
            category_id=form.category_id.data,
            product_type=form.product_type.data,
            image_url=form.image_url.data or None,
            is_active=form.is_active.data,
            sort_order=form.sort_order.data or 0,
        )
        db.session.add(prod)
        db.session.commit()
        flash("تمت إضافة المنتج بنجاح.", "success")
        return redirect(url_for("admin.products"))
    return render_template("admin/products/form.html", form=form, title="منتج جديد", product=None)


@admin_bp.route("/products/<int:prod_id>/edit", methods=["GET", "POST"])
@admin_required
def product_edit(prod_id):
    prod = Product.query.get_or_404(prod_id)
    form = ProductForm(obj=prod)
    form.category_id.choices = [
        (c.id, c.name) for c in Category.query.order_by(Category.sort_order).all()
    ]
    if form.validate_on_submit():
        prod.name            = form.name.data
        prod.description     = form.description.data
        prod.price           = float(form.price.data)
        prod.category_id     = form.category_id.data
        prod.product_type    = form.product_type.data
        prod.image_url       = form.image_url.data or None
        prod.is_active       = form.is_active.data
        prod.sort_order      = form.sort_order.data or 0
        db.session.commit()
        flash("تم تحديث المنتج.", "success")
        return redirect(url_for("admin.products"))
    return render_template("admin/products/form.html", form=form, title="تعديل المنتج", product=prod)


@admin_bp.route("/products/<int:prod_id>/delete", methods=["POST"])
@admin_required
def product_delete(prod_id):
    prod = Product.query.get_or_404(prod_id)
    db.session.delete(prod)
    db.session.commit()
    flash("تم حذف المنتج.", "warning")
    return redirect(url_for("admin.products"))


@admin_bp.route("/products/<int:prod_id>/fields", methods=["GET", "POST"])
@admin_required
def product_fields(prod_id):
    prod = Product.query.get_or_404(prod_id)
    if request.method == "POST":
        # حذف الحقول القديمة وإعادة الإنشاء
        ProductField.query.filter_by(product_id=prod_id).delete()
        labels = request.form.getlist("label[]")
        types  = request.form.getlist("type[]")
        reqs   = request.form.getlist("required[]")
        for i, label in enumerate(labels):
            if label.strip():
                pf = ProductField(
                    product_id=prod_id,
                    label=label.strip(),
                    field_type=types[i] if i < len(types) else "text",
                    is_required=str(i) in reqs,
                    sort_order=i,
                )
                db.session.add(pf)
        db.session.commit()
        flash("تم حفظ الحقول.", "success")
        return redirect(url_for("admin.product_fields", prod_id=prod_id))
    fields = ProductField.query.filter_by(product_id=prod_id).order_by(ProductField.sort_order).all()
    return render_template("admin/products/fields.html", product=prod, fields=fields)

"""
=============================================================
  admin/inventory.py — إدارة المخزون (Codes / Accounts)
=============================================================
"""

from flask import render_template, redirect, url_for, request, flash
from . import admin_bp, admin_required
from app.extensions import db
from app.models.product   import Product
from app.models.inventory import InventoryItem


@admin_bp.route("/inventory")
@admin_required
def inventory():
    prod_id = request.args.get("product_id", type=int)
    page    = request.args.get("page", 1, type=int)
    query   = InventoryItem.query
    if prod_id:
        query = query.filter_by(product_id=prod_id)
    items = query.order_by(InventoryItem.created_at.desc()).paginate(page=page, per_page=30)
    products = Product.query.filter(Product.product_type != "account_subscription").order_by(Product.name).all()
    return render_template(
        "admin/inventory/list.html",
        items=items, products=products,
        selected_product_id=prod_id,
    )


@admin_bp.route("/inventory/add", methods=["GET", "POST"])
@admin_required
def inventory_add():
    products = Product.query.filter(
        Product.product_type != "account_subscription",
        Product.is_active.is_(True),
    ).order_by(Product.name).all()
    if request.method == "POST":
        prod_id = request.form.get("product_id", type=int)
        codes   = request.form.get("codes", "").strip()
        if not prod_id:
            flash("اختر منتجاً أولاً.", "danger")
        elif not codes:
            flash("أدخل بيانات المخزون.", "danger")
        else:
            added = 0
            for line in codes.splitlines():
                line = line.strip()
                if line:
                    item = InventoryItem(product_id=prod_id, code=line)
                    db.session.add(item)
                    added += 1
            db.session.commit()
            flash(f"تمت إضافة {added} عنصر للمخزون.", "success")
            return redirect(url_for("admin.inventory", product_id=prod_id))
    return render_template("admin/inventory/add.html", products=products)


@admin_bp.route("/inventory/<int:item_id>/delete", methods=["POST"])
@admin_required
def inventory_delete(item_id):
    item = InventoryItem.query.get_or_404(item_id)
    prod_id = item.product_id
    if item.is_sold:
        flash("لا يمكن حذف عنصر تم بيعه.", "danger")
        return redirect(url_for("admin.inventory", product_id=prod_id))
    db.session.delete(item)
    db.session.commit()
    flash("تم حذف العنصر.", "warning")
    return redirect(url_for("admin.inventory", product_id=prod_id))


@admin_bp.route("/inventory/<int:item_id>/edit", methods=["GET", "POST"])
@admin_required
def inventory_edit(item_id):
    item = InventoryItem.query.get_or_404(item_id)
    if item.is_sold:
        flash("لا يمكن تعديل عنصر تم بيعه.", "danger")
        return redirect(url_for("admin.inventory", product_id=item.product_id))
    if request.method == "POST":
        item.code = request.form.get("code", "").strip() or None
        item.email = request.form.get("email", "").strip() or None
        item.password = request.form.get("password", "").strip() or None
        item.pin = request.form.get("pin", "").strip() or None
        item.notes = request.form.get("notes", "").strip() or None
        if not any((item.code, item.email, item.password)):
            flash("أدخل كوداً أو بيانات حساب.", "danger")
        else:
            db.session.commit()
            flash("تم تحديث عنصر المخزون.", "success")
            return redirect(url_for("admin.inventory", product_id=item.product_id))
    return render_template("admin/inventory/edit.html", item=item)

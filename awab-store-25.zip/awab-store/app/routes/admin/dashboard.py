"""
=============================================================
  admin/dashboard.py — الصفحة الرئيسية للوحة التحكم
=============================================================
"""

from flask import render_template
from . import admin_bp, admin_required
from app.extensions import db
from app.models.user        import User
from app.models.product     import Product
from app.models.inventory   import InventoryItem
from app.models.order       import Order
from app.models.payment     import TopUpRequest
from app.models.notification import SiteNotification
from app.models.admin_staff import AdminStaff


@admin_bp.route("/")
@admin_bp.route("/dashboard")
@admin_required
def dashboard():
    stats = {
        "users":           User.query.count(),
        "orders_total":    Order.query.count(),
        "orders_pending":  Order.query.filter_by(status="pending").count(),
        "products":        Product.query.count(),
        "inventory":       InventoryItem.query.filter_by(is_sold=False).count(),
        "topups_pending":  TopUpRequest.query.filter_by(status="pending").count(),
        "notifs_active":   len(SiteNotification.get_active_now()),
        "staff":           AdminStaff.query.filter_by(is_active=True).count(),
        "orders_completed": Order.query.filter_by(status="completed").count(),
        "revenue":         db.session.query(
                               db.func.sum(Order.total_amount)
                           ).filter_by(status="completed").scalar() or 0,
    }
    recent_orders = (
        Order.query
        .order_by(Order.created_at.desc())
        .limit(10)
        .all()
    )
    return render_template(
        "admin/dashboard.html",
        stats=stats,
        recent_orders=recent_orders,
    )

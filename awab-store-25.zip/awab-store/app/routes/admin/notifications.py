"""
=============================================================
  admin/notifications.py — إدارة الإشعارات
=============================================================
"""

from datetime import datetime

from flask import render_template, redirect, url_for, request, flash
from . import admin_bp, admin_required
from app.extensions import db
from app.models.notification import SiteNotification, NOTIF_TYPES


@admin_bp.route("/notifications")
@admin_required
def notifications_list():
    notifs = SiteNotification.query.order_by(SiteNotification.created_at.desc()).all()
    return render_template("admin/notifications/list.html", notifications=notifs)


@admin_bp.route("/notifications/new", methods=["GET", "POST"])
@admin_required
def notifications_create():
    if request.method == "POST":
        title       = request.form.get("title", "").strip()
        message     = request.form.get("message", "").strip()
        notif_type  = request.form.get("notif_type", "info")
        starts_at_s = request.form.get("starts_at", "")
        expires_at_s = request.form.get("expires_at", "")

        if not title or not message:
            flash("العنوان والمحتوى مطلوبان.", "danger")
            return render_template(
                "admin/notifications/form.html",
                notif=None,
                NOTIF_TYPES=NOTIF_TYPES,
            )

        starts_at = datetime.fromisoformat(starts_at_s) if starts_at_s else None
        expires_at = datetime.fromisoformat(expires_at_s) if expires_at_s else None

        notif = SiteNotification(
            title=title, message=message,
            notif_type=notif_type,
            starts_at=starts_at, expires_at=expires_at,
            is_active=request.form.get("is_active") == "1",
        )
        db.session.add(notif)
        db.session.commit()
        flash("تم إنشاء الإشعار بنجاح.", "success")
        return redirect(url_for("admin.notifications_list"))

    return render_template(
        "admin/notifications/form.html",
        notif=None,
        NOTIF_TYPES=NOTIF_TYPES,
    )


@admin_bp.route("/notifications/<int:notif_id>/edit", methods=["GET", "POST"])
@admin_required
def notifications_edit(notif_id):
    notif = SiteNotification.query.get_or_404(notif_id)
    if request.method == "POST":
        notif.title      = request.form.get("title", "").strip()
        notif.message    = request.form.get("message", "").strip()
        notif.notif_type = request.form.get("notif_type", "info")
        s = request.form.get("starts_at", "")
        e = request.form.get("expires_at", "")
        notif.starts_at = datetime.fromisoformat(s) if s else None
        notif.expires_at = datetime.fromisoformat(e) if e else None
        notif.is_active = request.form.get("is_active") == "1"
        db.session.commit()
        flash("تم تحديث الإشعار.", "success")
        return redirect(url_for("admin.notifications_list"))
    return render_template(
        "admin/notifications/form.html",
        notif=notif,
        NOTIF_TYPES=NOTIF_TYPES,
    )


@admin_bp.route("/notifications/<int:notif_id>/toggle", methods=["POST"])
@admin_required
def notifications_toggle(notif_id):
    notif = SiteNotification.query.get_or_404(notif_id)
    notif.is_active = not notif.is_active
    db.session.commit()
    flash("تم تحديث حالة الإشعار.", "success")
    return redirect(url_for("admin.notifications_list"))


@admin_bp.route("/notifications/<int:notif_id>/delete", methods=["POST"])
@admin_required
def notifications_delete(notif_id):
    notif = SiteNotification.query.get_or_404(notif_id)
    db.session.delete(notif)
    db.session.commit()
    flash("تم حذف الإشعار.", "warning")
    return redirect(url_for("admin.notifications_list"))

"""Administrative controls for optional store features."""
from datetime import datetime, timedelta

from flask import flash, jsonify, redirect, render_template, request, url_for
from sqlalchemy.exc import IntegrityError

from . import admin_bp, admin_required
from ...extensions import db
from ...models.features import (Auction, DomainEmailAddress, DomainEmailVerificationBatch,
                                GroupBuy, NetflixProfile, NetflixProfileAssignment,
                                ProviderSession)
from ...models.product import PRODUCT_TYPE_SUBSCRIPTION, Product
from ...models.user import User
from ...services.domain_email import generate_verification_batch, send_verification_messages
from ...services.features import (assign_netflix_profile, end_netflix_profile_assignment,
                                  expire_profile_assignments, finalize_auction, money,
                                  parse_subscription_expiration, subscription_days_remaining)


def _data():
    return request.get_json(silent=True) or request.form


@admin_bp.route("/features")
@admin_required
def features_dashboard():
    return render_template(
        "admin/features/dashboard.html",
        auctions=Auction.query.order_by(Auction.created_at.desc()).all(),
        group_buys=GroupBuy.query.order_by(GroupBuy.created_at.desc()).all(),
        products=Product.query.filter(Product.is_active.is_(True), Product.product_type != PRODUCT_TYPE_SUBSCRIPTION).order_by(Product.name).all(),
        providers=ProviderSession.query.order_by(ProviderSession.provider).all(),
        profiles=NetflixProfile.query.order_by(NetflixProfile.account_label, NetflixProfile.profile_number).all(),
    )


@admin_bp.route("/features/secure-inventory")
@admin_required
def secure_inventory_admin():
    expire_profile_assignments()
    db.session.commit()
    return render_template(
        "admin/features/secure_inventory.html",
        profiles=NetflixProfile.query.order_by(
            NetflixProfile.account_label, NetflixProfile.profile_number).all(),
        assignments=NetflixProfileAssignment.query.order_by(
            NetflixProfileAssignment.starts_at.desc()).limit(100).all(),
        users=User.query.order_by(User.username).all(),
        email_batches=DomainEmailVerificationBatch.query.order_by(
            DomainEmailVerificationBatch.created_at.desc()).limit(20).all(),
        email_rows=DomainEmailAddress.query.order_by(
            DomainEmailAddress.created_at.desc()).limit(200).all(),
        now=datetime.utcnow(),
        subscription_days_remaining=subscription_days_remaining,
    )


@admin_bp.route("/features/secure-inventory/action", methods=["POST"])
@admin_required
def secure_inventory_action():
    action = request.form.get("action", "")
    try:
        if action == "email_batch":
            batch, rows = generate_verification_batch(10)
            sent = send_verification_messages(rows)
            flash("تم إنشاء دفعة من 10 عناوين وإرسال الاختبار." if sent
                  else "تم إنشاء دفعة من 10 عناوين. أضف إعدادات SMTP لإرسال الاختبار.", "success")
        elif action == "assign_profile":
            expires_at = request.form.get("expires_at", "").strip()
            expires_at = datetime.fromisoformat(expires_at) if expires_at else None
            if expires_at and expires_at <= datetime.utcnow():
                raise ValueError("تاريخ انتهاء الوصول يجب أن يكون في المستقبل")
            assign_netflix_profile(
                request.form.get("profile_id", type=int),
                request.form.get("user_id", type=int),
                expires_at,
                request.form.get("max_devices", type=int) or 1,
            )
            flash("تم تخصيص البروفايل.", "success")
        elif action == "end_assignment":
            end_netflix_profile_assignment(request.form.get("assignment_id", type=int))
            flash("تم إنهاء التخصيص وأصبح البروفايل قابلاً لإعادة البيع.", "success")
        else:
            raise ValueError("الإجراء غير صالح")
    except IntegrityError:
        db.session.rollback()
        flash("البروفايل مخصص حالياً لطلب آخر.", "danger")
    except (OSError, TypeError, ValueError) as exc:
        db.session.rollback()
        flash(str(exc), "danger")
    return redirect(url_for("admin.secure_inventory_admin"))


@admin_bp.route("/features/dashboard", methods=["POST"])
@admin_required
def features_dashboard_action():
    action = request.form.get("action", "")
    try:
        if action == "auction":
            title = request.form.get("title", "").strip()
            minutes = request.form.get("duration_minutes", type=int)
            if not title or not minutes or not 1 <= minutes <= 10080:
                raise ValueError("اسم المزاد ومدة صحيحة مطلوبان.")
            db.session.add(Auction(
                title=title[:160], description=request.form.get("description", "").strip()[:5000] or None,
                start_price=money(request.form.get("start_price")), bid_step=money(request.form.get("bid_step")),
                ends_at=datetime.utcnow() + timedelta(minutes=minutes),
                delivery_text=request.form.get("delivery_text", "").strip()[:5000] or None,
            ))
            message = "تم إنشاء المزاد."
        elif action == "group_buy":
            product = Product.query.get(request.form.get("product_id", type=int))
            target = request.form.get("target_count", type=int)
            hours = request.form.get("duration_hours", type=int)
            if (not product or product.product_type == PRODUCT_TYPE_SUBSCRIPTION or not target or not hours
                    or not 2 <= target <= 100000 or not 1 <= hours <= 720):
                raise ValueError("بيانات العرض الجماعي غير صالحة.")
            db.session.add(GroupBuy(product_id=product.id, target_count=target,
                                    deal_price=money(request.form.get("deal_price")),
                                    ends_at=datetime.utcnow() + timedelta(hours=hours)))
            message = "تم إنشاء العرض الجماعي."
        elif action == "provider":
            provider = request.form.get("provider", "").strip().lower()
            encrypted = request.form.get("encrypted_value", "").strip()
            if provider not in {"midasbuy", "shop2game", "garena"} or not encrypted:
                raise ValueError("اختر مزوداً وأدخل قيمة الجلسة المشفرة.")
            row = ProviderSession.query.filter_by(provider=provider).first()
            if row is None:
                row = ProviderSession(provider=provider)
                db.session.add(row)
            row.encrypted_value, row.status = encrypted, "configured"
            message = "تم حفظ جلسة المزود بشكل مشفر."
        elif action == "netflix":
            label = request.form.get("account_label", "").strip()
            number = request.form.get("profile_number", type=int)
            if not label or number not in range(1, 6):
                raise ValueError("أدخل اسم الحساب ورقم بروفايل من 1 إلى 5.")
            pin = request.form.get("pin", "").strip()
            if pin:
                from werkzeug.security import generate_password_hash
                pin = generate_password_hash(pin)
            db.session.add(NetflixProfile(account_label=label[:120], profile_number=number, pin_hash=pin or None))
            message = "تمت إضافة بروفايل Netflix."
        else:
            raise ValueError("إجراء غير صالح.")
        db.session.commit()
        flash(message, "success")
    except (IntegrityError, TypeError, ValueError) as exc:
        db.session.rollback()
        flash("هذا السجل موجود بالفعل." if isinstance(exc, IntegrityError) else str(exc), "danger")
    return redirect(url_for("admin.features_dashboard"))


@admin_bp.route("/features/auctions", methods=["GET", "POST"])
@admin_required
def auction_admin():
    if request.method == "POST":
        data = _data()
        try:
            title = str(data.get("title", "")).strip()
            minutes = int(data.get("duration_minutes", 15))
            if not title or not 1 <= minutes <= 10080:
                raise ValueError("اسم المزاد أو مدته غير صالح")
            auction = Auction(title=title,
                              description=str(data.get("description", "")).strip() or None,
                              start_price=money(data.get("start_price")),
                              bid_step=money(data.get("bid_step")),
                              ends_at=datetime.utcnow() + timedelta(minutes=minutes),
                              delivery_text=str(data.get("delivery_text", "")).strip() or None)
            db.session.add(auction)
            db.session.commit()
            return jsonify({"status": True, "auction_id": auction.id}), 201
        except (TypeError, ValueError) as exc:
            db.session.rollback()
            return jsonify({"status": False, "message": str(exc)}), 400
    return jsonify([{"id": a.id, "title": a.title, "status": a.status,
                     "ends_at": a.ends_at.isoformat(), "bids": a.bids.count()}
                    for a in Auction.query.order_by(Auction.created_at.desc()).all()])


@admin_bp.route("/features/auctions/<int:auction_id>/decision", methods=["POST"])
@admin_required
def auction_decision(auction_id):
    auction = Auction.query.get_or_404(auction_id)
    action = _data().get("action")
    if action == "cancel":
        auction.status = "cancelled"
        db.session.commit()
        if not request.is_json:
            flash("تم إلغاء المزاد.", "success")
            return redirect(url_for("admin.features_dashboard"))
        return jsonify({"status": True, "decision": "cancelled"})
    if action != "sell":
        return jsonify({"status": False, "message": "قرار غير صالح"}), 400
    try:
        bid = finalize_auction(auction.id)
    except ValueError as exc:
        db.session.rollback()
        if not request.is_json:
            flash(str(exc), "danger")
            return redirect(url_for("admin.features_dashboard"))
        return jsonify({"status": False, "message": str(exc)}), 409
    if not request.is_json:
        flash("تم حسم المزاد." if bid else "تم إلغاء المزاد لعدم وجود مزايدات.", "success")
        return redirect(url_for("admin.features_dashboard"))
    return jsonify({"status": True, "decision": "sold" if bid else "cancelled",
                    "winner": bid.user.username if bid else None,
                    "amount": bid.amount if bid else None})


@admin_bp.route("/features/group-buys", methods=["GET", "POST"])
@admin_required
def group_buy_admin():
    if request.method == "POST":
        data = _data()
        try:
            product = Product.query.get(int(data.get("product_id")))
            target = int(data.get("target_count"))
            hours = int(data.get("duration_hours", 24))
            if (not product or product.product_type == PRODUCT_TYPE_SUBSCRIPTION
                    or not 2 <= target <= 100000 or not 1 <= hours <= 720):
                raise ValueError("بيانات الشراء الجماعي غير صالحة")
            group = GroupBuy(product_id=product.id, target_count=target,
                             deal_price=money(data.get("deal_price")),
                             ends_at=datetime.utcnow() + timedelta(hours=hours))
            db.session.add(group)
            db.session.commit()
            return jsonify({"status": True, "group_id": group.id}), 201
        except (TypeError, ValueError) as exc:
            db.session.rollback()
            return jsonify({"status": False, "message": str(exc)}), 400
    return jsonify([{"id": g.id, "product_id": g.product_id, "status": g.status,
                     "participants": g.participants.count(), "target": g.target_count,
                     "ends_at": g.ends_at.isoformat()}
                    for g in GroupBuy.query.order_by(GroupBuy.created_at.desc()).all()])


@admin_bp.route("/features/provider-sessions", methods=["GET", "POST"])
@admin_required
def provider_sessions_admin():
    if request.method == "POST":
        data = _data()
        provider = str(data.get("provider", "")).strip().lower()
        encrypted = str(data.get("encrypted_value", "")).strip()
        if provider not in {"midasbuy", "shop2game", "garena"} or not encrypted:
            return jsonify({"status": False, "message": "مزود أو قيمة مشفرة غير صالحة"}), 400
        row = ProviderSession.query.filter_by(provider=provider).first()
        if row is None:
            row = ProviderSession(provider=provider)
            db.session.add(row)
        row.encrypted_value, row.status = encrypted, "configured"
        # Optional explicit expiration (ISO date or datetime)
        expires_raw = data.get("expires_at")
        if expires_raw:
            try:
                from datetime import datetime as _dt
                cleaned = str(expires_raw).strip().replace("T", " ")
                row.expires_at = _dt.fromisoformat(cleaned)
            except Exception:
                return jsonify({"status": False, "message": "تاريخ انتهاء غير صالح"}), 400
        row.refresh_status()
        db.session.commit()
        return jsonify({"status": True, "provider": provider,
                        "session_status": row.status,
                        "is_expired": row.is_expired})
    # GET — refresh expiration status then return rich snapshot.
    from ...services.features import refresh_provider_sessions
    refresh_provider_sessions()
    return jsonify([{
        "provider": p.provider,
        "status": p.status,
        "is_expired": p.is_expired,
        "is_usable": p.is_usable,
        "expires_at": p.expires_at.isoformat() if p.expires_at else None,
        "updated_at": p.updated_at.isoformat() if p.updated_at else None,
    } for p in ProviderSession.query.order_by(ProviderSession.provider).all()])


@admin_bp.route("/features/netflix/profiles", methods=["GET", "POST"])
@admin_required
def netflix_profiles_admin():
    if request.method == "POST":
        data = _data()
        try:
            label = str(data.get("account_label", "")).strip()
            number = int(data.get("profile_number"))
            if not label or number not in range(1, 6):
                raise ValueError("الحساب ورقم البروفايل (1-5) مطلوبان")
            # Enforce Netflix's 5-profiles-per-account limit before any DB writes.
            existing_count = NetflixProfile.query.filter_by(account_label=label).count()
            existing_same_slot = NetflixProfile.query.filter_by(
                account_label=label, profile_number=number
            ).first()
            if not existing_same_slot and existing_count >= 5:
                raise ValueError("لا يمكن إضافة أكثر من 5 بروفايلات لنفس الحساب")
            from ...services.features import (MAX_NETFLIX_PROFILES, hash_profile_pin,
                                              netflix_profile_slots)
            pin = data.get("pin")
            pin_hash = hash_profile_pin(pin) if pin else None
            expiration_date = data.get("expiration_date")
            expiration_date = (datetime.strptime(str(expiration_date), "%Y-%m-%d").date()
                               if expiration_date else parse_subscription_expiration(data.get("expiration_text")))
            status = str(data.get("status", "active")).strip().lower()
            if status not in {"active", "available", "maintenance", "disabled"}:
                raise ValueError("حالة البروفايل غير صالحة")
            # Support both create and update semantics in a single endpoint.
            profile_id = data.get("profile_id")
            if profile_id:
                profile = NetflixProfile.query.get(int(profile_id))
                if not profile or profile.account_label != label or profile.profile_number != number:
                    raise ValueError("بروفايل غير موجود أو لا يطابق البيانات")
                if pin_hash:
                    profile.pin_hash = pin_hash
                elif pin in ("", None) and "pin" in data:
                    profile.pin_hash = None
                if expiration_date is not None:
                    profile.expiration_date = expiration_date
                profile.status = status
            else:
                profile = NetflixProfile(account_label=label, profile_number=number, pin_hash=pin_hash,
                                         expiration_date=expiration_date, status=status)
                db.session.add(profile)
            db.session.commit()
            return jsonify({"status": True, "profile_id": profile.id,
                            "slots": [
                                {"number": idx + 1,
                                 "filled": slot is not None,
                                 "id": slot.id if slot else None}
                                for idx, slot in enumerate(netflix_profile_slots(label))
                            ],
                            "max_profiles": MAX_NETFLIX_PROFILES}), 201
        except (IntegrityError, TypeError, ValueError) as exc:
            db.session.rollback()
            message = "الحساب ورقم البروفايل موجودان بالفعل" if isinstance(exc, IntegrityError) else str(exc)
            return jsonify({"status": False, "message": message}), 400
    from ...services.features import netflix_profile_slots
    profiles = NetflixProfile.query.order_by(NetflixProfile.account_label,
                                             NetflixProfile.profile_number).all()
    payload = []
    for p in profiles:
        slots = netflix_profile_slots(p.account_label)
        payload.append({
            "id": p.id,
            "account_label": p.account_label,
            "profile_number": p.profile_number,
            "status": p.status,
            "has_pin": bool(p.pin_hash),
            "expiration_date": p.expiration_date.isoformat() if p.expiration_date else None,
            "days_remaining": subscription_days_remaining(p.expiration_date),
            "devices": p.devices.count(),
            "slots": [{"number": idx + 1, "filled": slot is not None,
                       "id": slot.id if slot else None}
                      for idx, slot in enumerate(slots)],
        })
    return jsonify(payload)


@admin_bp.route("/features/netflix/expiration-preview", methods=["POST"])
@admin_required
def netflix_expiration_preview_admin():
    """Parse an explicit date without retaining the submitted administrative text."""
    expiration = parse_subscription_expiration(_data().get("text"))
    if not expiration:
        return jsonify({"status": False, "message": "لم يتم العثور على تاريخ بصيغة YYYY-MM-DD"}), 400
    return jsonify({"status": True, "expiration_date": expiration.isoformat(),
                    "days_remaining": subscription_days_remaining(expiration)})


@admin_bp.route("/features/netflix/assignments", methods=["GET", "POST"])
@admin_required
def netflix_assignments_admin():
    if request.method == "POST":
        data = _data()
        try:
            profile_id = int(data.get("profile_id"))
            user_id = int(data.get("user_id"))
            max_devices = int(data.get("max_devices", 1))
            expires_at = data.get("expires_at")
            expires_at = datetime.fromisoformat(str(expires_at)) if expires_at else None
            if expires_at and expires_at <= datetime.utcnow():
                raise ValueError("تاريخ انتهاء الوصول يجب أن يكون في المستقبل")
            if not User.query.get(user_id):
                raise ValueError("المستخدم غير موجود")
            row = assign_netflix_profile(profile_id, user_id, expires_at, max_devices)
            return jsonify({"status": True, "assignment_id": row.id}), 201
        except IntegrityError:
            db.session.rollback()
            return jsonify({"status": False, "message": "البروفايل مخصص حالياً لطلب آخر"}), 409
        except (TypeError, ValueError) as exc:
            db.session.rollback()
            return jsonify({"status": False, "message": str(exc)}), 400
    expire_profile_assignments()
    db.session.commit()
    rows = NetflixProfileAssignment.query.order_by(NetflixProfileAssignment.starts_at.desc()).all()
    return jsonify([{
        "id": row.id, "profile_id": row.profile_id, "user_id": row.user_id,
        "status": row.status, "max_devices": row.max_devices,
        "starts_at": row.starts_at.isoformat(),
        "expires_at": row.expires_at.isoformat() if row.expires_at else None,
        "ended_at": row.ended_at.isoformat() if row.ended_at else None,
    } for row in rows])


@admin_bp.route("/features/netflix/assignments/<int:assignment_id>/end", methods=["POST"])
@admin_required
def netflix_assignment_end_admin(assignment_id):
    try:
        row = end_netflix_profile_assignment(assignment_id)
    except ValueError as exc:
        db.session.rollback()
        return jsonify({"status": False, "message": str(exc)}), 404
    return jsonify({"status": True, "assignment_id": row.id, "assignment_status": row.status})


@admin_bp.route("/features/domain-email/batches", methods=["GET", "POST"])
@admin_required
def domain_email_batches_admin():
    if request.method == "POST":
        try:
            batch, rows = generate_verification_batch(10)
            sent = send_verification_messages(rows)
            return jsonify({
                "status": True, "batch_id": batch.batch_id,
                "delivery_status": "sent" if sent else "queued",
                "addresses": [row.address for row in rows],
            }), 201
        except (OSError, ValueError) as exc:
            db.session.rollback()
            return jsonify({"status": False, "message": str(exc)}), 400
    batches = DomainEmailVerificationBatch.query.order_by(
        DomainEmailVerificationBatch.created_at.desc()).all()
    return jsonify([{
        "batch_id": batch.batch_id, "created_at": batch.created_at.isoformat(),
        "addresses": [{"address": row.address, "status": row.status,
                       "verified_at": row.verified_at.isoformat() if row.verified_at else None}
                      for row in DomainEmailAddress.query.filter_by(batch_id=batch.batch_id)
                      .order_by(DomainEmailAddress.address).all()],
    } for batch in batches])
"""
=============================================================
  admin/settings.py — إعدادات النظام
=============================================================
"""

from flask import render_template, redirect, url_for, request, flash
from . import admin_bp, admin_required


@admin_bp.route("/settings")
@admin_required
def settings():
    return render_template("admin/settings.html")


@admin_bp.route("/settings/save", methods=["POST"])
@admin_required
def settings_save():
    # Placeholder – يمكن توسيعها لاحقاً
    flash("تم حفظ الإعدادات.", "success")
    return redirect(url_for("admin.settings"))

"""
=============================================================
  admin/staff.py — إدارة مشرفي البوت
=============================================================
"""

from flask import render_template, redirect, url_for, request, flash
from . import admin_bp, admin_required
from app.extensions import db
from app.models.admin_staff import AdminStaff


@admin_bp.route("/staff")
@admin_required
def staff():
    members = AdminStaff.query.order_by(AdminStaff.added_at.desc()).all()
    return render_template("admin/staff/list.html", staff=members)


@admin_bp.route("/staff/new", methods=["POST"])
@admin_required
def staff_new():
    tg_id   = request.form.get("telegram_id", "").strip()
    tg_user = request.form.get("telegram_username", "").strip().lstrip("@")
    name    = request.form.get("display_name", "").strip()

    if not tg_id or not tg_user:
        flash("يجب إدخال معرّف ورقم تيليجرام.", "danger")
        return redirect(url_for("admin.staff"))

    try:
        tg_id_value = int(tg_id)
    except ValueError:
        flash("معرّف تيليجرام يجب أن يكون رقماً.", "danger")
        return redirect(url_for("admin.staff"))

    existing = AdminStaff.query.filter_by(telegram_id=tg_id_value).first()
    if existing:
        flash("هذا المشرف مسجّل مسبقاً.", "warning")
        return redirect(url_for("admin.staff"))

    member = AdminStaff(
        telegram_id=tg_id_value,
        username=tg_user,
        full_name=name or tg_user,
        is_active=True,
    )
    db.session.add(member)
    db.session.commit()
    flash("تمت إضافة المشرف بنجاح.", "success")
    return redirect(url_for("admin.staff"))


@admin_bp.route("/staff/<int:staff_id>/toggle", methods=["POST"])
@admin_required
def staff_toggle(staff_id):
    member = AdminStaff.query.get_or_404(staff_id)
    member.is_active = not member.is_active
    db.session.commit()
    flash("تم تحديث حالة المشرف.", "success")
    return redirect(url_for("admin.staff"))


@admin_bp.route("/staff/<int:staff_id>/delete", methods=["POST"])
@admin_required
def staff_delete(staff_id):
    member = AdminStaff.query.get_or_404(staff_id)
    db.session.delete(member)
    db.session.commit()
    flash("تم حذف المشرف.", "warning")
    return redirect(url_for("admin.staff"))

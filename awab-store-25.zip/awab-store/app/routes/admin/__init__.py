"""
=============================================================
  app/routes/admin/__init__.py
  لوحة الإدارة — Blueprint مع المصادقة بالجلسة
=============================================================
"""

from flask import Blueprint, session, redirect, url_for, flash
from functools import wraps

admin_bp = Blueprint(
    "admin",
    __name__,
    url_prefix="/admin",
    template_folder="../../templates/admin",
)


def admin_required(f):
    """Decorator: يتحقق من تسجيل دخول المشرف عبر الجلسة"""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("admin_logged_in"):
            flash("يجب تسجيل الدخول للوصول إلى لوحة التحكم.", "danger")
            return redirect(url_for("admin.login"))
        return f(*args, **kwargs)
    return decorated


# ─── استيراد مسارات الفروع ───
from . import auth          # noqa: E402  (login/logout)
from . import dashboard     # noqa: E402
from . import products      # noqa: E402
from . import inventory     # noqa: E402
from . import orders        # noqa: E402
from . import users         # noqa: E402
from . import staff         # noqa: E402
from . import notifications # noqa: E402
from . import settings      # noqa: E402
from . import reports       # noqa: E402
from . import features      # noqa: E402

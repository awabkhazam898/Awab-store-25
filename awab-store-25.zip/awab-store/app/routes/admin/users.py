"""
=============================================================
  admin/users.py — إدارة المستخدمين
=============================================================
"""

from flask import render_template, redirect, url_for, request, flash, session
from . import admin_bp, admin_required
from app.extensions import db
from app.models.user    import User
from app.models.payment import Transaction, AuditLog


@admin_bp.route("/users")
@admin_required
def users():
    page = request.args.get("page", 1, type=int)
    q    = request.args.get("q", "").strip()
    query = User.query
    if q:
        query = query.filter(
            User.username.ilike(f"%{q}%") | User.email.ilike(f"%{q}%")
        )
    users_page = query.order_by(User.created_at.desc()).paginate(page=page, per_page=20)
    return render_template("admin/users/list.html", users=users_page, q=q, query=q)


@admin_bp.route("/users/new", methods=["GET", "POST"])
@admin_required
def user_new():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        phone = request.form.get("phone", "").strip() or None
        is_admin = request.form.get("is_admin") == "1"

        if not username or not email or len(password) < 6:
            flash("أدخل الاسم والبريد وكلمة مرور لا تقل عن 6 أحرف.", "danger")
        elif User.query.filter((User.username == username) | (User.email == email)).first():
            flash("اسم المستخدم أو البريد مستخدم مسبقاً.", "danger")
        else:
            user = User(username=username, email=email, phone=phone, is_admin=is_admin)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            flash(f"تم إنشاء المستخدم {username}.", "success")
            return redirect(url_for("admin.user_detail", user_id=user.id))
    return render_template("admin/users/form.html", title="إنشاء مستخدم")


@admin_bp.route("/users/<int:user_id>")
@admin_required
def user_detail(user_id):
    user   = User.query.get_or_404(user_id)
    orders = user.orders.order_by(db.text("created_at desc")).limit(20).all() if hasattr(user, "orders") else []
    txns   = Transaction.query.filter_by(user_id=user_id).order_by(Transaction.created_at.desc()).limit(20).all()
    return render_template("admin/users/detail.html", user=user, orders=orders, transactions=txns)


@admin_bp.route("/users/<int:user_id>/balance", methods=["POST"])
@admin_required
def user_balance_adjust(user_id):
    user   = User.query.get_or_404(user_id)
    amount = request.form.get("amount", type=float, default=0)
    reason = request.form.get("reason", "").strip()
    admin_name = session.get("admin_username", "admin")

    if amount == 0:
        flash("أدخل مبلغاً صحيحاً.", "danger")
        return redirect(url_for("admin.user_detail", user_id=user_id))

    old_balance = round(user.balance or 0, 3)
    user.balance = round(old_balance + amount, 3)
    db.session.add(Transaction(
        user_id=user.id,
        amount=amount,
        balance_before=old_balance,
        balance_after=user.balance,
        type="credit" if amount > 0 else "debit",
        note=reason or "تعديل يدوي من الإدارة",
    ))
    log = AuditLog(
        action="balance_adjust",
        target_user_id=user_id,
        performed_by=admin_name,
        data={"amount": amount, "old": old_balance, "new": user.balance,
              "reason": reason or "تعديل يدوي"},
        ip_address=request.remote_addr,
    )
    db.session.add(log)
    db.session.commit()

    action_word = "إضافة" if amount > 0 else "خصم"
    flash(f"تم {action_word} {abs(amount):.3f} د.ل من رصيد {user.username}.", "success")
    return redirect(url_for("admin.user_detail", user_id=user_id))


@admin_bp.route("/users/<int:user_id>/toggle-ban", methods=["POST"])
@admin_required
def user_toggle_ban(user_id):
    user = User.query.get_or_404(user_id)
    user.is_banned = not getattr(user, "is_banned", False)
    db.session.add(AuditLog(
        action="user_ban_toggle",
        target_user_id=user.id,
        performed_by=session.get("admin_username", "admin"),
        data={"is_banned": user.is_banned},
        ip_address=request.remote_addr,
    ))
    db.session.commit()
    action = "حظر" if user.is_banned else "رفع الحظر عن"
    flash(f"تم {action} المستخدم {user.username}.", "warning")
    return redirect(url_for("admin.user_detail", user_id=user_id))


@admin_bp.route("/users/<int:user_id>/toggle-active", methods=["POST"])
@admin_required
def user_toggle_active(user_id):
    user = User.query.get_or_404(user_id)
    user.is_active = not user.is_active
    db.session.commit()
    flash(f"تم {'تفعيل' if user.is_active else 'تعطيل'} حساب {user.username}.", "success")
    return redirect(url_for("admin.user_detail", user_id=user.id))

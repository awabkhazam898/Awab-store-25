"""
=============================================================
  admin/auth.py — دخول / خروج المشرف (جلسة)
=============================================================
"""

from flask import request, render_template, redirect, url_for, session, flash
from werkzeug.security import check_password_hash
from . import admin_bp
from config import ADMIN_USERNAME, ADMIN_PASSWORD


@admin_bp.route("/login", methods=["GET", "POST"])
def login():
    if session.get("admin_logged_in"):
        return redirect(url_for("admin.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        # مقارنة بسيطة بالنص العادي أو المشفر
        pw_ok = (password == ADMIN_PASSWORD) or check_password_hash(ADMIN_PASSWORD, password)
        if username == ADMIN_USERNAME and pw_ok:
            session["admin_logged_in"]  = True
            session["admin_username"]   = username
            session.permanent = True
            return redirect(url_for("admin.dashboard"))

        flash("اسم المستخدم أو كلمة المرور غير صحيحة.", "danger")

    return render_template("admin/login.html")


@admin_bp.route("/logout")
def logout():
    session.pop("admin_logged_in", None)
    session.pop("admin_username", None)
    flash("تم تسجيل الخروج بنجاح.", "success")
    return redirect(url_for("admin.login"))

"""
=============================================================
  admin/orders.py — إدارة الطلبات
=============================================================
"""

import json
from datetime import datetime
from flask import render_template, redirect, url_for, request, flash, session
from . import admin_bp, admin_required
from app.extensions import db
from app.models.order       import (
    Order, OrderStatusLog, ORDER_STATUS_PENDING, ORDER_STATUS_ACCEPTED,
    ORDER_STATUS_TRANSFERRED, ORDER_STATUS_COMPLETED, ORDER_STATUS_REJECTED,
    ORDER_STATUS_CANCELLED, ORDER_STATUSES,
)
from app.models.rewards     import RewardPoint, PointValueHistory
from app.models.admin_staff import AdminStaff
from app.utils.telegram     import notify_order_status_change, notify_user_order_update


@admin_bp.route("/orders")
@admin_required
def orders():
    page   = request.args.get("page", 1, type=int)
    status = request.args.get("status", "")
    query  = Order.query
    if status:
        query = query.filter_by(status=status)
    orders_page = query.order_by(Order.created_at.desc()).paginate(page=page, per_page=20)
    return render_template(
        "admin/orders/list.html",
        orders=orders_page,
        status_filter=status,
        ORDER_STATUSES=ORDER_STATUSES,
    )


@admin_bp.route("/orders/<order_number>")
@admin_required
def order_detail(order_number):
    order = Order.query.filter_by(order_number=order_number).first_or_404()
    logs  = OrderStatusLog.query.filter_by(order_id=order.id).order_by(OrderStatusLog.created_at).all()

    # تحليل البيانات المُسلَّمة
    delivered_items = []
    for item in order.items:
        if item.delivered_items:
            try:
                data = json.loads(item.delivered_items)
                delivered_items.append({
                    "item": item,
                    "data": data if isinstance(data, list) else [data],
                })
            except Exception:
                delivered_items.append({"item": item, "data": [item.delivered_items]})

    staff = AdminStaff.query.filter_by(is_active=True).all()
    return render_template(
        "admin/orders/detail.html",
        order=order, logs=logs,
        delivered_items=delivered_items,
        staff=staff,
    )


@admin_bp.route("/orders/<order_number>/action", methods=["POST"])
@admin_required
def order_action(order_number):
    order  = Order.query.filter_by(order_number=order_number).first_or_404()
    action = request.form.get("action", "")
    note   = request.form.get("note", "").strip()
    admin_name = session.get("admin_username", "admin")

    old_status = order.status

    allowed = {
        ORDER_STATUS_PENDING: {ORDER_STATUS_ACCEPTED, ORDER_STATUS_REJECTED, ORDER_STATUS_CANCELLED},
        ORDER_STATUS_ACCEPTED: {ORDER_STATUS_COMPLETED, ORDER_STATUS_TRANSFERRED,
                                ORDER_STATUS_REJECTED},
        ORDER_STATUS_TRANSFERRED: {ORDER_STATUS_ACCEPTED, ORDER_STATUS_REJECTED},
    }

    if action == "accept":
        order.status = ORDER_STATUS_ACCEPTED
        flash("تم قبول الطلب.", "success")

    elif action == "reject":
        order.status = ORDER_STATUS_REJECTED
        flash("تم رفض الطلب وإعادة الرصيد.", "warning")

    elif action == "complete":
        order.status = ORDER_STATUS_COMPLETED
        flash("تم إكمال الطلب.", "success")

    elif action == "transfer":
        to_admin_id = request.form.get("transfer_to", type=int)
        if not to_admin_id:
            flash("اختر مشرفاً للتحويل.", "danger")
            return redirect(url_for("admin.order_detail", order_number=order_number))
        target = AdminStaff.query.get(to_admin_id)
        if target:
            order.status = ORDER_STATUS_TRANSFERRED
            order.assigned_admin_id = target.id
            note = f"تحويل إلى: {target.display_name}"
            flash(f"تم تحويل الطلب إلى {target.display_name}.", "info")
        else:
            flash("المشرف غير موجود.", "danger")
            return redirect(url_for("admin.order_detail", order_number=order_number))

    elif action == "cancel":
        order.status = ORDER_STATUS_CANCELLED
        flash("تم إلغاء الطلب.", "warning")

    else:
        flash("إجراء غير معروف.", "danger")
        return redirect(url_for("admin.order_detail", order_number=order_number))

    new_status = order.status
    if new_status not in allowed.get(old_status, set()):
        flash("لا يمكن تنفيذ هذا الإجراء على حالة الطلب الحالية.", "warning")
        return redirect(url_for("admin.order_detail", order_number=order_number))

    if new_status == ORDER_STATUS_REJECTED:
        _refund_order_once(order, admin_name)
    elif new_status == ORDER_STATUS_COMPLETED:
        order.completed_at = datetime.utcnow()
        _award_admin_points(order, admin_name)

    order.log_status_change(old_status, new_status, note=note or admin_name)
    db.session.commit()

    # إشعار المستخدم عبر تيليجرام
    try:
        notify_order_status_change(order, old_status, admin_name, note)
    except Exception:
        pass

    return redirect(url_for("admin.order_detail", order_number=order_number))


def _refund_order_once(order, admin_name: str):
    """إرجاع قيمة الطلب مرة واحدة فقط عند الرفض."""
    from app.models.payment import AuditLog
    marker = AuditLog.query.filter_by(action="order_refund", target_user_id=order.user_id).all()
    if any(log.data.get("order_id") == order.id for log in marker):
        return
    if order.user and order.total_amount:
        order.user.add_balance(
            order.total_amount,
            note=f"استرداد الطلب {order.order_number}",
            performed_by=admin_name,
            reference_id=order.order_number,
            transaction_type="refund",
        )
        db.session.add(AuditLog(
            action="order_refund", performed_by=admin_name,
            target_user_id=order.user_id,
            data={"order_id": order.id, "order_number": order.order_number},
        ))


def _award_admin_points(order, admin_name: str):
    """منح نقاط للمشرف عند إكمال الطلب"""
    staff = AdminStaff.query.filter(
        (AdminStaff.username == admin_name) |
        (AdminStaff.full_name == admin_name)
    ).first()
    if not staff:
        return
    pv = PointValueHistory.query.order_by(PointValueHistory.id.desc()).first()
    point_value = pv.value_usd if pv else 0.05

    import datetime
    now = datetime.datetime.utcnow()
    if RewardPoint.query.filter_by(order_id=order.id).first():
        return
    rp = RewardPoint(
        admin_id=staff.id,
        order_id=order.id,
        reward_value_at_award=point_value,
        month=now.month,
        year=now.year,
    )
    db.session.add(rp)

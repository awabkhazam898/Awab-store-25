"""
=============================================================
  admin/reports.py — التقارير الشهرية ونقاط المشرفين
=============================================================
"""

import datetime
from flask import render_template, redirect, url_for, request, flash
from . import admin_bp, admin_required
from app.extensions import db
from app.models.order       import Order
from app.models.admin_staff import AdminStaff
from app.models.rewards     import RewardPoint, PointValueHistory


@admin_bp.route("/reports")
@admin_required
def reports():
    now   = datetime.datetime.utcnow()
    month = request.args.get("month", now.month, type=int)
    year  = request.args.get("year",  now.year,  type=int)

    # إجمالي الطلبات في الشهر
    from sqlalchemy import extract
    total_orders_month = Order.query.filter(
        extract("month", Order.created_at) == month,
        extract("year",  Order.created_at) == year,
    ).count()

    completed_month = Order.query.filter(
        Order.status == "completed",
        extract("month", Order.created_at) == month,
        extract("year",  Order.created_at) == year,
    ).count()

    # نقاط المشرفين
    pv = PointValueHistory.query.order_by(PointValueHistory.id.desc()).first()
    point_value = pv.value_usd if pv else 0.05

    all_staff  = AdminStaff.query.filter_by(is_active=True).all()
    admin_stats = []
    for staff in all_staff:
        pts = RewardPoint.query.filter_by(
            admin_id=staff.id, month=month, year=year
        ).all()
        total_pts  = len(pts)
        completed  = sum(1 for p in pts if not p.is_manual_adjustment)
        manual     = sum(1 for p in pts if p.is_manual_adjustment)
        admin_stats.append({
            "admin":     staff,
            "points":    total_pts,
            "completed": completed,
            "manual":    manual,
            "value_usd": total_pts * point_value,
        })

    admin_stats.sort(key=lambda x: x["points"], reverse=True)

    months = list(range(1, 13))
    return render_template(
        "admin/reports.html",
        total_orders_month=total_orders_month,
        completed_month=completed_month,
        admin_stats=admin_stats,
        point_value=point_value,
        month=month, year=year,
        months=months,
        current_year=now.year,
    )


@admin_bp.route("/reports/set-point-value", methods=["POST"])
@admin_required
def set_point_value():
    new_val = request.form.get("point_value", type=float)
    if not new_val or new_val <= 0:
        flash("أدخل قيمة صحيحة أكبر من صفر.", "danger")
    else:
        pv = PointValueHistory(value_usd=new_val, changed_by="admin")
        db.session.add(pv)
        db.session.commit()
        flash(f"تم تحديث قيمة النقطة إلى ${new_val:.4f}.", "success")
    return redirect(url_for("admin.reports"))

"""
=============================================================
  app/routes/store.py — مسارات واجهة المتجر الرئيسية
  الصفحة الرئيسية، الفئات، تفاصيل المنتجات، البحث
=============================================================
"""

from flask import Blueprint, render_template, request, redirect, url_for, abort
from ..models.product import Category, Product, PRODUCT_TYPE_GIFT_CARD, PRODUCT_TYPE_ACCOUNT, PRODUCT_TYPE_SUBSCRIPTION
from ..extensions import db

store_bp = Blueprint("store", __name__)


@store_bp.route("/")
def index():
    """الصفحة الرئيسية للمتجر"""
    categories  = Category.query.filter_by(is_active=True).order_by(Category.sort_order).all()
    featured    = Product.query.filter_by(is_active=True, is_featured=True).order_by(Product.sort_order).limit(8).all()
    new_products= Product.query.filter_by(is_active=True).order_by(Product.created_at.desc()).limit(6).all()
    return render_template("store/index.html",
                           categories=categories,
                           featured=featured,
                           new_products=new_products)


@store_bp.route("/category/<slug>")
def category(slug):
    """صفحة فئة المنتجات"""
    cat      = Category.query.filter_by(slug=slug, is_active=True).first_or_404()
    page     = request.args.get("page", 1, type=int)
    products = (Product.query
                .filter_by(category_id=cat.id, is_active=True)
                .order_by(Product.sort_order, Product.created_at.desc())
                .paginate(page=page, per_page=12, error_out=False))
    return render_template("store/category.html", category=cat, products=products)


@store_bp.route("/product/<slug>")
def product(slug):
    """صفحة تفاصيل المنتج"""
    prod = Product.query.filter_by(slug=slug, is_active=True).first_or_404()
    fields = prod.fields.all()
    return render_template("store/product.html", product=prod, fields=fields)


@store_bp.route("/search")
def search():
    """البحث في المنتجات"""
    q        = request.args.get("q", "").strip()
    page     = request.args.get("page", 1, type=int)
    products = db.session.query(Product)
    if q:
        products = products.filter(
            Product.name.ilike(f"%{q}%") | Product.description.ilike(f"%{q}%")
        ).filter_by(is_active=True)
    else:
        products = products.filter_by(is_active=True)
    products = products.order_by(Product.sort_order).paginate(page=page, per_page=12, error_out=False)
    return render_template("store/search.html", products=products, query=q)

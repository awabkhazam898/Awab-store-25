"""
=============================================================
  app/routes/cart.py — مسارات السلة والدفع
  إضافة / حذف / تعديل المنتجات وإتمام الشراء
=============================================================
"""

import json
import uuid
from flask import (Blueprint, render_template, redirect, url_for,
                   flash, request, session, jsonify)
from flask_login import login_required, current_user

from ..extensions import db
from ..models.product import Product, PRODUCT_TYPE_SUBSCRIPTION, PRODUCT_TYPE_GIFT_CARD, PRODUCT_TYPE_ACCOUNT
from ..models.inventory import InventoryItem
from ..models.order import Order, OrderItem, OrderFieldValue, generate_order_id, ORDER_STATUS_PENDING
from ..utils.telegram import notify_admins_new_order

cart_bp = Blueprint("cart", __name__)


def get_cart() -> dict:
    return session.get("cart", {})

def save_cart(cart: dict) -> None:
    session["cart"] = cart
    session.modified = True


@cart_bp.route("/")
@login_required
def view_cart():
    cart = get_cart()
    items = []
    total = 0.0
    for product_id, qty in cart.items():
        prod = Product.query.get(int(product_id))
        if prod and prod.is_active:
            subtotal = prod.price * qty
            total += subtotal
            items.append({"product": prod, "quantity": qty, "subtotal": subtotal})
    return render_template("cart/cart.html", items=items, total=total)


@cart_bp.route("/add/<int:product_id>", methods=["POST"])
@login_required
def add(product_id):
    prod = Product.query.get_or_404(product_id)
    if not prod.is_active:
        flash("هذا المنتج غير متاح حالياً.", "warning")
        return redirect(url_for("store.product", slug=prod.slug))

    qty = int(request.form.get("quantity", 1))
    cart = get_cart()
    key = str(product_id)
    cart[key] = cart.get(key, 0) + qty
    save_cart(cart)
    flash(f"تمت إضافة «{prod.name}» إلى السلة.", "success")
    return redirect(url_for("cart.view_cart"))


@cart_bp.route("/remove/<int:product_id>", methods=["POST"])
@login_required
def remove(product_id):
    cart = get_cart()
    cart.pop(str(product_id), None)
    save_cart(cart)
    return redirect(url_for("cart.view_cart"))


@cart_bp.route("/update", methods=["POST"])
@login_required
def update():
    cart = get_cart()
    for key, value in request.form.items():
        if key.startswith("qty_"):
            product_id = key[4:]
            try:
                qty = int(value)
                if qty <= 0:
                    cart.pop(product_id, None)
                else:
                    cart[product_id] = qty
            except ValueError:
                pass
    save_cart(cart)
    flash("تم تحديث السلة.", "success")
    return redirect(url_for("cart.view_cart"))


@cart_bp.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    """صفحة تأكيد الطلب"""
    cart = get_cart()
    if not cart:
        flash("السلة فارغة.", "warning")
        return redirect(url_for("store.index"))

    items_data = []
    total = 0.0
    has_subscription = False
    subscription_fields = {}  # {product_id: [fields]}

    for product_id, qty in cart.items():
        prod = Product.query.get(int(product_id))
        if not prod:
            continue
        if prod.product_type == PRODUCT_TYPE_SUBSCRIPTION:
            has_subscription = True
            subscription_fields[str(product_id)] = prod.fields.all()
        subtotal = prod.price * qty
        total += subtotal
        items_data.append({"product": prod, "quantity": qty, "subtotal": subtotal})

    if request.method == "POST":
        # التحقق من الرصيد
        if current_user.balance < total:
            flash(f"رصيدك غير كافٍ. رصيدك الحالي: {current_user.balance:.2f} LYD، المطلوب: {total:.2f} LYD.", "danger")
            return redirect(url_for("cart.checkout"))

        # Idempotency Key لمنع التكرار
        idem_key = request.form.get("idempotency_key") or str(uuid.uuid4())
        existing = Order.query.filter_by(idempotency_key=idem_key).first()
        if existing:
            session.pop("cart", None)
            return redirect(url_for("orders.detail", order_number=existing.order_number))

        try:
            # إنشاء الطلب داخل Transaction
            order = Order(
                user_id=current_user.id,
                total_amount=total,
                status=ORDER_STATUS_PENDING,
                idempotency_key=idem_key,
            )
            db.session.add(order)
            db.session.flush()  # نحتاج order.id

            delivered_all = True
            for item_d in items_data:
                prod = item_d["product"]
                qty  = item_d["quantity"]
                order_item = OrderItem(
                    order_id=order.id,
                    product_id=prod.id,
                    quantity=qty,
                    unit_price=prod.price,
                    total_price=prod.price * qty,
                )
                db.session.add(order_item)

                if prod.product_type in (PRODUCT_TYPE_GIFT_CARD, PRODUCT_TYPE_ACCOUNT):
                    # جلب الأكواد/الحسابات من المخزون
                    items_inv = (InventoryItem.query
                                 .filter_by(product_id=prod.id, is_sold=False)
                                 .with_for_update()
                                 .limit(qty)
                                 .all())
                    if len(items_inv) < qty:
                        db.session.rollback()
                        flash(f"المخزون غير كافٍ للمنتج «{prod.name}».", "danger")
                        return redirect(url_for("cart.checkout"))
                    delivered = []
                    for inv in items_inv:
                        inv.mark_sold(order.id)
                        delivered.append(inv.delivery_text)
                    order_item.delivered_items = json.dumps(delivered, ensure_ascii=False)

                elif prod.product_type == PRODUCT_TYPE_SUBSCRIPTION:
                    # حفظ بيانات الحساب المُدخلة
                    for field in prod.fields.all():
                        field_val = request.form.get(f"field_{prod.id}_{field.name}", "").strip()
                        if field.is_required and not field_val:
                            db.session.rollback()
                            flash(f"يرجى إدخال {field.label} للمنتج «{prod.name}».", "danger")
                            return redirect(url_for("cart.checkout"))
                        fv = OrderFieldValue(
                            order_id=order.id,
                            field_name=field.name,
                            field_label=field.label,
                            value=field_val,
                        )
                        db.session.add(fv)

            # خصم الرصيد
            if not current_user.deduct_balance(total, note=f"طلب {order.order_number}"):
                db.session.rollback()
                flash("فشل في خصم الرصيد. يرجى المحاولة مجدداً.", "danger")
                return redirect(url_for("cart.checkout"))

            # تحديث حالة الطلبات التلقائية
            if not has_subscription:
                order.status = "completed"

            db.session.commit()

            # إرسال إشعار تيليجرام لطلبات الاشتراك
            if has_subscription:
                try:
                    notify_admins_new_order(order)
                except Exception:
                    pass  # عدم إيقاف الطلب بسبب خطأ في تيليجرام

            session.pop("cart", None)
            flash("تم إنشاء طلبك بنجاح!", "success")
            return redirect(url_for("orders.detail", order_number=order.order_number))

        except Exception as e:
            db.session.rollback()
            flash("حدث خطأ أثناء معالجة الطلب. يرجى المحاولة مجدداً.", "danger")
            return redirect(url_for("cart.checkout"))

    idem_key = str(uuid.uuid4())
    return render_template("cart/checkout.html",
                           items=items_data,
                           total=total,
                           has_subscription=has_subscription,
                           subscription_fields=subscription_fields,
                           idempotency_key=idem_key)

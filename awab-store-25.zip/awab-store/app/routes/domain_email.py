"""Signed inbound events for catch-all delivery verification."""
import hashlib
import hmac
import time
from datetime import datetime

from flask import Blueprint, current_app, jsonify, request
from sqlalchemy.exc import IntegrityError

from ..extensions import csrf, db
from ..models.features import DomainEmailAddress, DomainEmailEvent


domain_email_bp = Blueprint("domain_email", __name__)


@domain_email_bp.route("/webhook", methods=["POST"])
@csrf.exempt
def webhook():
    timestamp = request.headers.get("X-Webhook-Timestamp", "")
    signature = request.headers.get("X-Webhook-Signature", "")
    try:
        timestamp_value = int(timestamp)
    except ValueError:
        return jsonify({"error": "invalid_timestamp"}), 401
    if abs(int(time.time()) - timestamp_value) > 300:
        return jsonify({"error": "expired_signature"}), 401
    configured_secret = current_app.config["DOMAIN_EMAIL_WEBHOOK_SECRET"]
    if not configured_secret:
        return jsonify({"error": "webhook_not_configured"}), 503
    secret = configured_secret.encode("utf-8")
    expected = hmac.new(secret, timestamp.encode("ascii") + b"." + request.get_data(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(signature, expected):
        return jsonify({"error": "unauthorized"}), 401

    data = request.get_json(silent=True) or {}
    event_id = str(data.get("event_id", "")).strip()[:160]
    address = str(data.get("recipient", "")).strip().lower()[:254]
    event_type = str(data.get("event_type", "delivered")).strip().lower()[:40]
    if not event_id or not address or event_type not in {"accepted", "delivered"}:
        return jsonify({"error": "invalid_event"}), 400
    row = DomainEmailAddress.query.filter_by(address=address).first()
    if row is None:
        return jsonify({"status": "ignored"}), 202
    try:
        db.session.add(DomainEmailEvent(event_id=event_id, address=address, event_type=event_type))
        row.status = "verified"
        row.verified_at = datetime.utcnow()
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return jsonify({"status": "duplicate"})
    return jsonify({"status": "verified", "address": address})
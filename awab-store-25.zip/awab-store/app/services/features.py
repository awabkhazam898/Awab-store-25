"""Transactional business operations for optional store features."""
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
import hashlib
import hmac
import re
import secrets

from ..extensions import db
from ..models.features import (Auction, AuctionBid, GroupBuy, GroupBuyParticipant,
                               NetflixAccess, NetflixDevice, NetflixProfile,
                               NetflixProfileAssignment, ProviderSession)
from ..models.inventory import InventoryItem
from ..models.user import User


def money(value):
    try:
        amount = Decimal(str(value)).quantize(Decimal("0.01"))
    except (InvalidOperation, TypeError):
        raise ValueError("قيمة مالية غير صحيحة")
    if amount <= 0 or amount > Decimal("1000000"):
        raise ValueError("القيمة المالية خارج النطاق المسموح")
    return float(amount)


def make_link_token():
    token = secrets.token_urlsafe(32)
    return token, hashlib.sha256(token.encode()).hexdigest()


def valid_link_token(link, token):
    return (link and link.token_hash and token and
            hmac.compare_digest(link.token_hash, hashlib.sha256(token.encode()).hexdigest()) and
            link.token_expires_at and link.token_expires_at > datetime.utcnow())


def place_bid(auction_id, user_id, telegram_id=None):
    auction = Auction.query.filter_by(id=auction_id).with_for_update().first()
    user = User.query.filter_by(id=user_id).with_for_update().first()
    if not auction or not user or auction.status != "active" or auction.ends_at <= datetime.utcnow():
        raise ValueError("انتهى المزاد أو لم يعد متاحاً")
    highest = auction.bids.order_by(AuctionBid.amount.desc(), AuctionBid.created_at.asc()).first()
    minimum = money((highest.amount + auction.bid_step) if highest else auction.start_price)
    if user.balance < minimum:
        raise ValueError(f"رصيدك ({user.balance:.2f}) لا يكفي للمزايدة")
    bid = AuctionBid(auction_id=auction.id, user_id=user.id, amount=minimum, telegram_id=telegram_id)
    db.session.add(bid)
    db.session.commit()
    return bid


def finalize_auction(auction_id):
    auction = Auction.query.filter_by(id=auction_id).with_for_update().first()
    if not auction or auction.status != "active":
        raise ValueError("المزاد اتخذ قراراً مسبقاً")
    bid = auction.bids.order_by(AuctionBid.amount.desc(), AuctionBid.created_at.asc()).first()
    if not bid:
        auction.status = "cancelled"
        db.session.commit()
        return None
    winner = User.query.filter_by(id=bid.user_id).with_for_update().first()
    if not winner or not winner.deduct_balance(bid.amount, f"شراء المزاد #{auction.id}"):
        raise ValueError("رصيد الفائز لم يعد كافياً")
    auction.status = "sold"
    auction.winner_user_id = bid.user_id
    auction.winning_amount = bid.amount
    db.session.commit()
    return bid


def _refund_group(participants, group_id):
    for participant in participants:
        if participant.status == "joined":
            participant.user.add_balance(participant.amount_paid, f"استرداد العرض الجماعي #{group_id}")
            participant.status = "refunded"


def complete_group_buy(group_id):
    group = GroupBuy.query.filter_by(id=group_id).with_for_update().first()
    if not group or group.status != "open":
        return group.status if group else "missing"
    if group.target_count <= 0:
        # Defensive: never unlock with zero target — mark expired and refund anyone who joined.
        participants = group.participants.order_by(GroupBuyParticipant.created_at).all()
        _refund_group(participants, group.id)
        group.status = "expired"
        db.session.commit()
        return group.status
    participants = group.participants.order_by(GroupBuyParticipant.created_at).all()
    if len(participants) < group.target_count:
        _refund_group(participants, group.id)
        group.status = "expired"
        db.session.commit()
        return group.status
    stock = (InventoryItem.query.filter_by(product_id=group.product_id, is_sold=False)
             .with_for_update().limit(len(participants)).all())
    if len(stock) < len(participants):
        _refund_group(participants, group.id)
        group.status = "failed"
        db.session.commit()
        return group.status
    for participant, item in zip(participants, stock):
        item.mark_sold(None)
        participant.delivery_text = item.delivery_text
        participant.status = "delivered"
    group.status = "unlocked"
    db.session.commit()
    return group.status


def get_group_buy_summary(group_id):
    """Return a small dict summarizing a group buy for UI / notifications."""
    group = GroupBuy.query.get(group_id)
    if not group:
        return None
    participants = group.participants.order_by(GroupBuyParticipant.created_at).all()
    return {
        "id": group.id,
        "product_name": group.product.name if group.product else "",
        "status": group.status,
        "deal_price": group.deal_price,
        "ends_at": group.ends_at,
        "target_count": group.target_count,
        "joined_count": len(participants),
        "participants": [
            {
                "user_id": p.user_id,
                "username": p.user.username if p.user else None,
                "status": p.status,
                "amount_paid": p.amount_paid,
                "created_at": p.created_at,
            }
            for p in participants
        ],
    }


def join_group_buy(group_id, user_id):
    group = GroupBuy.query.filter_by(id=group_id).with_for_update().first()
    user = User.query.filter_by(id=user_id).with_for_update().first()
    if not group or not user or group.status != "open" or group.ends_at <= datetime.utcnow():
        raise ValueError("انتهت مدة العرض الجماعي")
    if GroupBuyParticipant.query.filter_by(group_buy_id=group.id, user_id=user.id).first():
        raise ValueError("أنت مشترك بالفعل في هذا العرض")
    if not user.deduct_balance(group.deal_price, f"حجز العرض الجماعي #{group.id}"):
        raise ValueError("رصيدك غير كافٍ للاشتراك في العرض")
    participant = GroupBuyParticipant(group_buy_id=group.id, user_id=user.id, amount_paid=group.deal_price)
    db.session.add(participant)
    db.session.flush()
    count = group.participants.count()
    if count >= group.target_count:
        status = complete_group_buy(group.id)
    else:
        status = group.status
        db.session.commit()
    return participant, status, count


def expire_group_buys(now=None):
    now = now or datetime.utcnow()
    group_ids = [row.id for row in GroupBuy.query.filter(GroupBuy.status == "open", GroupBuy.ends_at <= now).all()]
    for group_id in group_ids:
        complete_group_buy(group_id)
    return len(group_ids)


def device_fingerprint_digest(fingerprint, assignment_id=None):
    """Return a stable, non-reversible identifier for a client-provided fingerprint."""
    value = str(fingerprint or "").strip()
    if not 16 <= len(value) <= 128:
        raise ValueError("بصمة الجهاز غير صالحة")
    scope = str(assignment_id or "legacy")
    return hashlib.sha256(f"{scope}:{value}".encode("utf-8")).hexdigest()


def reset_devices(access, fingerprint, ip_address):
    assignment = access if isinstance(access, NetflixProfileAssignment) else None
    profile = access.profile
    digest = device_fingerprint_digest(fingerprint, assignment.id if assignment else None)
    query = NetflixDevice.query.filter_by(profile_id=profile.id, fingerprint=digest)
    if assignment:
        query = query.filter_by(assignment_id=assignment.id)
    else:
        query = query.filter(NetflixDevice.assignment_id.is_(None))
    existing = query.first()
    if existing:
        return existing
    max_devices = access.max_devices
    device_query = NetflixDevice.query.filter_by(profile_id=profile.id)
    if assignment:
        device_query = device_query.filter_by(assignment_id=assignment.id)
    else:
        device_query = device_query.filter(NetflixDevice.assignment_id.is_(None))
    if device_query.count() >= max_devices:
        raise ValueError("تم تجاوز عدد الأجهزة المسموح به")
    device = NetflixDevice(profile_id=profile.id, assignment_id=assignment.id if assignment else None,
                           fingerprint=digest, ip_address=ip_address)
    db.session.add(device)
    db.session.commit()
    return device


def reset_access_devices(access):
    profile = access.profile
    reset_owner = access if isinstance(access, NetflixProfileAssignment) else profile
    if reset_owner.reset_count >= 2:
        raise ValueError("تم استخدام الحد الأقصى لإعادة ضبط الأجهزة")
    device_query = NetflixDevice.query.filter_by(profile_id=profile.id)
    if isinstance(access, NetflixProfileAssignment):
        device_query = device_query.filter_by(assignment_id=access.id)
    else:
        device_query = device_query.filter(NetflixDevice.assignment_id.is_(None))
    device_query.delete(synchronize_session=False)
    reset_owner.reset_count += 1
    reset_owner.reset_window_started = datetime.utcnow()
    db.session.commit()


def active_access_for_user(profile_id, user_id):
    from ..models.features import NetflixProfileAssignment
    expire_profile_assignments()
    assignment = NetflixProfileAssignment.query.filter_by(
        profile_id=profile_id, user_id=user_id, status="active").first()
    if assignment:
        return assignment
    access = NetflixAccess.query.filter_by(profile_id=profile_id, user_id=user_id, is_active=True).first()
    if not access or (access.expires_at and access.expires_at <= datetime.utcnow()):
        return None
    return access


def expire_profile_assignments(now=None):
    from ..models.features import NetflixProfileAssignment
    now = now or datetime.utcnow()
    rows = NetflixProfileAssignment.query.filter(
        NetflixProfileAssignment.status == "active",
        NetflixProfileAssignment.expires_at.isnot(None),
        NetflixProfileAssignment.expires_at <= now,
    ).all()
    for row in rows:
        row.status = "expired"
        row.ended_at = row.expires_at
    if rows:
        db.session.flush()
    return len(rows)


def subscription_days_remaining(expiration, now=None):
    """Return whole remaining calendar days for a date/datetime, never negative."""
    if not expiration:
        return None
    current = now or datetime.utcnow()
    target = expiration.date() if isinstance(expiration, datetime) else expiration
    today = current.date() if isinstance(current, datetime) else current
    return max((target - today).days, 0)


def parse_subscription_expiration(text):
    """Parse explicit ISO dates from trusted admin notes; message content is not persisted."""
    match = re.search(r"\b(20\d{2})[-/](\d{1,2})[-/](\d{1,2})\b", str(text or ""))
    if not match:
        return None
    try:
        return date(int(match.group(1)), int(match.group(2)), int(match.group(3)))
    except ValueError:
        return None


def refresh_provider_sessions():
    """Refresh expiration status on every provider session. Returns count of changed rows."""
    changed = 0
    for session in ProviderSession.query.all():
        previous = session.status
        session.refresh_status()
        if session.status != previous:
            changed += 1
    if changed:
        db.session.commit()
    return changed


def provider_session_status():
    """Return a snapshot of all provider sessions with health flags (no raw credentials)."""
    refresh_provider_sessions()
    return [
        {
            "provider": s.provider,
            "status": s.status,
            "is_expired": s.is_expired,
            "is_usable": s.is_usable,
            "expires_at": s.expires_at.isoformat() if s.expires_at else None,
            "updated_at": s.updated_at.isoformat() if s.updated_at else None,
        }
        for s in ProviderSession.query.order_by(ProviderSession.provider).all()
    ]


# ----------------------------------------------------------------------------
# Netflix PIN + device fingerprint helpers
# ----------------------------------------------------------------------------

# Netflix allows at most 5 profiles per account.
MAX_NETFLIX_PROFILES = 5


def hash_profile_pin(pin: str) -> str:
    """Hash a Netflix profile PIN (4 digits) using werkzeug's pbkdf2."""
    from werkzeug.security import generate_password_hash
    pin = str(pin or "").strip()
    if not 4 <= len(pin) <= 12:
        raise ValueError("يجب أن يكون PIN بين 4 و12 خانة")
    if not pin.isdigit():
        raise ValueError("يجب أن يحتوي PIN على أرقام فقط")
    return generate_password_hash(pin, method="pbkdf2:sha256", salt_length=12)


def verify_profile_pin(profile, pin: str) -> bool:
    """Verify a Netflix profile PIN. Profiles without a PIN hash always pass."""
    if not profile or not getattr(profile, "pin_hash", None):
        return True
    from werkzeug.security import check_password_hash
    return check_password_hash(profile.pin_hash, str(pin or ""))


def set_profile_pin(profile, pin: str):
    """Set or clear the PIN hash on a profile."""
    if pin in (None, ""):
        profile.pin_hash = None
    else:
        profile.pin_hash = hash_profile_pin(pin)
    db.session.commit()
    return profile


def netflix_profile_slots(account_label: str):
    """Return list of 5 slots (filled or empty) for an account to drive UI."""
    label = (account_label or "").strip()
    existing = NetflixProfile.query.filter_by(account_label=label).order_by(
        NetflixProfile.profile_number
    ).all() if label else []
    by_num = {p.profile_number: p for p in existing}
    slots = []
    for n in range(1, MAX_NETFLIX_PROFILES + 1):
        slots.append(by_num.get(n))
    return slots


def validate_device_fingerprint(fingerprint: str) -> str:
    """Normalize and validate a fingerprint string (16-128 chars)."""
    value = str(fingerprint or "").strip()
    if not 16 <= len(value) <= 128:
        raise ValueError("بصمة الجهاز يجب أن تكون بين 16 و128 خانة")
    return value


def assign_netflix_profile(profile_id, user_id, expires_at=None, max_devices=1):
    from ..models.features import NetflixProfileAssignment
    profile = NetflixProfile.query.filter_by(id=profile_id).with_for_update().first()
    if not profile or profile.status not in {"active", "available"}:
        raise ValueError("البروفايل غير متاح للتخصيص")
    if not 1 <= max_devices <= 5:
        raise ValueError("عدد الأجهزة يجب أن يكون بين 1 و5")
    expire_profile_assignments()
    active = NetflixProfileAssignment.query.filter_by(profile_id=profile.id, status="active").first()
    if active:
        raise ValueError("البروفايل مخصص حالياً لطلب آخر")
    assignment = NetflixProfileAssignment(
        profile_id=profile.id, user_id=user_id, expires_at=expires_at,
        max_devices=max_devices, status="active",
    )
    db.session.add(assignment)
    db.session.commit()
    return assignment


def end_netflix_profile_assignment(assignment_id):
    from ..models.features import NetflixProfileAssignment
    row = NetflixProfileAssignment.query.filter_by(id=assignment_id).with_for_update().first()
    if not row:
        raise ValueError("التخصيص غير موجود")
    if row.status == "active":
        row.status = "ended"
        row.ended_at = datetime.utcnow()
        db.session.commit()
    return row


def preview_game_code(provider, code, player_id=None):
    provider = (provider or "").lower().strip()
    if provider not in {"midasbuy", "shop2game", "garena"}:
        return {"status": False, "amount": 0, "type": "", "player_name": "", "message": "مزود غير مدعوم"}
    if not code or len(code.strip()) < 4:
        return {"status": False, "amount": 0, "type": "", "player_name": "", "message": "الكود غير صالح"}
    match = re.search(r"(?:uc|gems|جوهرة|شدة)\s*([0-9]+)|([0-9]+)\s*(?:uc|gems)", code, re.I)
    amount = int(next((item for item in (match.groups() if match else ()) if item), 0))
    return {"status": False, "amount": amount, "type": "UC" if provider == "midasbuy" else "Gems",
            "player_name": "", "message": "المزود الرسمي غير مهيأ؛ لم يتم تنفيذ شحن."}
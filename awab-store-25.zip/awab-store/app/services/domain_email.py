"""Safe catch-all address verification without storing message content."""
import secrets
import smtplib
import string
from datetime import datetime
from email.message import EmailMessage

from flask import current_app

from ..extensions import db
from ..models.features import DomainEmailAddress, DomainEmailVerificationBatch


ALPHABET = string.ascii_lowercase + string.digits


def _new_address(domain):
    while True:
        local = "nflx_" + "".join(secrets.choice(ALPHABET) for _ in range(8))
        address = f"{local}@{domain}"
        if not DomainEmailAddress.query.filter_by(address=address).first():
            return address


def generate_verification_batch(count=10):
    if count != 10:
        raise ValueError("Verification batches must contain exactly 10 addresses")
    domain = current_app.config["DOMAIN_EMAIL_DOMAIN"].strip().lower()
    if not domain or "@" in domain:
        raise ValueError("DOMAIN_EMAIL_DOMAIN is invalid")
    batch_id = secrets.token_urlsafe(24)
    batch = DomainEmailVerificationBatch(batch_id=batch_id, requested_count=count)
    db.session.add(batch)
    rows = []
    for _ in range(count):
        row = DomainEmailAddress(address=_new_address(domain), batch_id=batch_id)
        db.session.add(row)
        rows.append(row)
    db.session.commit()
    return batch, rows


def send_verification_messages(rows):
    host = current_app.config.get("DOMAIN_EMAIL_SMTP_HOST", "").strip()
    sender = current_app.config.get("DOMAIN_EMAIL_TEST_SENDER", "").strip()
    if not host or not sender:
        return False
    port = int(current_app.config.get("DOMAIN_EMAIL_SMTP_PORT", 587))
    username = current_app.config.get("DOMAIN_EMAIL_SMTP_USERNAME", "")
    password = current_app.config.get("DOMAIN_EMAIL_SMTP_PASSWORD", "")
    use_tls = bool(current_app.config.get("DOMAIN_EMAIL_SMTP_USE_TLS", True))
    with smtplib.SMTP(host, port, timeout=20) as smtp:
        if use_tls:
            smtp.starttls()
        if username:
            smtp.login(username, password)
        for row in rows:
            message = EmailMessage()
            message["From"] = sender
            message["To"] = row.address
            message["Subject"] = "Catch-all delivery test"
            message.set_content(f"Delivery verification for batch {row.batch_id}. No authentication data.")
            smtp.send_message(message)
            row.status = "sent"
            row.last_tested_at = datetime.utcnow()
    db.session.commit()
    return True
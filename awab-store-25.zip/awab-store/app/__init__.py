"""
=============================================================
  app/__init__.py — Flask Application Factory
=============================================================
"""

import os
import logging
import time
from datetime import datetime
from logging.handlers import RotatingFileHandler
from flask import Flask, render_template, request, g
from .extensions import db, login_manager, csrf, limiter


def create_app() -> Flask:
    """إنشاء تطبيق Flask"""
    base_dir = os.path.dirname(os.path.abspath(__file__))

    app = Flask(
        __name__,
        template_folder=os.path.join(base_dir, "templates"),
        static_folder=os.path.join(base_dir, "static"),
    )
    app.url_map.strict_slashes = False

    # ─── إعداد التطبيق من config.py ───
    import sys
    sys.path.insert(0, os.path.dirname(base_dir))
    import config as cfg

    app.config["SECRET_KEY"]              = cfg.Config.SECRET_KEY
    app.config["SQLALCHEMY_DATABASE_URI"] = cfg.Config.SQLALCHEMY_DATABASE_URI
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["WTF_CSRF_ENABLED"]        = cfg.Config.WTF_CSRF_ENABLED
    app.config["WTF_CSRF_SECRET_KEY"]     = cfg.Config.WTF_CSRF_SECRET_KEY
    app.config["PERMANENT_SESSION_LIFETIME"] = cfg.Config.PERMANENT_SESSION_LIFETIME
    app.config["SESSION_COOKIE_HTTPONLY"] = cfg.Config.SESSION_COOKIE_HTTPONLY
    app.config["SESSION_COOKIE_SAMESITE"] = cfg.Config.SESSION_COOKIE_SAMESITE
    app.config["MAX_CONTENT_LENGTH"]      = cfg.Config.MAX_CONTENT_LENGTH
    app.config["DOMAIN_EMAIL_DOMAIN"] = cfg.Config.DOMAIN_EMAIL_DOMAIN
    app.config["DOMAIN_EMAIL_WEBHOOK_SECRET"] = cfg.Config.DOMAIN_EMAIL_WEBHOOK_SECRET
    app.config["DOMAIN_EMAIL_SMTP_HOST"] = cfg.Config.DOMAIN_EMAIL_SMTP_HOST
    app.config["DOMAIN_EMAIL_SMTP_PORT"] = cfg.Config.DOMAIN_EMAIL_SMTP_PORT
    app.config["DOMAIN_EMAIL_SMTP_USERNAME"] = cfg.Config.DOMAIN_EMAIL_SMTP_USERNAME
    app.config["DOMAIN_EMAIL_SMTP_PASSWORD"] = cfg.Config.DOMAIN_EMAIL_SMTP_PASSWORD
    app.config["DOMAIN_EMAIL_SMTP_USE_TLS"] = cfg.Config.DOMAIN_EMAIL_SMTP_USE_TLS
    app.config["DOMAIN_EMAIL_TEST_SENDER"] = cfg.Config.DOMAIN_EMAIL_TEST_SENDER

    # مراقبة آمنة لطلبات POST الخاصة بالـ webhooks: نسجل أسماء الحقول فقط.
    monitor_log = os.path.join(os.path.dirname(base_dir), "webhook_requests.log")
    webhook_logger = logging.getLogger("awab.webhook_monitor")
    webhook_logger.setLevel(logging.INFO)
    webhook_logger.propagate = False
    if not webhook_logger.handlers:
        handler = RotatingFileHandler(
            monitor_log, maxBytes=2 * 1024 * 1024, backupCount=3, encoding="utf-8"
        )
        handler.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
        webhook_logger.addHandler(handler)

    @app.before_request
    def monitor_webhook_request():
        if request.method != "POST" or not request.path.startswith("/sms/"):
            return
        g.webhook_started_at = time.perf_counter()
        json_data = request.get_json(silent=True)
        if isinstance(json_data, dict):
            fields = sorted(str(key) for key in json_data.keys())
            body_type = "json"
        else:
            fields = sorted(str(key) for key in request.form.keys())
            body_type = "form" if request.form else "empty/invalid"
        webhook_logger.info(
            "incoming method=POST path=%s content_type=%s body_type=%s "
            "fields=%s content_length=%s secret_header=%s remote=%s",
            request.path, request.content_type or "none", body_type, fields,
            request.content_length or 0,
            "present" if request.headers.get("X-Webhook-Secret") else "missing",
            request.remote_addr or "unknown",
        )

    @app.after_request
    def monitor_webhook_response(response):
        if request.method == "POST" and request.path.startswith("/sms/"):
            started = getattr(g, "webhook_started_at", None)
            duration_ms = round((time.perf_counter() - started) * 1000, 2) if started else None
            webhook_logger.info(
                "completed method=POST path=%s status=%s duration_ms=%s",
                request.path, response.status_code, duration_ms,
            )
        return response

    @app.after_request
    def ensure_utf8_response(response):
        """إجبار صفحات HTML والنصوص على الإعلان عن ترميز UTF-8."""
        if response.mimetype in {"text/html", "text/plain", "application/json"}:
            response.headers["Content-Type"] = (
                f"{response.mimetype}; charset=utf-8"
            )
        return response

    # ─── تهيئة الإضافات ───
    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)

    # ─── هجرة تلقائية للأعمدة الجديدة ───
    with app.app_context():
        try:
            engine = db.engine
            with engine.connect() as conn:
                from sqlalchemy import text, inspect
                inspector = inspect(engine)
                cols = [c["name"] for c in inspector.get_columns("top_up_requests")]
                if "binance_amount_usd" not in cols:
                    conn.execute(text(
                        "ALTER TABLE top_up_requests ADD COLUMN binance_amount_usd REAL"
                    ))
                    conn.commit()
                device_cols = [c["name"] for c in inspector.get_columns("netflix_devices")]
                if "assignment_id" not in device_cols:
                    conn.execute(text(
                        "ALTER TABLE netflix_devices ADD COLUMN assignment_id INTEGER "
                        "REFERENCES netflix_profile_assignments(id)"
                    ))
                    conn.execute(text(
                        "CREATE INDEX IF NOT EXISTS ix_netflix_devices_assignment_id "
                        "ON netflix_devices (assignment_id)"
                    ))
                    conn.commit()
                assignment_cols = [c["name"] for c in inspector.get_columns("netflix_profile_assignments")]
                if "reset_count" not in assignment_cols:
                    conn.execute(text(
                        "ALTER TABLE netflix_profile_assignments "
                        "ADD COLUMN reset_count INTEGER NOT NULL DEFAULT 0"
                    ))
                if "reset_window_started" not in assignment_cols:
                    conn.execute(text(
                        "ALTER TABLE netflix_profile_assignments "
                        "ADD COLUMN reset_window_started DATETIME"
                    ))
                gift_cols = [c["name"] for c in inspector.get_columns("gift_orders")]
                if "delivery_text" not in gift_cols:
                    conn.execute(text("ALTER TABLE gift_orders ADD COLUMN delivery_text TEXT"))
                if "delivered_at" not in gift_cols:
                    conn.execute(text("ALTER TABLE gift_orders ADD COLUMN delivered_at DATETIME"))
                conn.commit()
        except Exception:
            pass  # الجدول غير موجود بعد — سيُنشأ عبر create_all لاحقاً

    login_manager.login_view      = "auth.login"
    login_manager.login_message   = "يجب تسجيل الدخول للوصول إلى هذه الصفحة."
    login_manager.login_message_category = "warning"

    @login_manager.user_loader
    def load_user(user_id: str):
        from .models.user import User
        return User.query.get(int(user_id))

    # ─── تسجيل Blueprints ───
    from .routes.store       import store_bp
    from .routes.auth        import auth_bp
    from .routes.cart        import cart_bp
    from .routes.orders      import orders_bp
    from .routes.payments    import payments_bp
    from .routes.sms_webhook import sms_bp
    from .routes.features    import features_bp
    from .routes.domain_email import domain_email_bp
    from .routes.admin       import admin_bp

    app.register_blueprint(store_bp,    url_prefix="/")
    app.register_blueprint(auth_bp,     url_prefix="/")
    app.register_blueprint(cart_bp,     url_prefix="/cart")
    app.register_blueprint(orders_bp,   url_prefix="/orders")
    app.register_blueprint(payments_bp, url_prefix="/payments")
    app.register_blueprint(sms_bp,      url_prefix="/sms")
    app.register_blueprint(features_bp, url_prefix="/")
    app.register_blueprint(domain_email_bp, url_prefix="/domain-email")
    app.register_blueprint(admin_bp,    url_prefix="/admin")

    # ─── متغيرات السياق العامة ───
    @app.context_processor
    def inject_globals():
        from flask_login import current_user
        from flask import session
        from .models.order import ORDER_STATUSES
        from .models.notification import NOTIF_TYPES
        cart = session.get("cart", {}) if True else {}
        try:
            cart = session.get("cart", {})
        except Exception:
            cart = {}
        return {
            "site_name":   "Awab Store",
            "cart_count":  sum(cart.values()) if cart else 0,
            "current_user": current_user,
            "ORDER_STATUSES": ORDER_STATUSES,
            "NOTIF_TYPES": NOTIF_TYPES,
            "now": datetime.utcnow(),
        }

    # ─── معالجات الأخطاء ───
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(500)
    def internal_error(e):
        db.session.rollback()
        return render_template("errors/500.html"), 500

    return app

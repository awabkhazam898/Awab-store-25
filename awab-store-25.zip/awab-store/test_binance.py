"""
اختبار الاتصال بـ Binance API
شغّله بـ: python test_binance.py
"""
import hashlib, hmac, time, json, urllib.request, urllib.parse, os

API_KEY    = os.environ.get("BINANCE_API_KEY", "")
API_SECRET = os.environ.get("BINANCE_API_SECRET", "")

def sign(secret, query):
    return hmac.new(secret.encode(), query.encode(), hashlib.sha256).hexdigest()

def test_ping():
    print("1. اختبار الاتصال الأساسي...")
    req = urllib.request.Request("https://api.binance.com/api/v3/ping")
    with urllib.request.urlopen(req, timeout=10) as r:
        print(f"   ✅ الاتصال ناجح — {r.status}")

def test_server_time():
    print("2. اختبار وقت السيرفر...")
    req = urllib.request.Request("https://api.binance.com/api/v3/time")
    with urllib.request.urlopen(req, timeout=10) as r:
        data = json.loads(r.read())
        print(f"   ✅ وقت Binance: {data['serverTime']}")

def test_api_key():
    print("3. اختبار صحة API Key (Pay permissions)...")
    if not API_KEY or not API_SECRET:
        print("   ❌ المفاتيح غير موجودة في متغيرات البيئة")
        return
    ts     = int(time.time() * 1000)
    params = f"timestamp={ts}"
    sig    = sign(API_SECRET, params)
    url    = f"https://api.binance.com/sapi/v1/pay/transactions/query?{params}&signature={sig}"
    req    = urllib.request.Request(url, headers={"X-MBX-APIKEY": API_KEY})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
            print(f"   ✅ API Key صحيح — الاستجابة: {data}")
    except urllib.error.HTTPError as e:
        body = json.loads(e.read())
        code = body.get("code")
        msg  = body.get("msg", "")
        if code == -1102:
            # -1102 = Mandatory param 'transId' missing — يعني الـ key يعمل
            print(f"   ✅ API Key صحيح ويملك صلاحية Pay ✔")
        elif code == -2015:
            print(f"   ❌ API Key غير صحيح أو منتهي الصلاحية: {msg}")
        elif code == -1021:
            print(f"   ❌ فرق في الوقت مع Binance — تحقق من ساعة الجهاز: {msg}")
        else:
            print(f"   ⚠️  كود: {code} — {msg}")

if __name__ == "__main__":
    print("=" * 40)
    print("  اختبار Binance API — Awab Store")
    print("=" * 40)
    try:
        test_ping()
        test_server_time()
        test_api_key()
    except Exception as e:
        print(f"   ❌ خطأ: {e}")
    print("=" * 40)

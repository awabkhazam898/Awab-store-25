"""
=============================================================
  Awab Store — ملف الإعدادات الرئيسي
  config.py — يحتوي على جميع بيانات الإعداد والتكوين
=============================================================
  ⚠️  تعليمات:
     1. أدخل بيانات لوحة الإدارة (اسم المستخدم وكلمة المرور)
     2. أدخل توكن بوت تيليجرام
     3. أدخل معرّف مجموعة سجل الطلبات
     4. أدخل معرّف المالك على تيليجرام
=============================================================
"""

import os
from datetime import timedelta

# ─────────────────────────────────────────────
#  بيانات لوحة الإدارة
# ─────────────────────────────────────────────
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "Awab_11")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "A2011kh11")

# ─────────────────────────────────────────────
#  بوت تيليجرام — Order Processing Bot
# ─────────────────────────────────────────────
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "8703917238:AAFGOWm-4F8ZZynd4fJnVsrGhIZkp94r-p4")

# معرّف مجموعة سجل الطلبات (يبدأ بـ -)
ORDERS_LOG_GROUP_ID = int(os.environ.get("ORDERS_LOG_GROUP_ID", "-1002880174356") or 0)

# معرّف المالك على تيليجرام
OWNER_TELEGRAM_ID = int(os.environ.get("OWNER_TELEGRAM_ID", "393240324") or 0)

# قائمة معرّفات المشرفين (Admins)
ADMIN_TELEGRAM_IDS = [
    int(x.strip())
    for x in os.environ.get("ADMIN_TELEGRAM_IDS", "").split(",")
    if x.strip().lstrip("-").isdigit()
]

# ─────────────────────────────────────────────
#  إعدادات قاعدة البيانات
# ─────────────────────────────────────────────
_default_db = os.path.join(os.path.dirname(os.path.abspath(__file__)), "awab_store.db")
DATABASE_URL = os.environ.get(
    "FLASK_DATABASE_URL",
    f"sqlite:///{_default_db}"
)

# ─────────────────────────────────────────────
#  إعدادات الأمان
# ─────────────────────────────────────────────
SECRET_KEY = os.environ.get("SECRET_KEY", "awab-store-ultra-secure-key-change-in-production-2025!")
WTF_CSRF_SECRET_KEY = os.environ.get("WTF_CSRF_SECRET_KEY", "csrf-awab-store-2025-change-me!")
WEBHOOK_SECRET = os.environ.get("WEBHOOK_SECRET", "sms-webhook-secret-2025")
DOMAIN_EMAIL_WEBHOOK_SECRET = os.environ.get("DOMAIN_EMAIL_WEBHOOK_SECRET", "")

# مدة صلاحية الجلسة
SESSION_LIFETIME = timedelta(days=7)

# ─────────────────────────────────────────────
#  إعدادات الدفع عبر SMS
# ─────────────────────────────────────────────
LIBYANA_PHONE = os.environ.get("LIBYANA_PHONE", "0920471970")
LIBYANA_VERIFICATION_WINDOW = 300  # 5 دقائق بالثواني

ALMADAR_PHONE = os.environ.get("ALMADAR_PHONE", "0931187040")
ALMADAR_VERIFICATION_WINDOW = 420  # 7 دقائق بالثواني

# ─────────────────────────────────────────────
#  إعدادات Binance Internal Transfer
# ─────────────────────────────────────────────
BINANCE_UID = os.environ.get("BINANCE_UID", "829746222")
BINANCE_EMAIL = os.environ.get("BINANCE_EMAIL", "awabkhazam898@gmail.com")
BINANCE_ACCEPTED_COINS = ["USDT", "GRAM"]

# مفاتيح Binance API للتحقق من المدفوعات
BINANCE_API_KEY    = os.environ.get("BINANCE_API_KEY", "fAtInKlKP2APkb2qVpBpn1X0l06aVPCLJfiCd8kAFQDafEd9Gl0C9Rzm5RUuBrdf")
BINANCE_API_SECRET = os.environ.get("BINANCE_API_SECRET", "qGcV6o77ui242uYk2QzbmnlF6bnZJIAJoiRwqRSfhQChZ3Sifh5IVGnYM4lAtYox")

# ─────────────────────────────────────────────
#  إعدادات نظام المكافآت
# ─────────────────────────────────────────────
DEFAULT_POINT_VALUE_USD = 0.05  # قيمة النقطة الافتراضية بالدولار


# ─────────────────────────────────────────────
#  إعدادات Flask
# ─────────────────────────────────────────────
class Config:
    """إعدادات Flask الرئيسية"""
    SECRET_KEY = SECRET_KEY
    WTF_CSRF_ENABLED = True
    WTF_CSRF_SECRET_KEY = WTF_CSRF_SECRET_KEY

    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 300,
    }

    PERMANENT_SESSION_LIFETIME = SESSION_LIFETIME
    SESSION_COOKIE_SECURE = False
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"

    RATELIMIT_DEFAULT = "200 per day;50 per hour"
    RATELIMIT_STORAGE_URL = "memory://"

    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB

    DOMAIN_EMAIL_DOMAIN = os.environ.get("DOMAIN_EMAIL_DOMAIN", "awab-store.com.ly")
    DOMAIN_EMAIL_WEBHOOK_SECRET = DOMAIN_EMAIL_WEBHOOK_SECRET
    DOMAIN_EMAIL_SMTP_HOST = os.environ.get("DOMAIN_EMAIL_SMTP_HOST", "")
    DOMAIN_EMAIL_SMTP_PORT = int(os.environ.get("DOMAIN_EMAIL_SMTP_PORT", "587"))
    DOMAIN_EMAIL_SMTP_USERNAME = os.environ.get("DOMAIN_EMAIL_SMTP_USERNAME", "")
    DOMAIN_EMAIL_SMTP_PASSWORD = os.environ.get("DOMAIN_EMAIL_SMTP_PASSWORD", "")
    DOMAIN_EMAIL_SMTP_USE_TLS = os.environ.get("DOMAIN_EMAIL_SMTP_USE_TLS", "true").lower() == "true"
    DOMAIN_EMAIL_TEST_SENDER = os.environ.get("DOMAIN_EMAIL_TEST_SENDER", "")

    SITE_NAME = os.environ.get("SITE_NAME", "Awab Store")
    SITE_URL = os.environ.get("SITE_URL", "https://awab-store.com.ly")
    TELEGRAM_LINK = os.environ.get("TELEGRAM_LINK", "https://t.me/ppcxq")


class DevelopmentConfig(Config):
    DEBUG = True
    SESSION_COOKIE_SECURE = False


class ProductionConfig(Config):
    DEBUG = False
    SESSION_COOKIE_SECURE = True


config = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig,
}

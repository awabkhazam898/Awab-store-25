"""
wsgi.py — نقطة دخول gunicorn للإنتاج
Usage: gunicorn -b 0.0.0.0:$PORT wsgi:app
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from run import app, init_db

# تهيئة قاعدة البيانات عند أول تشغيل
init_db()

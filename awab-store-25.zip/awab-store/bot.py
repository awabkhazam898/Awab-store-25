#!/usr/bin/env python3
"""
=============================================================
  bot.py — بوت Telegram المستقل لمعالجة الطلبات
  يعمل بشكل منفصل عن المتجر ولوحة الإدارة
=============================================================
  تشغيل البوت:
      python bot.py
=============================================================
"""

import sys
import os
import logging
from datetime import datetime
from typing import Optional

# إضافة مجلد المشروع للمسار
_base_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _base_dir)

# إجبار SQLite (نفس قاعدة البيانات التي يستخدمها المتجر)
os.environ["DATABASE_URL"] = f"sqlite:///{os.path.join(_base_dir, 'awab_store.db')}"

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ConversationHandler,
    filters,
    ContextTypes,
)
from telegram.constants import ParseMode

from config import (
    TELEGRAM_BOT_TOKEN,
    OWNER_TELEGRAM_ID,
    ORDERS_LOG_GROUP_ID,
    DEFAULT_POINT_VALUE_USD,
)

# تهيئة Flask لاستخدام قاعدة البيانات
from app import create_app

flask_app = create_app()

# استيراد وحدة المزادات المضافة حديثًا (bot/auctions.py)
from bot.auctions import (  # noqa: E402  (import after create_app)
    cb_auction_decision,
    cb_bid,
    cmd_auction,
    finalize_due_auctions,
)


async def _cmd_auction_wrapped(update, context):
    await cmd_auction(update, context, flask_app)


async def _cb_bid_wrapped(update, context):
    await cb_bid(update, context, flask_app)


async def _cb_auction_decision_wrapped(update, context):
    await cb_auction_decision(update, context, flask_app)

# ─── Logging ───────────────────────────────────────────────────────────────
logging.basicConfig(
    format="%(asctime)s — %(name)s — %(levelname)s — %(message)s",
    level=logging.INFO,
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("bot.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("awab_bot")

# ─── حالات المحادثة (Conversation States) ───────────────────────────────
REJECT_REASON = 1
TRANSFER_SELECT = 2
ADJ_ADMIN = 3
ADJ_COUNT = 4
ADJ_REASON = 5
SET_POINT = 6


# ═══════════════════════════════════════════════════════════════════════════
#  دوال مساعدة
# ═══════════════════════════════════════════════════════════════════════════

def is_owner(telegram_id: int) -> bool:
    return telegram_id == OWNER_TELEGRAM_ID


def _get_admin_staff(telegram_id: int):
    """جلب بيانات المشرف من قاعدة البيانات"""
    from app.models.admin_staff import AdminStaff
    return AdminStaff.query.filter_by(telegram_id=telegram_id, is_active=True).first()


def _require_admin(telegram_id: int) -> bool:
    """هل المستخدم مشرف نشط أو مالك؟"""
    if is_owner(telegram_id):
        return True
    with flask_app.app_context():
        return _get_admin_staff(telegram_id) is not None


def _build_order_keyboard(order_id: int, status: str) -> Optional[InlineKeyboardMarkup]:
    """بناء لوحة مفاتيح الطلب حسب الحالة"""
    if status in ("completed", "rejected", "cancelled", "failed"):
        return None
    if status == "pending":
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ قبول", callback_data=f"accept_{order_id}"),
                InlineKeyboardButton("❌ رفض", callback_data=f"reject_{order_id}"),
            ],
            [
                InlineKeyboardButton("🔄 تحويل", callback_data=f"transfer_{order_id}"),
            ],
        ])
    if status in ("accepted", "processing"):
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ إتمام الطلب", callback_data=f"complete_{order_id}"),
                InlineKeyboardButton("🔄 تحويل", callback_data=f"transfer_{order_id}"),
            ],
        ])
    return None


def _format_order_text(order) -> str:
    """تنسيق نص تفاصيل الطلب"""
    items_text = "\n".join(
        f"  • {item.product.name} × {item.quantity} — {item.total_price:.2f} LYD"
        for item in order.items.all()
    )
    fields_text = ""
    for fv in order.field_values.all():
        fields_text += f"  • {fv.field_label}: <code>{fv.value}</code>\n"

    assigned_text = ""
    if order.assigned_admin_id:
        from app.models.admin_staff import AdminStaff
        admin = AdminStaff.query.get(order.assigned_admin_id)
        if admin:
            assigned_text = f"\n👮 <b>المسؤول:</b> {admin.display_name}"

    status_label = order.status_info.get("label", order.status)
    return (
        f"🛒 <b>طلب اشتراك</b>\n"
        f"{'━' * 28}\n"
        f"🆔 <b>رقم الطلب:</b> <code>{order.order_number}</code>\n"
        f"👤 <b>العميل:</b> {order.user.username} (ID: {order.user.id})\n"
        f"\n<b>📦 المنتجات:</b>\n{items_text}\n"
        + (f"\n<b>📋 بيانات الحساب:</b>\n{fields_text}" if fields_text else "")
        + f"\n💰 <b>الإجمالي:</b> {order.total_amount:.2f} LYD\n"
        f"📌 <b>الحالة:</b> {status_label}"
        f"{assigned_text}\n"
        f"🕒 {order.created_at.strftime('%Y-%m-%d %H:%M')}"
    )


async def _notify_log_group(context: ContextTypes.DEFAULT_TYPE, text: str):
    """إرسال إشعار لمجموعة السجلات"""
    if not ORDERS_LOG_GROUP_ID:
        return
    try:
        await context.bot.send_message(
            chat_id=ORDERS_LOG_GROUP_ID,
            text=text,
            parse_mode=ParseMode.HTML,
        )
    except Exception as e:
        logger.warning(f"فشل إرسال سجل: {e}")


async def _notify_user_telegram(context, order, message: str):
    """إشعار العميل إذا كان لديه telegram_id"""
    try:
        user = order.user
        if hasattr(user, "telegram_id") and user.telegram_id:
            await context.bot.send_message(
                chat_id=user.telegram_id,
                text=message,
                parse_mode=ParseMode.HTML,
            )
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════
#  أوامر عامة
# ═══════════════════════════════════════════════════════════════════════════

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tid = update.effective_user.id
    if is_owner(tid):
        role = "👑 المالك"
    elif _require_admin(tid):
        role = "👮 مشرف"
    else:
        role = "❌ غير مصرح"

    text = (
        f"مرحباً في بوت <b>Awab Store</b> 🏪\n"
        f"{'━' * 28}\n"
        f"الدور: {role}\n\n"
    )
    if _require_admin(tid):
        text += (
            "📋 الأوامر المتاحة:\n"
            "/orders — عرض الطلبات المعلقة\n"
            "/help — مساعدة\n"
        )
    if is_owner(tid):
        text += (
            "\n👑 أوامر المالك:\n"
            "/owner — لوحة المالك\n"
            "/stats — إحصائيات عامة\n"
            "/report — تقرير شهري\n"
            "/admins — قائمة المشرفين\n"
            "/addadmin — إضافة مشرف\n"
            "/removeadmin — حذف مشرف\n"
            "/setpoint — تعديل قيمة النقطة\n"
            "/adjustpoints — تعديل نقاط مشرف\n"
        )
    await update.message.reply_text(text, parse_mode=ParseMode.HTML)


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await cmd_start(update, context)


# ═══════════════════════════════════════════════════════════════════════════
#  عرض الطلبات المعلقة
# ═══════════════════════════════════════════════════════════════════════════

async def cmd_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tid = update.effective_user.id
    if not _require_admin(tid):
        await update.message.reply_text("⛔ غير مصرح لك.")
        return

    with flask_app.app_context():
        from app.models.order import Order, ORDER_STATUS_PENDING, ORDER_STATUS_ACCEPTED
        from app.models.product import PRODUCT_TYPE_SUBSCRIPTION

        orders = (
            Order.query
            .filter(Order.status.in_([ORDER_STATUS_PENDING, ORDER_STATUS_ACCEPTED]))
            .order_by(Order.created_at.asc())
            .limit(10)
            .all()
        )

        if not orders:
            await update.message.reply_text("✅ لا توجد طلبات معلقة حالياً.")
            return

        await update.message.reply_text(
            f"📋 <b>الطلبات المعلقة ({len(orders)})</b>",
            parse_mode=ParseMode.HTML,
        )

        for order in orders:
            text = _format_order_text(order)
            keyboard = _build_order_keyboard(order.id, order.status)
            await update.message.reply_text(
                text,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard,
            )


# ═══════════════════════════════════════════════════════════════════════════
#  معالجة Callback — قبول الطلب
# ═══════════════════════════════════════════════════════════════════════════

async def cb_accept(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    tid = update.effective_user.id
    if not _require_admin(tid):
        await query.answer("⛔ غير مصرح.", show_alert=True)
        return

    order_id = int(query.data.split("_")[1])

    with flask_app.app_context():
        from app.extensions import db
        from app.models.order import Order, ORDER_STATUS_PENDING, ORDER_STATUS_ACCEPTED
        from app.models.admin_staff import AdminStaff
        from app.models.payment import AuditLog

        order = Order.query.get(order_id)
        if not order:
            await query.edit_message_text("❌ الطلب غير موجود.")
            return

        if order.status != ORDER_STATUS_PENDING:
            status_label = order.status_info.get("label", order.status)
            await query.answer(f"⚠️ الطلب بالفعل في حالة: {status_label}", show_alert=True)
            return

        admin = _get_admin_staff(tid) if not is_owner(tid) else None
        admin_name = admin.display_name if admin else f"المالك (@{update.effective_user.username})"

        old_status = order.status
        order.status = ORDER_STATUS_ACCEPTED
        order.accepted_at = datetime.utcnow()
        if admin:
            order.assigned_admin_id = admin.id
            order.accepted_by_id = admin.id
            admin.total_accepted = (admin.total_accepted or 0) + 1

        order.log_status_change(old_status, ORDER_STATUS_ACCEPTED,
                                note=f"قبل بواسطة {admin_name}")

        log = AuditLog(
            action="order_accepted",
            performed_by=admin_name,
            target_user_id=order.user_id,
            data={"order_number": order.order_number, "admin": admin_name},
        )
        db.session.add(log)
        db.session.commit()

        text = _format_order_text(order)
        keyboard = _build_order_keyboard(order.id, order.status)
        await query.edit_message_text(
            text + f"\n\n✅ <b>قبله:</b> {admin_name}",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard,
        )

        await _notify_log_group(
            context,
            f"✅ <b>تم قبول الطلب</b>\n"
            f"🆔 <code>{order.order_number}</code>\n"
            f"👮 القابل: {admin_name}",
        )


# ═══════════════════════════════════════════════════════════════════════════
#  معالجة Callback — رفض الطلب (ConversationHandler)
# ═══════════════════════════════════════════════════════════════════════════

async def cb_reject_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    tid = update.effective_user.id
    if not _require_admin(tid):
        await query.answer("⛔ غير مصرح.", show_alert=True)
        return ConversationHandler.END

    order_id = int(query.data.split("_")[1])
    context.user_data["reject_order_id"] = order_id
    context.user_data["reject_message_id"] = query.message.message_id
    context.user_data["reject_chat_id"] = query.message.chat_id

    await query.message.reply_text(
        f"❌ <b>رفض الطلب #{order_id}</b>\n\nأرسل سبب الرفض:",
        parse_mode=ParseMode.HTML,
    )
    return REJECT_REASON


async def cb_reject_reason(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reason = update.message.text.strip()
    order_id = context.user_data.get("reject_order_id")
    tid = update.effective_user.id

    if not order_id:
        await update.message.reply_text("❌ خطأ، حاول مجدداً.")
        return ConversationHandler.END

    with flask_app.app_context():
        from app.extensions import db
        from app.models.order import Order, ORDER_STATUS_REJECTED
        from app.models.admin_staff import AdminStaff
        from app.models.payment import AuditLog

        order = Order.query.get(order_id)
        if not order:
            await update.message.reply_text("❌ الطلب غير موجود.")
            return ConversationHandler.END

        admin = _get_admin_staff(tid) if not is_owner(tid) else None
        admin_name = admin.display_name if admin else f"المالك (@{update.effective_user.username})"

        old_status = order.status
        order.status = ORDER_STATUS_REJECTED
        order.reject_reason = reason
        if admin:
            admin.total_rejected = (admin.total_rejected or 0) + 1

        order.log_status_change(old_status, ORDER_STATUS_REJECTED,
                                note=f"رُفض بواسطة {admin_name}: {reason}")

        log = AuditLog(
            action="order_rejected",
            performed_by=admin_name,
            target_user_id=order.user_id,
            data={"order_number": order.order_number, "reason": reason},
        )
        db.session.add(log)
        db.session.commit()

        # تحديث رسالة الطلب الأصلية
        try:
            await context.bot.edit_message_text(
                chat_id=context.user_data["reject_chat_id"],
                message_id=context.user_data["reject_message_id"],
                text=_format_order_text(order) + f"\n\n❌ <b>رُفض:</b> {reason}\n👮 بواسطة: {admin_name}",
                parse_mode=ParseMode.HTML,
            )
        except Exception:
            pass

        await update.message.reply_text(
            f"✅ تم رفض الطلب <code>{order.order_number}</code>\nالسبب: {reason}",
            parse_mode=ParseMode.HTML,
        )
        await _notify_log_group(
            context,
            f"❌ <b>تم رفض الطلب</b>\n"
            f"🆔 <code>{order.order_number}</code>\n"
            f"📝 السبب: {reason}\n"
            f"👮 بواسطة: {admin_name}",
        )

    context.user_data.clear()
    return ConversationHandler.END


# ═══════════════════════════════════════════════════════════════════════════
#  معالجة Callback — تحويل الطلب
# ═══════════════════════════════════════════════════════════════════════════

async def cb_transfer_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    tid = update.effective_user.id
    if not _require_admin(tid):
        await query.answer("⛔ غير مصرح.", show_alert=True)
        return

    order_id = int(query.data.split("_")[1])

    with flask_app.app_context():
        from app.models.admin_staff import AdminStaff

        admins = AdminStaff.query.filter(
            AdminStaff.is_active == True,
            AdminStaff.telegram_id != tid,
        ).all()

        if not admins:
            await query.answer("⚠️ لا يوجد مشرفون آخرون متاحون.", show_alert=True)
            return

        buttons = [
            [InlineKeyboardButton(
                f"{a.display_name}",
                callback_data=f"transfer_to_{order_id}_{a.telegram_id}",
            )]
            for a in admins
        ]
        buttons.append([InlineKeyboardButton("❌ إلغاء", callback_data=f"cancel_transfer")])

        await query.message.reply_text(
            f"🔄 <b>تحويل الطلب #{order_id}</b>\nاختر المشرف:",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(buttons),
        )


async def cb_transfer_to(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    tid = update.effective_user.id
    if not _require_admin(tid):
        return

    parts = query.data.split("_")  # transfer_to_{order_id}_{admin_tg_id}
    order_id = int(parts[2])
    target_tg_id = int(parts[3])

    with flask_app.app_context():
        from app.extensions import db
        from app.models.order import Order
        from app.models.admin_staff import AdminStaff
        from app.models.payment import AuditLog

        order = Order.query.get(order_id)
        target_admin = AdminStaff.query.filter_by(telegram_id=target_tg_id, is_active=True).first()
        from_admin = _get_admin_staff(tid) if not is_owner(tid) else None

        if not order or not target_admin:
            await query.edit_message_text("❌ خطأ في بيانات التحويل.")
            return

        from_name = from_admin.display_name if from_admin else f"المالك"
        old_status = order.status

        old_admin_id = order.assigned_admin_id
        order.assigned_admin_id = target_admin.id
        order.status = "transferred"

        if from_admin:
            from_admin.total_transferred = (from_admin.total_transferred or 0) + 1

        order.log_status_change(
            old_status, "transferred",
            note=f"حُوِّل من {from_name} إلى {target_admin.display_name}",
        )

        log = AuditLog(
            action="order_transferred",
            performed_by=from_name,
            target_user_id=order.user_id,
            data={
                "order_number": order.order_number,
                "from": from_name,
                "to": target_admin.display_name,
            },
        )
        db.session.add(log)
        db.session.commit()

        await query.edit_message_text(
            f"✅ تم تحويل الطلب <code>{order.order_number}</code>\n"
            f"من: {from_name} → إلى: {target_admin.display_name}",
            parse_mode=ParseMode.HTML,
        )

        # إشعار المشرف الجديد
        try:
            text = (
                f"🔔 <b>تم تحويل طلب إليك</b>\n"
                f"{'━' * 25}\n"
                + _format_order_text(order)
                + f"\n\n📨 من: {from_name}"
            )
            keyboard = _build_order_keyboard(order.id, order.status)
            await context.bot.send_message(
                chat_id=target_tg_id,
                text=text,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard,
            )
        except Exception as e:
            logger.warning(f"فشل إشعار المشرف الجديد: {e}")

        await _notify_log_group(
            context,
            f"🔄 <b>تحويل طلب</b>\n"
            f"🆔 <code>{order.order_number}</code>\n"
            f"من: {from_name} → إلى: {target_admin.display_name}",
        )


async def cb_cancel_transfer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer("تم إلغاء التحويل.")
    await query.edit_message_text("❌ تم إلغاء عملية التحويل.")


# ═══════════════════════════════════════════════════════════════════════════
#  معالجة Callback — إتمام الطلب
# ═══════════════════════════════════════════════════════════════════════════

async def cb_complete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    tid = update.effective_user.id
    if not _require_admin(tid):
        await query.answer("⛔ غير مصرح.", show_alert=True)
        return

    order_id = int(query.data.split("_")[1])

    with flask_app.app_context():
        from app.extensions import db
        from app.models.order import Order, ORDER_STATUS_COMPLETED
        from app.models.admin_staff import AdminStaff
        from app.models.rewards import RewardPoint, PointValueHistory
        from app.models.payment import AuditLog

        order = Order.query.get(order_id)
        if not order:
            await query.edit_message_text("❌ الطلب غير موجود.")
            return

        if order.status == ORDER_STATUS_COMPLETED:
            await query.answer("⚠️ الطلب مكتمل بالفعل.", show_alert=True)
            return

        admin = _get_admin_staff(tid) if not is_owner(tid) else None
        admin_name = admin.display_name if admin else "المالك"

        old_status = order.status
        order.status = ORDER_STATUS_COMPLETED
        order.completed_at = datetime.utcnow()
        if admin:
            order.completed_by_id = admin.id
            admin.total_completed = (admin.total_completed or 0) + 1

        order.log_status_change(old_status, ORDER_STATUS_COMPLETED,
                                note=f"أكمله {admin_name}")

        # منح نقطة للمشرف المُكمِل فقط
        if admin:
            existing_point = RewardPoint.query.filter_by(order_id=order.id).first()
            if not existing_point:
                point_value = PointValueHistory.current_value()
                now = datetime.utcnow()
                point = RewardPoint(
                    admin_id=admin.id,
                    order_id=order.id,
                    month=now.month,
                    year=now.year,
                    reward_value_at_award=point_value,
                )
                db.session.add(point)

        log = AuditLog(
            action="order_completed",
            performed_by=admin_name,
            target_user_id=order.user_id,
            data={"order_number": order.order_number, "admin": admin_name},
        )
        db.session.add(log)
        db.session.commit()

        await query.edit_message_text(
            _format_order_text(order)
            + f"\n\n✅ <b>أُكمل بواسطة:</b> {admin_name}",
            parse_mode=ParseMode.HTML,
        )

        await _notify_log_group(
            context,
            f"✅ <b>اكتمل الطلب</b>\n"
            f"🆔 <code>{order.order_number}</code>\n"
            f"👮 أكمله: {admin_name}"
            + (f"\n🏅 حصل على نقطة بقيمة ${PointValueHistory.current_value():.3f}" if admin else ""),
        )


# ═══════════════════════════════════════════════════════════════════════════
#  أوامر المالك
# ═══════════════════════════════════════════════════════════════════════════

async def cmd_owner(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("⛔ هذا الأمر للمالك فقط.")
        return

    await update.message.reply_text(
        "👑 <b>لوحة المالك</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "/stats — الإحصائيات العامة\n"
        "/report — تقرير شهري\n"
        "/admins — قائمة المشرفين\n"
        "/addadmin {telegram_id} {الاسم} — إضافة مشرف\n"
        "/removeadmin {telegram_id} — حذف مشرف\n"
        "/setpoint {القيمة} — تغيير قيمة النقطة\n"
        "/adjustpoints — تعديل نقاط مشرف يدوياً\n",
        parse_mode=ParseMode.HTML,
    )


async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("⛔ هذا الأمر للمالك فقط.")
        return

    with flask_app.app_context():
        from app.models.order import Order, ORDER_STATUS_COMPLETED, ORDER_STATUS_PENDING
        from app.models.admin_staff import AdminStaff
        from app.models.rewards import RewardPoint, PointValueHistory
        from app.models.user import User
        from app.models.payment import Transaction

        total_orders = Order.query.count()
        completed = Order.query.filter_by(status=ORDER_STATUS_COMPLETED).count()
        pending = Order.query.filter(
            Order.status.in_(["pending", "accepted", "processing", "transferred"])
        ).count()
        total_users = User.query.count()
        active_admins = AdminStaff.query.filter_by(is_active=True).count()
        point_value = PointValueHistory.current_value()

        now = datetime.utcnow()
        points_this_month = RewardPoint.query.filter_by(
            month=now.month, year=now.year
        ).count()

        # إجمالي الإيرادات
        revenue_row = (
            Transaction.query.with_entities(
                __import__("sqlalchemy").func.sum(Transaction.amount)
            )
            .filter(Transaction.type == "debit")
            .scalar()
            or 0.0
        )

        await update.message.reply_text(
            f"📊 <b>الإحصائيات العامة</b>\n"
            f"{'━' * 28}\n"
            f"👥 المستخدمون: {total_users}\n"
            f"👮 المشرفون النشطون: {active_admins}\n"
            f"\n📦 <b>الطلبات:</b>\n"
            f"  الإجمالي: {total_orders}\n"
            f"  المكتملة: {completed}\n"
            f"  المعلقة: {pending}\n"
            f"\n💰 الإيرادات الإجمالية: {abs(revenue_row):.2f} LYD\n"
            f"\n🏅 <b>النقاط ({now.strftime('%B %Y')}):</b>\n"
            f"  النقاط الممنوحة: {points_this_month}\n"
            f"  قيمة النقطة الحالية: ${point_value:.4f}\n",
            parse_mode=ParseMode.HTML,
        )


async def cmd_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("⛔ هذا الأمر للمالك فقط.")
        return

    now = datetime.utcnow()
    args = context.args
    try:
        month = int(args[0]) if args else now.month
        year = int(args[1]) if len(args) > 1 else now.year
    except (ValueError, IndexError):
        await update.message.reply_text("الاستخدام: /report [الشهر] [السنة]\nمثال: /report 7 2025")
        return

    with flask_app.app_context():
        from app.models.admin_staff import AdminStaff
        from app.models.rewards import RewardPoint, PointValueHistory

        admins = AdminStaff.query.filter_by(is_active=True).all()
        if not admins:
            await update.message.reply_text("لا يوجد مشرفون.")
            return

        lines = [
            f"📊 <b>التقرير الشهري — {month}/{year}</b>",
            "━" * 28,
        ]
        total_points = 0
        total_value = 0.0

        for admin in sorted(admins, key=lambda a: -RewardPoint.query.filter_by(
            admin_id=a.id, month=month, year=year
        ).count()):
            points = RewardPoint.query.filter_by(
                admin_id=admin.id, month=month, year=year
            ).all()
            count = len(points)
            value = sum(p.reward_value_at_award for p in points)
            total_points += count
            total_value += value
            lines.append(
                f"👮 {admin.display_name}\n"
                f"   نقاط: {count} | القيمة: ${value:.3f}"
            )

        lines.append("━" * 28)
        lines.append(f"🏅 الإجمالي: {total_points} نقطة | ${total_value:.3f}")

        await update.message.reply_text(
            "\n".join(lines),
            parse_mode=ParseMode.HTML,
        )


async def cmd_admins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("⛔ هذا الأمر للمالك فقط.")
        return

    with flask_app.app_context():
        from app.models.admin_staff import AdminStaff

        admins = AdminStaff.query.order_by(AdminStaff.added_at).all()
        if not admins:
            await update.message.reply_text("لا يوجد مشرفون مسجلون.")
            return

        lines = ["👮 <b>قائمة المشرفين</b>", "━" * 28]
        for a in admins:
            status = "✅ نشط" if a.is_active else "❌ معطّل"
            lines.append(
                f"{status} {a.display_name}\n"
                f"   ID: <code>{a.telegram_id}</code>\n"
                f"   مكتمل: {a.total_completed} | نقاط الشهر: {a.points_this_month}"
            )
        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML)


async def cmd_addadmin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("⛔ هذا الأمر للمالك فقط.")
        return

    args = context.args
    if not args:
        await update.message.reply_text("الاستخدام: /addadmin {telegram_id} {الاسم}")
        return

    try:
        tg_id = int(args[0])
        name = " ".join(args[1:]) if len(args) > 1 else None
    except ValueError:
        await update.message.reply_text("❌ معرّف التيليجرام يجب أن يكون رقماً.")
        return

    with flask_app.app_context():
        from app.extensions import db
        from app.models.admin_staff import AdminStaff
        from app.models.payment import AuditLog

        existing = AdminStaff.query.filter_by(telegram_id=tg_id).first()
        if existing:
            if not existing.is_active:
                existing.is_active = True
                if name:
                    existing.full_name = name
                db.session.commit()
                await update.message.reply_text(f"✅ تم تفعيل المشرف {existing.display_name} مجدداً.")
            else:
                await update.message.reply_text("⚠️ المشرف موجود بالفعل.")
            return

        admin = AdminStaff(
            telegram_id=tg_id,
            full_name=name,
        )
        db.session.add(admin)
        log = AuditLog(
            action="admin_added",
            performed_by=f"المالك ({update.effective_user.id})",
            data={"telegram_id": tg_id, "name": name},
        )
        db.session.add(log)
        db.session.commit()

        await update.message.reply_text(
            f"✅ تمت إضافة المشرف:\n"
            f"الاسم: {name or 'غير محدد'}\n"
            f"ID: <code>{tg_id}</code>",
            parse_mode=ParseMode.HTML,
        )


async def cmd_removeadmin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("⛔ هذا الأمر للمالك فقط.")
        return

    args = context.args
    if not args:
        await update.message.reply_text("الاستخدام: /removeadmin {telegram_id}")
        return

    try:
        tg_id = int(args[0])
    except ValueError:
        await update.message.reply_text("❌ معرّف التيليجرام يجب أن يكون رقماً.")
        return

    with flask_app.app_context():
        from app.extensions import db
        from app.models.admin_staff import AdminStaff
        from app.models.payment import AuditLog

        admin = AdminStaff.query.filter_by(telegram_id=tg_id).first()
        if not admin:
            await update.message.reply_text("❌ المشرف غير موجود.")
            return

        admin.is_active = False
        log = AuditLog(
            action="admin_removed",
            performed_by=f"المالك ({update.effective_user.id})",
            data={"telegram_id": tg_id, "name": admin.display_name},
        )
        db.session.add(log)
        db.session.commit()

        await update.message.reply_text(
            f"✅ تم تعطيل المشرف: {admin.display_name}"
        )


# ─── setpoint — تغيير قيمة النقطة (ConversationHandler) ─────────────────

async def cmd_setpoint_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("⛔ هذا الأمر للمالك فقط.")
        return ConversationHandler.END

    args = context.args
    if args:
        # تنفيذ مباشر: /setpoint 0.05
        return await _do_setpoint(update, context, args[0])

    with flask_app.app_context():
        from app.models.rewards import PointValueHistory
        current = PointValueHistory.current_value()

    await update.message.reply_text(
        f"قيمة النقطة الحالية: <b>${current:.4f}</b>\n\nأرسل القيمة الجديدة (بالدولار):",
        parse_mode=ParseMode.HTML,
    )
    return SET_POINT


async def cmd_setpoint_value(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return await _do_setpoint(update, context, update.message.text.strip())


async def _do_setpoint(update, context, value_str: str):
    try:
        value = float(value_str.replace(",", "."))
        if value <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ قيمة غير صالحة. أرسل رقماً موجباً مثل: 0.05")
        return SET_POINT

    with flask_app.app_context():
        from app.extensions import db
        from app.models.rewards import PointValueHistory
        from app.models.payment import AuditLog

        entry = PointValueHistory(
            value_usd=value,
            changed_by=f"المالك ({update.effective_user.id})",
        )
        db.session.add(entry)
        log = AuditLog(
            action="point_value_changed",
            performed_by=f"المالك ({update.effective_user.id})",
            data={"new_value": value},
        )
        db.session.add(log)
        db.session.commit()

    await update.message.reply_text(
        f"✅ تم تغيير قيمة النقطة إلى: <b>${value:.4f}</b>",
        parse_mode=ParseMode.HTML,
    )
    return ConversationHandler.END


# ─── adjustpoints — تعديل نقاط مشرف يدوياً (ConversationHandler) ────────

async def cmd_adjust_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("⛔ هذا الأمر للمالك فقط.")
        return ConversationHandler.END

    with flask_app.app_context():
        from app.models.admin_staff import AdminStaff
        admins = AdminStaff.query.filter_by(is_active=True).all()
        if not admins:
            await update.message.reply_text("لا يوجد مشرفون.")
            return ConversationHandler.END

        lines = ["👮 <b>اختر المشرف (أرسل الرقم):</b>"]
        for i, a in enumerate(admins, 1):
            lines.append(f"{i}. {a.display_name} (ID: {a.telegram_id})")
        context.user_data["adjust_admins"] = [a.id for a in admins]
        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML)

    return ADJ_ADMIN


async def cmd_adjust_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        idx = int(update.message.text.strip()) - 1
        admin_id = context.user_data["adjust_admins"][idx]
        context.user_data["adjust_admin_id"] = admin_id
    except (ValueError, IndexError):
        await update.message.reply_text("❌ رقم غير صالح، أرسل رقماً من القائمة.")
        return ADJ_ADMIN

    await update.message.reply_text(
        "أرسل عدد النقاط للتعديل (موجب للإضافة، سالب للخصم):\nمثال: 3 أو -1"
    )
    return ADJ_COUNT


async def cmd_adjust_count(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        count = int(update.message.text.strip())
        context.user_data["adjust_count"] = count
    except ValueError:
        await update.message.reply_text("❌ أرسل عدداً صحيحاً.")
        return ADJ_COUNT

    await update.message.reply_text("أرسل سبب التعديل:")
    return ADJ_REASON


async def cmd_adjust_reason(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reason = update.message.text.strip()
    admin_id = context.user_data.get("adjust_admin_id")
    count = context.user_data.get("adjust_count", 0)
    owner_id = update.effective_user.id

    with flask_app.app_context():
        from app.extensions import db
        from app.models.admin_staff import AdminStaff
        from app.models.rewards import RewardPoint, PointValueHistory
        from app.models.payment import AuditLog

        admin = AdminStaff.query.get(admin_id)
        if not admin:
            await update.message.reply_text("❌ المشرف غير موجود.")
            return ConversationHandler.END

        now = datetime.utcnow()
        point_value = PointValueHistory.current_value()

        if count > 0:
            for _ in range(count):
                p = RewardPoint(
                    admin_id=admin.id,
                    month=now.month,
                    year=now.year,
                    reward_value_at_award=point_value,
                    is_manual_adjustment=True,
                    manual_reason=reason,
                    adjusted_by=str(owner_id),
                )
                db.session.add(p)
        elif count < 0:
            # حذف النقاط الأحدث
            points_to_delete = (
                RewardPoint.query
                .filter_by(admin_id=admin.id, month=now.month, year=now.year)
                .order_by(RewardPoint.awarded_at.desc())
                .limit(abs(count))
                .all()
            )
            for p in points_to_delete:
                db.session.delete(p)

        log = AuditLog(
            action="points_adjusted",
            performed_by=f"المالك ({owner_id})",
            data={
                "admin": admin.display_name,
                "count": count,
                "reason": reason,
            },
        )
        db.session.add(log)
        db.session.commit()

        action_text = f"تمت إضافة {count}" if count > 0 else f"تم خصم {abs(count)}"
        await update.message.reply_text(
            f"✅ {action_text} نقطة للمشرف {admin.display_name}\n"
            f"السبب: {reason}",
            parse_mode=ParseMode.HTML,
        )

    context.user_data.clear()
    return ConversationHandler.END


# ─── إلغاء أي محادثة جارية ────────────────────────────────────────────────

async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.message.reply_text("❌ تم إلغاء العملية.")
    return ConversationHandler.END


# ─── معالج الأخطاء ─────────────────────────────────────────────────────────

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"خطأ: {context.error}", exc_info=True)


async def _auction_finalizer_job(context: ContextTypes.DEFAULT_TYPE):
    """Job دوري: إرسال تقرير لأي مزاد انتهى وقته للمالك لاتخاذ القرار."""
    try:
        count = await finalize_due_auctions(context, flask_app)
        if count:
            logger.info("⏰ تم إرسال تقارير %s مزاد منتهي للآدمن.", count)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("فشل فحص المزادات المنتهية: %s", exc)


def _group_buy_finalizer_job(context: ContextTypes.DEFAULT_TYPE):
    """Job دوري: إنهاء/استرداد العروض الجماعية التي انتهى وقتها (داخل سياق Flask)."""
    try:
        with flask_app.app_context():
            from app.services.features import expire_group_buys
            n = expire_group_buys()
            if n:
                logger.info("⏰ تم فحص/إنهاء %s عرض جماعي منتهي.", n)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("فشل فحص العروض الجماعية المنتهية: %s", exc)


async def cmd_finalize(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر يدوي للآدمن لإعادة فحص المزادات والعروض الجماعية فوراً."""
    user = update.effective_user
    if not user or user.id != OWNER_TELEGRAM_ID:
        if update.effective_message:
            await update.effective_message.reply_text("⛔ هذا الأمر للمالك فقط.")
        return
    forced = await finalize_due_auctions(context, flask_app)
    with flask_app.app_context():
        from app.services.features import expire_group_buys
        groups = expire_group_buys()
    text = (
        f"✅ تم الفحص اليدوي:\n"
        f"• المزادات المنتهية المُبلَّغة: {forced}\n"
        f"• العروض الجماعية المنتهية: {groups}"
    )
    if update.effective_message:
        await update.effective_message.reply_text(text)


# ═══════════════════════════════════════════════════════════════════════════
#  نقطة الدخول الرئيسية
# ═══════════════════════════════════════════════════════════════════════════

def main():
    if not TELEGRAM_BOT_TOKEN or TELEGRAM_BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        logger.error("❌ لم يتم تعيين TELEGRAM_BOT_TOKEN في config.py")
        sys.exit(1)

    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    # ─── ConversationHandler — الرفض ───────────────────────────────────────
    reject_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(cb_reject_start, pattern=r"^reject_\d+$")],
        states={REJECT_REASON: [MessageHandler(filters.TEXT & ~filters.COMMAND, cb_reject_reason)]},
        fallbacks=[CommandHandler("cancel", cmd_cancel)],
        per_user=True,
        per_chat=False,
    )

    # ─── ConversationHandler — تغيير قيمة النقطة ─────────────────────────
    setpoint_conv = ConversationHandler(
        entry_points=[CommandHandler("setpoint", cmd_setpoint_start)],
        states={SET_POINT: [MessageHandler(filters.TEXT & ~filters.COMMAND, cmd_setpoint_value)]},
        fallbacks=[CommandHandler("cancel", cmd_cancel)],
    )

    # ─── ConversationHandler — تعديل النقاط ──────────────────────────────
    adjust_conv = ConversationHandler(
        entry_points=[CommandHandler("adjustpoints", cmd_adjust_start)],
        states={
            ADJ_ADMIN:  [MessageHandler(filters.TEXT & ~filters.COMMAND, cmd_adjust_admin)],
            ADJ_COUNT:  [MessageHandler(filters.TEXT & ~filters.COMMAND, cmd_adjust_count)],
            ADJ_REASON: [MessageHandler(filters.TEXT & ~filters.COMMAND, cmd_adjust_reason)],
        },
        fallbacks=[CommandHandler("cancel", cmd_cancel)],
    )

    # ─── Handlers ────────────────────────────────────────────────────────
    app.add_handler(CommandHandler("start",         cmd_start))
    app.add_handler(CommandHandler("help",          cmd_help))
    app.add_handler(CommandHandler("orders",        cmd_orders))
    app.add_handler(CommandHandler("owner",         cmd_owner))
    app.add_handler(CommandHandler("stats",         cmd_stats))
    app.add_handler(CommandHandler("report",        cmd_report))
    app.add_handler(CommandHandler("admins",        cmd_admins))
    app.add_handler(CommandHandler("addadmin",      cmd_addadmin))
    app.add_handler(CommandHandler("removeadmin",   cmd_removeadmin))
    app.add_handler(CommandHandler("auction",       _cmd_auction_wrapped))
    app.add_handler(CommandHandler("finalize",      cmd_finalize))

    app.add_handler(reject_conv)
    app.add_handler(setpoint_conv)
    app.add_handler(adjust_conv)

    app.add_handler(CallbackQueryHandler(cb_accept,          pattern=r"^accept_\d+$"))
    app.add_handler(CallbackQueryHandler(cb_complete,        pattern=r"^complete_\d+$"))
    app.add_handler(CallbackQueryHandler(cb_transfer_start,  pattern=r"^transfer_\d+$"))
    app.add_handler(CallbackQueryHandler(cb_transfer_to,     pattern=r"^transfer_to_\d+_\d+$"))
    app.add_handler(CallbackQueryHandler(cb_cancel_transfer, pattern=r"^cancel_transfer$"))
    app.add_handler(CallbackQueryHandler(_cb_bid_wrapped,
                                         pattern=r"^bid:\d+$"))
    app.add_handler(CallbackQueryHandler(_cb_auction_decision_wrapped,
                                         pattern=r"^auction_(?:sell|cancel):\d+$"))

    # جدولة فحص المزادات المنتهية كل دقيقة لإرسال تقرير للآدمن
    if app.job_queue:
        app.job_queue.run_repeating(
            _auction_finalizer_job, interval=60, first=10,
            name="auction-finalizer",
        )
        app.job_queue.run_repeating(
            _group_buy_finalizer_job, interval=120, first=20,
            name="group-buy-finalizer",
        )

    app.add_error_handler(error_handler)

    logger.info("🚀 بدء تشغيل البوت...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
